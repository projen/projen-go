import { Component } from "./component";
import type { IResolver } from "./file";
import type { Project } from "./project";
import type { TaskOptions } from "./task";
import { Task } from "./task";
import type { TasksManifest } from "./task-model";
/**
 * Defines and manages project tasks.
 *
 * Tasks extend the projen CLI by adding subcommands to it. Task definitions are
 * synthesized into `.projen/tasks.json`.
 */
export declare class Tasks extends Component {
    private readonly _tasks;
    private readonly _env;
    private _runner;
    constructor(project: Project);
    /**
     * All tasks.
     */
    get all(): Task[];
    /**
     * Adds a task to a project.
     * @param name The name of the task
     * @param options Task options.
     */
    addTask(name: string, options?: TaskOptions): Task;
    /**
     * Removes a task from a project.
     *
     * @param name The name of the task to remove.
     *
     * @returns The `Task` that was removed, otherwise `undefined`.
     */
    removeTask(name: string): undefined | Task;
    /**
     * Adds global environment.
     * @param name Environment variable name
     * @param value Value
     */
    addEnvironment(name: string, value: string): void;
    /**
     * Returns a copy of the currently global environment for this project.
     */
    get env(): {
        [key: string]: string;
    };
    /**
     * Finds a task by name. Returns `undefined` if the task cannot be found.
     * @param name The name of the task
     */
    tryFind(name: string): undefined | Task;
    /**
     * Runs the specified task.
     *
     * @param name The name of the task to run.
     * @param args Arguments to pass to the task.
     */
    runTask(name: string, args?: (string | number)[]): void;
    synthesize(): void;
    resolveTasksManifest(resolver: IResolver): TasksManifest;
    private renderTasks;
    private renderEnv;
    /**
     * Ensure that environment variables are persisted as strings
     * to prevent type errors when parsing from tasks.json in future
     */
    private getEnvString;
}
