import { CdktnDeps } from "./cdktn-deps";
import type { CdktnDepsCommonOptions } from "./cdktn-deps";
import type { ConstructLibraryOptions } from "../cdk";
import { ConstructLibrary } from "../cdk";
/**
 * Options for `ConstructLibraryCdktn`.
 */
export interface ConstructLibraryCdktnOptions extends ConstructLibraryOptions, CdktnDepsCommonOptions {
}
/**
 * CDKTN construct library project
 *
 * A multi-language (jsii) construct library which vends constructs designed to
 * use within CDK Terrain (CDKTN), a community-driven fork of CDKTF.
 * Provides a friendly workflow and automatic publishing to the construct catalog.
 *
 * Learn more at https://cdktn.io/
 *
 * @pjid cdktn-construct
 */
export declare class ConstructLibraryCdktn extends ConstructLibrary {
    readonly cdktnDeps: CdktnDeps;
    constructor(options: ConstructLibraryCdktnOptions);
    /**
     * The target CDKTN version for this library.
     */
    get cdktnVersion(): string;
}
