import { Component } from "../component";
import type { Project } from "../project";
import type { Task } from "../task";
/**
 * Adds standard CDKTN tasks to your project.
 */
export declare class CdktnTasks extends Component {
    /**
     * Gets/updates Terraform providers and modules.
     */
    readonly get: Task;
    /**
     * Synthesizes your app.
     */
    readonly synth: Task;
    /**
     * Synthesizes your app and suppresses stdout.
     */
    readonly synthSilent: Task;
    /**
     * Plan your app deployment.
     */
    readonly plan: Task;
    /**
     * Deploys your app.
     */
    readonly deploy: Task;
    /**
     * Destroys all the stacks.
     */
    readonly destroy: Task;
    /**
     * Diff against the currently deployed stacks.
     */
    readonly diff: Task;
    /**
     * Watch task.
     */
    readonly watch: Task;
    constructor(project: Project);
}
