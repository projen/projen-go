import { Component } from "../component";
import { DependencyType } from "../dependencies";
import type { Project } from "../project";
/**
 * Options for `CdktnDeps`
 */
export interface CdktnDepsCommonOptions {
    /**
     * Minimum version of the CDKTN to depend on.
     *
     * @default "^0.24.0"
     */
    readonly cdktnVersion: string;
    /**
     * Version range of the CDKTN CLI to depend on.
     *
     * Can be either a specific version, or an NPM version range.
     *
     * By default, the latest version will be installed; you can use this
     * option to restrict it to a specific version or version range.
     *
     * @default - no specific version
     */
    readonly cdktnCliVersion?: string;
    /**
     * Minimum version of the `constructs` library to depend on.
     *
     * @default "^10.7.2"
     */
    readonly constructsVersion?: string;
    /**
     * Use pinned version instead of caret version for CDKTN.
     *
     * You can use this to prevent mixed versions for your CDKTN dependencies and to prevent auto-updates.
     * If you use experimental features this will let you define the moment you include breaking changes.
     */
    readonly cdktnVersionPinning?: boolean;
}
export interface CdktnDepsOptions extends CdktnDepsCommonOptions {
    /**
     * The type of dependency to use for the runtime `cdktn` module.
     *
     * For libraries, use peer dependencies and for apps use runtime dependencies.
     */
    readonly dependencyType: DependencyType;
}
/**
 * Manages dependencies on CDK Terrain (CDKTN).
 */
export declare class CdktnDeps extends Component {
    /**
     * The dependency requirement for CDKTN (e.g. `^0.24.0`).
     */
    readonly cdktnVersion: string;
    /**
     * The dependency requirement for the CDKTN CLI.
     */
    readonly cdktnCliVersion: string;
    /**
     * The minimum version of CDKTN (e.g. `0.24.0`).
     */
    readonly cdktnMinimumVersion: string;
    private readonly dependencyType;
    constructor(project: Project, options: CdktnDepsOptions);
    /**
     * Adds a dependency on the CDKTN framework package (e.g. `cdktn`).
     */
    private addFrameworkDependency;
    private addConstructsDependency;
}
