import type { IConstruct } from "constructs";
import { Component } from "../component";
import { JsonFile } from "../json";
/**
 * Common options for `cdktf.json`.
 */
export interface CdktnConfigCommonOptions {
    /**
     * Terraform providers to build.
     *
     * @default []
     */
    readonly terraformProviders?: string[];
    /**
     * Terraform modules to build.
     *
     * @default []
     */
    readonly terraformModules?: string[];
    /**
     * Additional context to include in `cdktf.json`.
     *
     * @default - no additional context
     */
    readonly context?: {
        [key: string]: any;
    };
    /**
     * CDKTN output directory.
     *
     * @default "cdktf.out"
     */
    readonly cdktnOut?: string;
    /**
     * CDK project identifier
     *
     * @default - Automatically generated
     */
    readonly projectId?: string;
    /**
     * Whether report crashing to a remote server
     *
     * @default true
     */
    readonly sendCrashReports?: boolean;
}
/**
 * Options for `CdktnConfig`.
 */
export interface CdktnConfigOptions extends CdktnConfigCommonOptions {
    /**
     * The command line to execute in order to synthesize the CDKTN application
     * (language specific).
     */
    readonly app: string;
    /**
     * The programming language used in the CDKTN app.
     *
     * @default "typescript"
     */
    readonly language?: string;
}
/**
 * Represents cdktf.json file.
 *
 * CDKTN (CDK Terrain) continues to use the `cdktf.json` filename for
 * backwards compatibility with its CDKTF origins.
 */
export declare class CdktnConfig extends Component {
    /**
     * Represents the JSON file.
     */
    readonly file: JsonFile;
    /**
     * Name of the cdktn.out directory.
     */
    readonly cdktnOut: string;
    /**
     * List of Terraform providers to build.
     */
    private readonly _terraformProviders;
    /**
     * List of Terraform modules to build.
     */
    private readonly _terraformModules;
    constructor(scope: IConstruct, options: CdktnConfigOptions);
    /**
     * Add Terraform providers to `cdktf.json`.
     * @param providers The providers to add.
     */
    addTerraformProviders(...providers: string[]): void;
    /**
     * Add Terraform modules to `cdktf.json`.
     * @param modules The modules to add.
     */
    addTerraformModules(...modules: string[]): void;
    /**
     * Reads the existing `cdktf.json` from disk and merges projen-managed
     * providers with any that were added externally (e.g. via `cdktn provider add`).
     */
    private resolveTerraformProviders;
    /**
     * Reads the existing `cdktf.json` from disk and merges projen-managed
     * modules with any that were added externally (e.g. via `cdktn get`).
     */
    private resolveTerraformModules;
    /**
     * Merge entries from the existing file with projen-managed entries,
     * deduplicating by value.
     */
    private mergeEntries;
    /**
     * Read the existing cdktf.json file from disk (if it exists).
     */
    private readExistingConfig;
}
