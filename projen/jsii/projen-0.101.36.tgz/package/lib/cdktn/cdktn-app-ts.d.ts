import { CdktnConfig } from "./cdktn-config";
import type { CdktnConfigCommonOptions } from "./cdktn-config";
import { CdktnDeps } from "./cdktn-deps";
import type { CdktnDepsCommonOptions } from "./cdktn-deps";
import { CdktnTasks } from "./cdktn-tasks";
import type { TypeScriptProjectOptions } from "../typescript";
import { TypeScriptAppProject } from "../typescript";
export interface CdktnTypeScriptAppOptions extends TypeScriptProjectOptions, CdktnDepsCommonOptions, CdktnConfigCommonOptions {
    /**
     * The CDKTN app's entrypoint (relative to the source directory, which is
     * "src" by default).
     *
     * @default "main.ts"
     */
    readonly appEntrypoint?: string;
    /**
     * The command line to execute in order to synthesize the CDKTN application
     * (language specific).
     */
    readonly app?: string;
}
/**
 * CDKTN app in TypeScript.
 *
 * CDKTN (CDK Terrain) is a community-driven fork of CDK for Terraform (CDKTF).
 * Learn more at https://cdktn.io/
 *
 * @pjid cdktn-app-ts
 */
export declare class CdktnTypeScriptApp extends TypeScriptAppProject {
    /**
     * The CDKTN app entrypoint.
     */
    readonly appEntrypoint: string;
    /**
     * Common CDKTN tasks.
     */
    readonly cdktnTasks: CdktnTasks;
    /**
     * cdktf.json configuration.
     */
    readonly cdktnConfig: CdktnConfig;
    readonly cdktnDeps: CdktnDeps;
    constructor(options: CdktnTypeScriptAppOptions);
    private getCdktnApp;
}
