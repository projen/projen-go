import type { ConstructLibraryOptions } from "../cdk";
import { ConstructLibrary } from "../cdk";
export interface ConstructLibraryCdktfOptions extends ConstructLibraryOptions {
    /**
     * Minimum target version this library is tested against.
     * @default "^0.13.0"
     * @featured
     */
    readonly cdktfVersion: string;
    /**
     * Construct version to use
     * @default "^10.3.0"
     */
    readonly constructsVersion?: string;
}
/**
 * CDKTF construct library project
 *
 * A multi-language (jsii) construct library which vends constructs designed to
 * use within the CDK for Terraform (CDKTF), with a friendly workflow and
 * automatic publishing to the construct catalog.
 *
 * @deprecated CDKTF has been archived by HashiCorp. Use ConstructLibraryCdktn from the cdktn module instead.
 *             CDKTN is a community-driven fork that continues active development. Learn more at https://cdktn.io/
 * @pjid cdktf-construct
 */
export declare class ConstructLibraryCdktf extends ConstructLibrary {
    constructor(options: ConstructLibraryCdktfOptions);
}
