/**
 * Compatibility shims for older Node.js runtimes.
 *
 * dax's bundled `which` resolves executables by loading `node:fs` through
 * `process.getBuiltinModule()`, an API that only exists since Node 22.3.0 /
 * 20.16.0 (and in no 18.x or older release). On older runtimes every stat
 * call inside `which` throws, the error is treated as "file does not exist",
 * and every task command fails with `dax: <cmd>: command not found`
 * regardless of PATH (https://github.com/projen/projen/issues/4846).
 *
 * projen declares `engines: node >= 16`, so polyfill the API with `require()`
 * on runtimes that lack it. `src/util/dax.ts` - the only module allowed to
 * import dax - installs the polyfill before dax can resolve any command.
 */
/**
 * Installs a `process.getBuiltinModule()` polyfill on the given process
 * object if it does not already provide one.
 *
 * Mirrors the real API: returns the builtin module for both `"fs"` and
 * `"node:fs"` style ids, and `undefined` for anything that is not a builtin
 * (the real API never resolves userland modules).
 */
export declare function polyfillGetBuiltinModule(proc?: NodeJS.Process): void;
