/**
 * The configuration contained in `biome.json`.
 *
 * @schema BiomeConfiguration
 */
export interface BiomeConfiguration {
    /**
     * A field for the JSON schema specification: https://json-schema.org/
     *
     * @schema BiomeConfiguration#$schema
     */
    readonly schema?: string;
    /**
     * The assist configuration.
     *
     * @schema BiomeConfiguration#assist
     */
    readonly assist?: AssistConfiguration;
    /**
     * Configuration specific to CSS.
     *
     * @schema BiomeConfiguration#css
     */
    readonly css?: CssConfiguration;
    /**
     * A list of paths to other JSON files, used to extend the current configuration.
     *
     * @schema BiomeConfiguration#extends
     */
    readonly extends?: string[];
    /**
     * The file handling configuration.
     *
     * @schema BiomeConfiguration#files
     */
    readonly files?: FilesConfiguration;
    /**
     * The formatter configuration.
     *
     * @schema BiomeConfiguration#formatter
     */
    readonly formatter?: FormatterConfiguration;
    /**
     * Configuration specific to GraphQL.
     *
     * @schema BiomeConfiguration#graphql
     */
    readonly graphql?: GraphqlConfiguration;
    /**
     * Configuration specific to GritQL.
     *
     * @schema BiomeConfiguration#grit
     */
    readonly grit?: GritConfiguration;
    /**
     * Configuration specific to HTML.
     *
     * @schema BiomeConfiguration#html
     */
    readonly html?: HtmlConfiguration;
    /**
     * Configuration specific to JavaScript.
     *
     * @schema BiomeConfiguration#javascript
     */
    readonly javascript?: JsConfiguration;
    /**
     * Configuration specific to JSON.
     *
     * @schema BiomeConfiguration#json
     */
    readonly json?: JsonConfiguration;
    /**
     * The linter configuration.
     *
     * @schema BiomeConfiguration#linter
     */
    readonly linter?: LinterConfiguration;
    /**
     * A list of granular patterns applied only to a subset of files.
     *
     * @schema BiomeConfiguration#overrides
     */
    readonly overrides?: OverridePattern[];
    /**
     * List of plugins to load.
     *
     * @schema BiomeConfiguration#plugins
     */
    readonly plugins?: any[];
    /**
     * Indicates whether this configuration file is at the root of a Biome
     * project. By default, this is `true`.
     *
     * @schema BiomeConfiguration#root
     */
    readonly root?: boolean;
    /**
     * The version control integration configuration.
     *
     * @schema BiomeConfiguration#vcs
     */
    readonly vcs?: VcsConfiguration;
}
/**
 * Converts an object of type 'BiomeConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_BiomeConfiguration(obj: BiomeConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema AssistConfiguration
 */
export interface AssistConfiguration {
    /**
     * Whether Biome should fail in CLI if the assist were not applied to the code.
     *
     * @schema AssistConfiguration#actions
     */
    readonly actions?: Actions;
    /**
     * Whether Biome should enable assist via LSP and CLI.
     *
     * @schema AssistConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * A list of glob patterns. Biome will include files/folders that will
     * match these patterns.
     *
     * @schema AssistConfiguration#includes
     */
    readonly includes?: string[];
}
/**
 * Converts an object of type 'AssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_AssistConfiguration(obj: AssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to CSS files.
 *
 * @schema CssConfiguration
 */
export interface CssConfiguration {
    /**
     * CSS assist options.
     *
     * @schema CssConfiguration#assist
     */
    readonly assist?: CssAssistConfiguration;
    /**
     * CSS formatter options.
     *
     * @schema CssConfiguration#formatter
     */
    readonly formatter?: CssFormatterConfiguration;
    /**
     * CSS globals.
     *
     * @schema CssConfiguration#globals
     */
    readonly globals?: string[];
    /**
     * CSS linter options.
     *
     * @schema CssConfiguration#linter
     */
    readonly linter?: CssLinterConfiguration;
    /**
     * CSS parsing options.
     *
     * @schema CssConfiguration#parser
     */
    readonly parser?: CssParserConfiguration;
}
/**
 * Converts an object of type 'CssConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssConfiguration(obj: CssConfiguration | undefined): Record<string, any> | undefined;
/**
 * The file handling configuration.
 *
 * @schema FilesConfiguration
 */
export interface FilesConfiguration {
    /**
     * **Deprecated:** Please use _force-ignore syntax_ in `files.includes`
     * instead: <https://biomejs.dev/reference/configuration/#filesincludes>
     *
     * Set of file and folder names that should be unconditionally ignored by
     * Biome's scanner.
     *
     * @schema FilesConfiguration#experimentalScannerIgnores
     */
    readonly experimentalScannerIgnores?: string[];
    /**
     * Prevents Biome from emitting diagnostics for unrecognized file types.
     *
     * @schema FilesConfiguration#ignoreUnknown
     */
    readonly ignoreUnknown?: boolean;
    /**
     * A list of glob patterns. Biome handles only files and directories that match these
     * patterns.
     *
     * @schema FilesConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * The maximum source file size in bytes. Biome ignores larger files. Defaults to `1 MiB`.
     *
     * @default 1 MiB`.
     * @schema FilesConfiguration#maxSize
     */
    readonly maxSize?: number;
}
/**
 * Converts an object of type 'FilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_FilesConfiguration(obj: FilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * Generic options applied to all files
 *
 * @schema FormatterConfiguration
 */
export interface FormatterConfiguration {
    /**
     * The attribute position style in HTML-like languages. Defaults to `auto`.
     *
     * @default auto`.
     * @schema FormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Places the `>` of a multiline HTML or JSX element at the end of the last line instead of on
     * the next line. Self-closing elements are unaffected. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Whether to insert spaces inside braces in object literals. Defaults to `true`.
     *
     * @default true`.
     * @schema FormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported delimiters when their content fits on one line.
     * It doesn't add spaces before opening delimiters or inside empty delimiters.
     *
     * The affected delimiters vary by language. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * @schema FormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Controls whether arrays and objects are formatted on one line or multiple lines.
     *
     * `auto` formats objects on multiple lines if the first property has a newline, and arrays on
     * one line if they fit.
     *
     * `always` formats arrays and objects on multiple lines.
     *
     * `never` formats arrays and objects on one line if they fit.
     *
     * Defaults to `auto`.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @default auto`.
     * @schema FormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * Allows formatting files that contain syntax errors when set to `true`. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#formatWithErrors
     */
    readonly formatWithErrors?: boolean;
    /**
     * A list of glob patterns. The formatter will include files/folders that will
     * match these patterns.
     *
     * @schema FormatterConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * Uses tabs or spaces for indentation. Defaults to `tab`.
     *
     * @default tab`.
     * @schema FormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width. Defaults to `2`.
     *
     * @default 2`.
     * @schema FormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * Selects the line ending. `auto` uses the platform convention. Defaults to `lf`.
     *
     * @default lf`.
     * @schema FormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width. Defaults to `80`.
     *
     * @default 80`.
     * @schema FormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Whether to add a trailing newline at the end of the file. Defaults to `true`; disabling
     * this option can cause compatibility problems with other tools.
     *
     * @default true`; disabling
     * @schema FormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
    /**
     * Uses `.editorconfig` files to configure the formatter. Settings in `biome.json` or
     * `biome.jsonc` override `.editorconfig` settings. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#useEditorconfig
     */
    readonly useEditorconfig?: boolean;
}
/**
 * Converts an object of type 'FormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_FormatterConfiguration(obj: FormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to GraphQL files.
 *
 * @schema GraphqlConfiguration
 */
export interface GraphqlConfiguration {
    /**
     * GraphQL assist options.
     *
     * @schema GraphqlConfiguration#assist
     */
    readonly assist?: GraphqlAssistConfiguration;
    /**
     * GraphQL formatter options.
     *
     * @schema GraphqlConfiguration#formatter
     */
    readonly formatter?: GraphqlFormatterConfiguration;
    /**
     * GraphQL linter options.
     *
     * @schema GraphqlConfiguration#linter
     */
    readonly linter?: GraphqlLinterConfiguration;
}
/**
 * Converts an object of type 'GraphqlConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlConfiguration(obj: GraphqlConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to GritQL files.
 *
 * @schema GritConfiguration
 */
export interface GritConfiguration {
    /**
     * GritQL assist options.
     *
     * @schema GritConfiguration#assist
     */
    readonly assist?: GritAssistConfiguration;
    /**
     * GritQL formatter options.
     *
     * @schema GritConfiguration#formatter
     */
    readonly formatter?: GritFormatterConfiguration;
    /**
     * GritQL linter options.
     *
     * @schema GritConfiguration#linter
     */
    readonly linter?: GritLinterConfiguration;
}
/**
 * Converts an object of type 'GritConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritConfiguration(obj: GritConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to HTML files.
 *
 * @schema HtmlConfiguration
 */
export interface HtmlConfiguration {
    /**
     * HTML assist options.
     *
     * @schema HtmlConfiguration#assist
     */
    readonly assist?: HtmlAssistConfiguration;
    /**
     * Enables full support for HTML, Vue, Svelte, and Astro files.
     *
     * @schema HtmlConfiguration#experimentalFullSupportEnabled
     */
    readonly experimentalFullSupportEnabled?: boolean;
    /**
     * HTML formatter options.
     *
     * @schema HtmlConfiguration#formatter
     */
    readonly formatter?: HtmlFormatterConfiguration;
    /**
     * HTML linter options.
     *
     * @schema HtmlConfiguration#linter
     */
    readonly linter?: HtmlLinterConfiguration;
    /**
     * HTML parsing options.
     *
     * @schema HtmlConfiguration#parser
     */
    readonly parser?: HtmlParserConfiguration;
}
/**
 * Converts an object of type 'HtmlConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlConfiguration(obj: HtmlConfiguration | undefined): Record<string, any> | undefined;
/**
 * A set of options applied to the JavaScript files
 *
 * @schema JsConfiguration
 */
export interface JsConfiguration {
    /**
     * Assist options
     *
     * @schema JsConfiguration#assist
     */
    readonly assist?: JsAssistConfiguration;
    /**
     * Enables support for embedding snippets.
     *
     * @schema JsConfiguration#experimentalEmbeddedSnippetsEnabled
     */
    readonly experimentalEmbeddedSnippetsEnabled?: boolean;
    /**
     * Formatting options
     *
     * @schema JsConfiguration#formatter
     */
    readonly formatter?: JsFormatterConfiguration;
    /**
     * A list of global bindings that should be ignored by the analyzers
     *
     * If defined here, they should not emit diagnostics.
     *
     * @schema JsConfiguration#globals
     */
    readonly globals?: string[];
    /**
     * Indicates the type of runtime or transformation used for interpreting JSX.
     *
     * @schema JsConfiguration#jsxRuntime
     */
    readonly jsxRuntime?: JsxRuntime;
    /**
     * Linter options
     *
     * @schema JsConfiguration#linter
     */
    readonly linter?: JsLinterConfiguration;
    /**
     * Parsing options
     *
     * @schema JsConfiguration#parser
     */
    readonly parser?: JsParserConfiguration;
    /**
     * Module/dependency resolver options
     *
     * @schema JsConfiguration#resolver
     */
    readonly resolver?: JsResolverConfiguration;
}
/**
 * Converts an object of type 'JsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsConfiguration(obj: JsConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to JSON files
 *
 * @schema JsonConfiguration
 */
export interface JsonConfiguration {
    /**
     * Assist options
     *
     * @schema JsonConfiguration#assist
     */
    readonly assist?: JsonAssistConfiguration;
    /**
     * Formatting options
     *
     * @schema JsonConfiguration#formatter
     */
    readonly formatter?: JsonFormatterConfiguration;
    /**
     * Linting options
     *
     * @schema JsonConfiguration#linter
     */
    readonly linter?: JsonLinterConfiguration;
    /**
     * Parsing options
     *
     * @schema JsonConfiguration#parser
     */
    readonly parser?: JsonParserConfiguration;
}
/**
 * Converts an object of type 'JsonConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonConfiguration(obj: JsonConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema LinterConfiguration
 */
export interface LinterConfiguration {
    /**
     * An object where the keys are the names of the domains, and the values are `all`, `recommended`, or `none`.
     *
     * @schema LinterConfiguration#domains
     */
    readonly domains?: {
        [key: string]: RuleDomainValue;
    };
    /**
     * if `false`, it disables the feature and the linter won't be executed. `true` by default
     *
     * @schema LinterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * A list of glob patterns. The analyzer will handle only those files/folders that will
     * match these patterns.
     *
     * @schema LinterConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * List of rules
     *
     * @schema LinterConfiguration#rules
     */
    readonly rules?: Rules;
}
/**
 * Converts an object of type 'LinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_LinterConfiguration(obj: LinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverridePattern
 */
export interface OverridePattern {
    /**
     * Specific configuration for the Json language
     *
     * @schema OverridePattern#assist
     */
    readonly assist?: OverrideAssistConfiguration;
    /**
     * Specific configuration for the CSS language
     *
     * @schema OverridePattern#css
     */
    readonly css?: CssConfiguration;
    /**
     * Specific configuration for the filesystem
     *
     * @schema OverridePattern#files
     */
    readonly files?: OverrideFilesConfiguration;
    /**
     * Specific configuration for the Json language
     *
     * @schema OverridePattern#formatter
     */
    readonly formatter?: OverrideFormatterConfiguration;
    /**
     * Specific configuration for the Graphql language
     *
     * @schema OverridePattern#graphql
     */
    readonly graphql?: GraphqlConfiguration;
    /**
     * Specific configuration for the GritQL language
     *
     * @schema OverridePattern#grit
     */
    readonly grit?: GritConfiguration;
    /**
     * Specific configuration for the GritQL language
     *
     * @schema OverridePattern#html
     */
    readonly html?: HtmlConfiguration;
    /**
     * A list of glob patterns. Biome will include files/folders that will
     * match these patterns.
     *
     * @schema OverridePattern#includes
     */
    readonly includes?: string[];
    /**
     * Specific configuration for the JavaScript language
     *
     * @schema OverridePattern#javascript
     */
    readonly javascript?: JsConfiguration;
    /**
     * Specific configuration for the Json language
     *
     * @schema OverridePattern#json
     */
    readonly json?: JsonConfiguration;
    /**
     * Specific configuration for the Json language
     *
     * @schema OverridePattern#linter
     */
    readonly linter?: OverrideLinterConfiguration;
    /**
     * Specific configuration for additional plugins
     *
     * @schema OverridePattern#plugins
     */
    readonly plugins?: any[];
}
/**
 * Converts an object of type 'OverridePattern' to JSON representation.
 * @internal
 */
export declare function toJson_OverridePattern(obj: OverridePattern | undefined): Record<string, any> | undefined;
/**
 * Settings for integrating Biome with version control.
 *
 * @schema VcsConfiguration
 */
export interface VcsConfiguration {
    /**
     * The version control client.
     *
     * @schema VcsConfiguration#clientKind
     */
    readonly clientKind?: VcsClientKind;
    /**
     * The project's default branch.
     *
     * @schema VcsConfiguration#defaultBranch
     */
    readonly defaultBranch?: string;
    /**
     * Whether Biome should integrate with the version control client.
     *
     * @schema VcsConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Sets the directory where Biome checks for version control files.
     *
     * Defaults to the directory containing `biome.json` or `biome.jsonc`. If no configuration is
     * found, Biome uses the current working directory.
     *
     * If neither directory is available, Biome disables version control integration and emits a
     * diagnostic.
     *
     * @default the directory containing `biome.json` or `biome.jsonc`. If no configuration is
     * @schema VcsConfiguration#root
     */
    readonly root?: string;
    /**
     * When `true`, Biome ignores files listed in `.gitignore`, `.ignore`, and Git's local
     * exclude file.
     *
     * @schema VcsConfiguration#useIgnoreFile
     */
    readonly useIgnoreFile?: boolean;
}
/**
 * Converts an object of type 'VcsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_VcsConfiguration(obj: VcsConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema Actions
 */
export interface Actions {
    /**
     * The actions preset to use.
     *
     * @schema Actions#preset
     */
    readonly preset?: PresetConfig;
    /**
     * It enables the assist actions recommended by Biome. `true` by default.
     *
     * @schema Actions#recommended
     */
    readonly recommended?: boolean;
    /**
     * @schema Actions#source
     */
    readonly source?: Source;
}
/**
 * Converts an object of type 'Actions' to JSON representation.
 * @internal
 */
export declare function toJson_Actions(obj: Actions | undefined): Record<string, any> | undefined;
/**
 * Options that change how CSS assist behaves.
 *
 * @schema CssAssistConfiguration
 */
export interface CssAssistConfiguration {
    /**
     * Controls assist actions for CSS files.
     *
     * @schema CssAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CssAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssAssistConfiguration(obj: CssAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS formatter behaves.
 *
 * @schema CssFormatterConfiguration
 */
export interface CssFormatterConfiguration {
    /**
     * Controls spaces inside CSS parentheses and square brackets when their content fits on one
     * line. When enabled, `rgb(0, 0, 0)` becomes `rgb( 0, 0, 0 )` and `[data-attr]` becomes
     * `[ data-attr ]`. Empty delimiters are unchanged.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema CssFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Controls the formatter for CSS and languages that extend it.
     *
     * @schema CssFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to CSS and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema CssFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to CSS and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema CssFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to CSS and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema CssFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width for CSS and languages that extend it. If unset, inherits the global
     * line width.
     *
     * @schema CssFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * The type of quotes used in CSS code. Defaults to `double`.
     *
     * @default double`.
     * @schema CssFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema CssFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'CssFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssFormatterConfiguration(obj: CssFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS linter behaves.
 *
 * @schema CssLinterConfiguration
 */
export interface CssLinterConfiguration {
    /**
     * Controls the linter for CSS files.
     *
     * @schema CssLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CssLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssLinterConfiguration(obj: CssLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS parser behaves.
 *
 * @schema CssParserConfiguration
 */
export interface CssParserConfiguration {
    /**
     * Allows comments to appear on incorrect lines in `.css` files.
     *
     * @schema CssParserConfiguration#allowWrongLineComments
     */
    readonly allowWrongLineComments?: boolean;
    /**
     * Enables parsing of CSS Modules-specific features. Enable this feature only
     * when your files don't end in `.module.css`.
     *
     * @schema CssParserConfiguration#cssModules
     */
    readonly cssModules?: boolean;
    /**
     * Enables parsing of Tailwind CSS 4.0 directives and functions.
     *
     * @schema CssParserConfiguration#tailwindDirectives
     */
    readonly tailwindDirectives?: boolean;
}
/**
 * Converts an object of type 'CssParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssParserConfiguration(obj: CssParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema AttributePosition
 */
export declare enum AttributePosition {
    /** auto */
    AUTO = "auto",
    /** multiline */
    MULTILINE = "multiline"
}
/**
 * @schema Expand
 */
export declare enum Expand {
    /** Objects are expanded when the first property has a leading newline. Arrays remain on one
  line if they fit. (auto) */
    AUTO = "auto",
    /** Objects and arrays are always expanded. (always) */
    ALWAYS = "always",
    /** Objects and arrays remain on one line if they fit. (never) */
    NEVER = "never"
}
/**
 * @schema IndentStyle
 */
export declare enum IndentStyle {
    /** Indent with Tab (tab) */
    TAB = "tab",
    /** Indent with Space (space) */
    SPACE = "space"
}
/**
 * @schema LineEnding
 */
export declare enum LineEnding {
    /** Line Feed only (\n), common on Linux and macOS as well as inside git repos (lf) */
    LF = "lf",
    /** Carriage Return + Line Feed characters (\r\n), common on Windows (crlf) */
    CRLF = "crlf",
    /** Carriage Return character only (\r), used very rarely (cr) */
    CR = "cr",
    /** Automatically use CRLF on Windows and LF on other platforms (auto) */
    AUTO = "auto"
}
/**
 * Options that change how GraphQL assist behaves.
 *
 * @schema GraphqlAssistConfiguration
 */
export interface GraphqlAssistConfiguration {
    /**
     * Controls assist actions for GraphQL files.
     *
     * @schema GraphqlAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GraphqlAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlAssistConfiguration(obj: GraphqlAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GraphQL formatter behaves.
 *
 * @schema GraphqlFormatterConfiguration
 */
export interface GraphqlFormatterConfiguration {
    /**
     * Whether to insert spaces inside braces in object literals. If unset, inherits the global
     * bracket spacing setting.
     *
     * @schema GraphqlFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls the formatter for GraphQL files.
     *
     * @schema GraphqlFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to GraphQL files. If unset, inherits the global indentation style.
     *
     * @schema GraphqlFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to GraphQL files. If unset, inherits the global indentation
     * width.
     *
     * @schema GraphqlFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to GraphQL files. If unset, inherits the global line ending.
     *
     * @schema GraphqlFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width for GraphQL files. If unset, inherits the global line width.
     *
     * @schema GraphqlFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * The type of quotes used in GraphQL code. Defaults to `double`.
     *
     * @default double`.
     * @schema GraphqlFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema GraphqlFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'GraphqlFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlFormatterConfiguration(obj: GraphqlFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GraphQL linter behaves.
 *
 * @schema GraphqlLinterConfiguration
 */
export interface GraphqlLinterConfiguration {
    /**
     * Controls the linter for GraphQL files.
     *
     * @schema GraphqlLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GraphqlLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlLinterConfiguration(obj: GraphqlLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how GritQL assist behaves.
 *
 * @schema GritAssistConfiguration
 */
export interface GritAssistConfiguration {
    /**
     * Controls assist actions for GritQL files.
     *
     * @schema GritAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GritAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritAssistConfiguration(obj: GritAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GritQL formatter behaves.
 *
 * @schema GritFormatterConfiguration
 */
export interface GritFormatterConfiguration {
    /**
     * Controls the formatter for GritQL files.
     *
     * @schema GritFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to GritQL files. If unset, inherits the global indentation style.
     *
     * @schema GritFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to GritQL files. If unset, inherits the global indentation
     * width.
     *
     * @schema GritFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to GritQL files. If unset, inherits the global line ending.
     *
     * @schema GritFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width for GritQL files. If unset, inherits the global line width.
     *
     * @schema GritFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema GritFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'GritFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritFormatterConfiguration(obj: GritFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GritQL linter behaves.
 *
 * @schema GritLinterConfiguration
 */
export interface GritLinterConfiguration {
    /**
     * Controls the linter for GritQL files.
     *
     * @schema GritLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GritLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritLinterConfiguration(obj: GritLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how HTML assist behaves.
 *
 * @schema HtmlAssistConfiguration
 */
export interface HtmlAssistConfiguration {
    /**
     * Controls assist actions for HTML and languages that extend it.
     *
     * @schema HtmlAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'HtmlAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlAssistConfiguration(obj: HtmlAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML formatter behaves.
 *
 * @schema HtmlFormatterConfiguration
 */
export interface HtmlFormatterConfiguration {
    /**
     * The attribute position style in HTML elements. If unset, inherits the global attribute
     * position setting.
     *
     * @schema HtmlFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Whether to place the closing bracket of a multiline HTML tag at the end of the last line
     * instead of on its own line. If unset, inherits the global `bracketSameLine` setting.
     *
     * @schema HtmlFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Controls the formatter for HTML and languages that extend it.
     *
     * @schema HtmlFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Whether to indent `<script>` and `<style>` tags in HTML and languages that extend it.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema HtmlFormatterConfiguration#indentScriptAndStyle
     */
    readonly indentScriptAndStyle?: boolean;
    /**
     * The indent style applied to HTML and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema HtmlFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to HTML and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema HtmlFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to HTML and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema HtmlFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width for HTML and languages that extend it. If unset, inherits the global
     * line width.
     *
     * @schema HtmlFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Controls whether void elements are self-closed. Defaults to `never`.
     *
     * @default never`.
     * @schema HtmlFormatterConfiguration#selfCloseVoidElements
     */
    readonly selfCloseVoidElements?: SelfCloseVoidElements;
    /**
     * Whether to add a trailing newline at the end of the file. Unlike other language-specific
     * trailing newline settings, this option defaults to `true` instead of inheriting the global
     * setting.
     *
     * @schema HtmlFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
    /**
     * Whether to account for whitespace sensitivity when formatting HTML and languages that
     * extend it. Defaults to `css`.
     *
     * @default css`.
     * @schema HtmlFormatterConfiguration#whitespaceSensitivity
     */
    readonly whitespaceSensitivity?: WhitespaceSensitivity;
}
/**
 * Converts an object of type 'HtmlFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlFormatterConfiguration(obj: HtmlFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML linter behaves.
 *
 * @schema HtmlLinterConfiguration
 */
export interface HtmlLinterConfiguration {
    /**
     * Controls the linter for HTML and languages that extend it.
     *
     * @schema HtmlLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'HtmlLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlLinterConfiguration(obj: HtmlLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML parser behaves.
 *
 * @schema HtmlParserConfiguration
 */
export interface HtmlParserConfiguration {
    /**
     * Enables parsing double text expressions such as `{{ expression }}` inside `.html` files.
     *
     * @schema HtmlParserConfiguration#interpolation
     */
    readonly interpolation?: boolean;
    /**
     * Enables parsing Vue syntax (`v-if`, `v-bind`, etc.) in `.html` files. Enabling this option
     * also enables `interpolation` implicitly.
     *
     * Biome will already automatically enable Vue parsing in `.vue` files, so you probably don't need
     * to enable this option. This only affects `.html` files, and does not change how `.vue`, `.svelte`,
     * or `.astro` files are parsed.
     *
     * @schema HtmlParserConfiguration#vue
     */
    readonly vue?: boolean;
}
/**
 * Converts an object of type 'HtmlParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlParserConfiguration(obj: HtmlParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * Assist options specific to the JavaScript assist
 *
 * @schema JsAssistConfiguration
 */
export interface JsAssistConfiguration {
    /**
     * Controls assist actions for JavaScript and languages that extend it.
     *
     * @schema JsAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsAssistConfiguration(obj: JsAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Formatting options specific to the JavaScript files
 *
 * @schema JsFormatterConfiguration
 */
export interface JsFormatterConfiguration {
    /**
     * Whether to add parentheses around arrow function parameters. Defaults to `always`.
     *
     * @default always`.
     * @schema JsFormatterConfiguration#arrowParentheses
     */
    readonly arrowParentheses?: ArrowParentheses;
    /**
     * The attribute position style in JSX elements. If unset, inherits the global attribute
     * position setting.
     *
     * @schema JsFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Whether to hug the closing bracket of multiline HTML/JSX tags to the end of the last line,
     * rather than being alone on the following line. If unset, inherits the global bracket
     * placement setting.
     *
     * @schema JsFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Whether to insert spaces inside braces in object literals. If unset, inherits the global
     * bracket spacing setting.
     *
     * @schema JsFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported JavaScript and TypeScript delimiters when their
     * content fits on one line. It doesn't add spaces before opening delimiters or inside empty
     * delimiters.
     *
     * It affects parentheses, square brackets, template interpolations, TypeScript angle brackets,
     * JSX expression braces, and logical NOT. In operator chains, only the final operator receives
     * a following space.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema JsFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Controls the formatter for JavaScript and languages that extend it.
     *
     * @schema JsFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Uses the same `auto`, `always`, and `never` behavior as the global expansion setting.
     *
     * If unset, inherits the global expansion setting.
     *
     * @schema JsFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * The indent style applied to JavaScript and languages that extend it. If unset, inherits the
     * global indentation style.
     *
     * @schema JsFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to JavaScript and languages that extend it. If unset,
     * inherits the global indentation width.
     *
     * @schema JsFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The type of quotes used in JSX. Defaults to `double`.
     *
     * @default double`.
     * @schema JsFormatterConfiguration#jsxQuoteStyle
     */
    readonly jsxQuoteStyle?: QuoteStyle;
    /**
     * The line ending applied to JavaScript and languages that extend it. If unset, inherits the
     * global line ending.
     *
     * @schema JsFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width applied to JavaScript and languages that extend it. If unset,
     * inherits the global line width.
     *
     * @schema JsFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * When breaking binary expressions into multiple lines, whether to break them before or after
     * the binary operator. Defaults to `after`.
     *
     * @default after`.
     * @schema JsFormatterConfiguration#operatorLinebreak
     */
    readonly operatorLinebreak?: OperatorLinebreak;
    /**
     * Controls when object properties are quoted. Defaults to `asNeeded` in configuration
     * (`as-needed` on the CLI).
     *
     * @default asNeeded` in configuration
     * @schema JsFormatterConfiguration#quoteProperties
     */
    readonly quoteProperties?: QuoteProperties;
    /**
     * The type of quotes used in JavaScript code. Defaults to `double`.
     *
     * @default double`.
     * @schema JsFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Prints semicolons after every statement or only where needed to avoid automatic semicolon
     * insertion hazards. Defaults to `always`.
     *
     * @default always`.
     * @schema JsFormatterConfiguration#semicolons
     */
    readonly semicolons?: Semicolons;
    /**
     * Prints trailing commas wherever possible in multiline comma-separated structures. Defaults
     * to `all`.
     *
     * @default all`.
     * @schema JsFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema JsFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'JsFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsFormatterConfiguration(obj: JsFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Indicates the type of runtime or transformation used for interpreting JSX.
 *
 * @schema JsxRuntime
 */
export declare enum JsxRuntime {
    /** Indicates a modern or native JSX environment, that doesn't require
  special handling by Biome. (transparent) */
    TRANSPARENT = "transparent",
    /** Indicates a classic React environment that requires the `React` import.
  
  Corresponds to the `react` value for the `jsx` option in TypeScript's
  `tsconfig.json`.
  
  This option should only be necessary if you cannot upgrade to a React
  version that supports the new JSX runtime. For more information about
  the old vs. new JSX runtime, please see:
  <https://legacy.reactjs.org/blog/2020/09/22/introducing-the-new-jsx-transform.html> (reactClassic) */
    REACT_CLASSIC = "reactClassic"
}
/**
 * Linter options specific to the JavaScript linter
 *
 * @schema JsLinterConfiguration
 */
export interface JsLinterConfiguration {
    /**
     * Controls the linter for JavaScript and languages that extend it.
     *
     * @schema JsLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsLinterConfiguration(obj: JsLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the JavaScript parser behaves.
 *
 * @schema JsParserConfiguration
 */
export interface JsParserConfiguration {
    /**
     * Enables parsing of Grit metavariables.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema JsParserConfiguration#gritMetavariables
     */
    readonly gritMetavariables?: boolean;
    /**
     * When enabled, files such as `.js`, `.mjs`, and `.cjs` may contain JSX syntax. Defaults to
     * `true`.
     *
     * @default true`.
     * @schema JsParserConfiguration#jsxEverywhere
     */
    readonly jsxEverywhere?: boolean;
    /**
     * It enables the experimental and unsafe parsing of parameter decorators
     *
     * These decorators belong to an old proposal, and they are subject to change.
     *
     * @schema JsParserConfiguration#unsafeParameterDecoratorsEnabled
     */
    readonly unsafeParameterDecoratorsEnabled?: boolean;
}
/**
 * Converts an object of type 'JsParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsParserConfiguration(obj: JsParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * Resolver options specific to JavaScript files
 *
 * @schema JsResolverConfiguration
 */
export interface JsResolverConfiguration {
    /**
     * Enables pnpm workspace catalog resolution for JavaScript package manifests.
     *
     * Opt-in:
     * - Set `javascript.resolver.experimentalPnpmCatalogs` to `true`.
     *
     * Scope:
     * - Resolves `catalog:` and `catalog:<name>` dependency versions from
     * `package.json`.
     * - Applies to `dependencies`, `devDependencies`, and `peerDependencies`.
     *
     * Fail-safe behavior:
     * - If `pnpm-workspace.yaml` is missing, unreadable, or cannot be parsed,
     * Biome silently falls back to the default behavior (as if this option
     * were disabled).
     * - Unknown keys and unsupported value shapes in `pnpm-workspace.yaml` are
     * ignored.
     *
     * Limitations:
     * - Only `pnpm-workspace.yaml` is read.
     * - Biome only reads top-level `catalog` / `catalogs` mappings and scalar
     * string entries.
     *
     * Defaults to `false`.
     *
     * @default false`.
     * @schema JsResolverConfiguration#experimentalPnpmCatalogs
     */
    readonly experimentalPnpmCatalogs?: boolean;
}
/**
 * Converts an object of type 'JsResolverConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsResolverConfiguration(obj: JsResolverConfiguration | undefined): Record<string, any> | undefined;
/**
 * Assist options specific to the JSON linter
 *
 * @schema JsonAssistConfiguration
 */
export interface JsonAssistConfiguration {
    /**
     * Controls assist actions for JSON and languages that extend it.
     *
     * @schema JsonAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsonAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonAssistConfiguration(obj: JsonAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema JsonFormatterConfiguration
 */
export interface JsonFormatterConfiguration {
    /**
     * Whether to insert spaces inside braces in object literals. If unset, inherits the global
     * bracket spacing setting.
     *
     * @schema JsonFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces inside JSON square brackets when their content fits on one line. When
     * enabled, `[1, 2, 3]` becomes `[ 1, 2, 3 ]`. Empty brackets are unchanged.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema JsonFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Controls the formatter for JSON and languages that extend it.
     *
     * @schema JsonFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Uses the same `auto`, `always`, and `never` behavior as the global expansion setting.
     *
     * If unset, inherits the global expansion setting.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @schema JsonFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * The indent style applied to JSON and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema JsonFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to JSON and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema JsonFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to JSON and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema JsonFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The maximum line width applied to JSON and languages that extend it. If unset, inherits the
     * global line width.
     *
     * @schema JsonFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Prints trailing commas wherever possible in multiline comma-separated structures. Defaults
     * to `none`.
     *
     * @default none`.
     * @schema JsonFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsonTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema JsonFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'JsonFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonFormatterConfiguration(obj: JsonFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Linter options specific to the JSON linter
 *
 * @schema JsonLinterConfiguration
 */
export interface JsonLinterConfiguration {
    /**
     * Controls the linter for JSON and languages that extend it.
     *
     * @schema JsonLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsonLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonLinterConfiguration(obj: JsonLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the JSON parser behaves.
 *
 * @schema JsonParserConfiguration
 */
export interface JsonParserConfiguration {
    /**
     * Allows parsing comments in `.json` files.
     *
     * @schema JsonParserConfiguration#allowComments
     */
    readonly allowComments?: boolean;
    /**
     * Allows parsing trailing commas in `.json` files.
     *
     * @schema JsonParserConfiguration#allowTrailingCommas
     */
    readonly allowTrailingCommas?: boolean;
}
/**
 * Converts an object of type 'JsonParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonParserConfiguration(obj: JsonParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema RuleDomainValue
 */
export declare enum RuleDomainValue {
    /** Enables all the rules that belong to this domain (all) */
    ALL = "all",
    /** Disables all the rules that belong to this domain (none) */
    NONE = "none",
    /** Enables only the recommended rules for this domain (recommended) */
    RECOMMENDED = "recommended"
}
/**
 * @schema Rules
 */
export interface Rules {
    /**
     * @schema Rules#a11y
     */
    readonly a11Y?: any;
    /**
     * @schema Rules#complexity
     */
    readonly complexity?: any;
    /**
     * @schema Rules#correctness
     */
    readonly correctness?: any;
    /**
     * @schema Rules#nursery
     */
    readonly nursery?: any;
    /**
     * @schema Rules#performance
     */
    readonly performance?: any;
    /**
     * The rule presets to use.
     *
     * @schema Rules#preset
     */
    readonly preset?: PresetConfig;
    /**
     * It enables the lint rules recommended by Biome. `true` by default.
     *
     * @schema Rules#recommended
     */
    readonly recommended?: boolean;
    /**
     * @schema Rules#security
     */
    readonly security?: any;
    /**
     * @schema Rules#style
     */
    readonly style?: any;
    /**
     * @schema Rules#suspicious
     */
    readonly suspicious?: any;
}
/**
 * Converts an object of type 'Rules' to JSON representation.
 * @internal
 */
export declare function toJson_Rules(obj: Rules | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideAssistConfiguration
 */
export interface OverrideAssistConfiguration {
    /**
     * List of actions
     *
     * @schema OverrideAssistConfiguration#actions
     */
    readonly actions?: Actions;
    /**
     * if `false`, it disables the feature and the assist won't be executed. `true` by default
     *
     * @schema OverrideAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'OverrideAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideAssistConfiguration(obj: OverrideAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideFilesConfiguration
 */
export interface OverrideFilesConfiguration {
    /**
     * File size limit in bytes
     *
     * @schema OverrideFilesConfiguration#maxSize
     */
    readonly maxSize?: number;
}
/**
 * Converts an object of type 'OverrideFilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideFilesConfiguration(obj: OverrideFilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideFormatterConfiguration
 */
export interface OverrideFormatterConfiguration {
    /**
     * The attribute position style.
     *
     * @schema OverrideFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Put the `>` of a multi-line HTML or JSX element at the end of the last line instead of being alone on the next line (does not apply to self closing elements).
     *
     * @schema OverrideFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Whether to insert spaces around brackets in object literals. Defaults to true.
     *
     * @default true.
     * @schema OverrideFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported delimiters when their content fits on one line.
     * It doesn't add spaces before opening delimiters or inside empty delimiters.
     *
     * The affected delimiters vary by language. If unset, uses the configured formatter setting.
     *
     * @schema OverrideFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * @schema OverrideFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Controls whether arrays and objects are formatted on one line or multiple lines.
     *
     * `auto` formats objects on multiple lines if the first property has a newline, and arrays on
     * one line if they fit.
     *
     * `always` formats arrays and objects on multiple lines.
     *
     * `never` formats arrays and objects on one line if they fit.
     *
     * If unset, uses the configured formatter setting.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @schema OverrideFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * Stores whether formatting should be allowed to proceed if a given file
     * has syntax errors
     *
     * @schema OverrideFormatterConfiguration#formatWithErrors
     */
    readonly formatWithErrors?: boolean;
    /**
     * The size of the indentation, 2 by default (deprecated, use `indent-width`)
     *
     * @schema OverrideFormatterConfiguration#indentSize
     */
    readonly indentSize?: number;
    /**
     * The indent style.
     *
     * @schema OverrideFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The size of the indentation, 2 by default
     *
     * @schema OverrideFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The type of line ending.
     *
     * @schema OverrideFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * What's the max width of a line. Defaults to 80.
     *
     * @default 80.
     * @schema OverrideFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Print trailing commas wherever possible in multi-line comma-separated syntactic structures.
     *
     * @schema OverrideFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of the file.
     *
     * Setting this option to `false` is **highly discouraged** because it could cause many problems with other tools:
     * - https://thoughtbot.com/blog/no-newline-at-end-of-file
     * - https://callmeryan.medium.com/no-newline-at-end-of-file-navigating-gits-warning-for-android-developers-af14e73dd804
     * - https://unix.stackexchange.com/questions/345548/how-to-cat-files-together-adding-missing-newlines-at-end-of-some-files
     *
     * Disable the option at your own risk.
     *
     * Defaults to true.
     *
     * @default true.
     * @schema OverrideFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'OverrideFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideFormatterConfiguration(obj: OverrideFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideLinterConfiguration
 */
export interface OverrideLinterConfiguration {
    /**
     * List of rules
     *
     * @schema OverrideLinterConfiguration#domains
     */
    readonly domains?: {
        [key: string]: RuleDomainValue;
    };
    /**
     * if `false`, it disables the feature and the linter won't be executed. `true` by default
     *
     * @schema OverrideLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * List of rules
     *
     * @schema OverrideLinterConfiguration#rules
     */
    readonly rules?: Rules;
}
/**
 * Converts an object of type 'OverrideLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideLinterConfiguration(obj: OverrideLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Integration with Git as the version control client.
 *
 * @schema VcsClientKind
 */
export declare enum VcsClientKind {
    /** git */
    GIT = "git"
}
/**
 * A preset configuration for enabling a set of rules.
 *
 * @schema PresetConfig
 */
export declare enum PresetConfig {
    /** recommended */
    RECOMMENDED = "recommended",
    /** all */
    ALL = "all",
    /** none */
    NONE = "none"
}
/**
 * A list of rules that belong to this group
 *
 * @schema Source
 */
export interface Source {
    /**
     * Remove duplicate CSS classes.
     * See https://biomejs.dev/assist/actions/no-duplicate-classes
     *
     * @schema Source#noDuplicateClasses
     */
    readonly noDuplicateClasses?: any;
    /**
     * Sorts imports and exports in your JavaScript and TypeScript files.
     * See https://biomejs.dev/assist/actions/organize-imports
     *
     * @schema Source#organizeImports
     */
    readonly organizeImports?: any;
    /**
     * Enables a particular rule preset
     *
     * @schema Source#preset
     */
    readonly preset?: PresetConfig;
    /**
     * Enables the recommended rules for this group
     *
     * @schema Source#recommended
     */
    readonly recommended?: boolean;
    /**
     * Enforce attribute sorting in HTML elements.
     * See https://biomejs.dev/assist/actions/use-sorted-attributes
     *
     * @schema Source#useSortedAttributes
     */
    readonly useSortedAttributes?: any;
    /**
     * Sort the members of an enum in natural order.
     * See https://biomejs.dev/assist/actions/use-sorted-enum-members
     *
     * @schema Source#useSortedEnumMembers
     */
    readonly useSortedEnumMembers?: any;
    /**
     * Sort interface members by key.
     * See https://biomejs.dev/assist/actions/use-sorted-interface-members
     *
     * @schema Source#useSortedInterfaceMembers
     */
    readonly useSortedInterfaceMembers?: any;
    /**
     * Sort the keys of a JSON object in natural order.
     * See https://biomejs.dev/assist/actions/use-sorted-keys
     *
     * @schema Source#useSortedKeys
     */
    readonly useSortedKeys?: any;
    /**
     * Organize package.json fields according to established conventions.
     * See https://biomejs.dev/assist/actions/use-sorted-package-json
     *
     * @schema Source#useSortedPackageJson
     */
    readonly useSortedPackageJson?: any;
    /**
     * Enforce ordering of CSS properties and nested rules.
     * See https://biomejs.dev/assist/actions/use-sorted-properties
     *
     * @schema Source#useSortedProperties
     */
    readonly useSortedProperties?: any;
    /**
     * Sort GraphQL selection sets.
     * See https://biomejs.dev/assist/actions/use-sorted-selection-set
     *
     * @schema Source#useSortedSelectionSet
     */
    readonly useSortedSelectionSet?: any;
    /**
     * Sort fields in GraphQL type definitions alphabetically.
     * See https://biomejs.dev/assist/actions/use-sorted-type-fields
     *
     * @schema Source#useSortedTypeFields
     */
    readonly useSortedTypeFields?: any;
}
/**
 * Converts an object of type 'Source' to JSON representation.
 * @internal
 */
export declare function toJson_Source(obj: Source | undefined): Record<string, any> | undefined;
/**
 * @schema QuoteStyle
 */
export declare enum QuoteStyle {
    /** double */
    DOUBLE = "double",
    /** single */
    SINGLE = "single"
}
/**
 * Controls whether void-elements should be self closed
 *
 * @schema SelfCloseVoidElements
 */
export declare enum SelfCloseVoidElements {
    /** The `/` inside void elements is removed by the formatter (never) */
    NEVER = "never",
    /** The `/` inside void elements is always added (always) */
    ALWAYS = "always"
}
/**
 * Whitespace sensitivity for HTML formatting.
 *
 * The following two cases won't produce the same output:
 *
 * |                |      html      |    output    |
 * | -------------- | :------------: | :----------: |
 * | with spaces    | `1<b> 2 </b>3` | 1<b> 2 </b>3 |
 * | without spaces |  `1<b>2</b>3`  |  1<b>2</b>3  |
 *
 * This happens because whitespace is significant in inline elements.
 *
 * As a consequence of this, the formatter must format blocks that look like this (assume a small line width, <20):
 * ```html
 * <span>really long content</span>
 * ```
 * as this, where the content hugs the tags:
 * ```html
 * <span
 * >really long content</span
 * >
 * ```
 *
 * Note that this is only necessary for inline elements. Block elements do not have this restriction.
 *
 * @schema WhitespaceSensitivity
 */
export declare enum WhitespaceSensitivity {
    /** The formatter considers whitespace significant for elements that have an "inline" display style by default in
  browser's user agent style sheets. (css) */
    CSS = "css",
    /** Leading and trailing whitespace in content is considered significant for all elements.
  
  The formatter should leave at least one whitespace character if whitespace is present.
  Otherwise, if there is no whitespace, it should not add any after `>` or before `<`. In other words, if there's no whitespace, the text content should hug the tags.
  
  Example of text hugging the tags:
  ```html
  <b
      >content</b
  >
  ``` (strict) */
    STRICT = "strict",
    /** Whitespace is considered insignificant. The formatter is free to remove or add whitespace as it sees fit. (ignore) */
    IGNORE = "ignore"
}
/**
 * @schema ArrowParentheses
 */
export declare enum ArrowParentheses {
    /** always */
    ALWAYS = "always",
    /** asNeeded */
    AS_NEEDED = "asNeeded"
}
/**
 * @schema OperatorLinebreak
 */
export declare enum OperatorLinebreak {
    /** The operator is placed after the expression (after) */
    AFTER = "after",
    /** The operator is placed before the expression (before) */
    BEFORE = "before"
}
/**
 * @schema QuoteProperties
 */
export declare enum QuoteProperties {
    /** asNeeded */
    AS_NEEDED = "asNeeded",
    /** preserve */
    PRESERVE = "preserve"
}
/**
 * @schema Semicolons
 */
export declare enum Semicolons {
    /** always */
    ALWAYS = "always",
    /** asNeeded */
    AS_NEEDED = "asNeeded"
}
/**
 * Print trailing commas wherever possible in multi-line comma-separated syntactic structures for JavaScript/TypeScript files.
 *
 * @schema JsTrailingCommas
 */
export declare enum JsTrailingCommas {
    /** all */
    ALL = "all",
    /** es5 */
    ES5 = "es5",
    /** none */
    NONE = "none"
}
/**
 * Print trailing commas wherever possible in multi-line comma-separated syntactic structures for JSON files.
 *
 * @schema JsonTrailingCommas
 */
export declare enum JsonTrailingCommas {
    /** none */
    NONE = "none",
    /** all */
    ALL = "all"
}
