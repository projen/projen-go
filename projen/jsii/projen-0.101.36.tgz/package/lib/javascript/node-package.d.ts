import type { PnpmWorkspaceYamlOptions } from "./pnpm-workspace";
import type { YarnrcOptions } from "./yarnrc";
import { Component } from "../component";
import { JsonFile } from "../json";
import type { Project } from "../project";
import type { Task } from "../task";
export interface NodePackageOptions {
    /**
     * The "name" in package.json
     * @default - defaults to project name
     * @featured
     */
    readonly packageName?: string;
    /**
     * The description is just a string that helps people understand the purpose of the package.
     * It can be used when searching for packages in a package manager as well.
     * See https://classic.yarnpkg.com/en/docs/package-json/#toc-description
     * @featured
     */
    readonly description?: string;
    /**
     * Runtime dependencies of this module.
     *
     * The recommendation is to only specify the module name here (e.g.
     * `express`). This will behave similar to `pnpm add` or `npm install` in the
     * sense that it will add the module as a dependency to your `package.json`
     * file with the latest version (`^`). You can specify semver requirements in
     * the same syntax passed to `pnpm add` or `npm i` (e.g. `express@^2`) and
     * this will be what your `package.json` will eventually include.
     *
     * @example [ 'express', 'lodash', 'foo@^2' ]
     * @default []
     * @featured
     */
    readonly deps?: string[];
    /**
     * Build dependencies for this module. These dependencies will only be
     * available in your build environment but will not be fetched when this
     * module is consumed.
     *
     * The recommendation is to only specify the module name here (e.g.
     * `express`). This will behave similar to `pnpm add` or `npm install` in the
     * sense that it will add the module as a dependency to your `package.json`
     * file with the latest version (`^`). You can specify semver requirements in
     * the same syntax passed to `pnpm add` or `npm i` (e.g. `express@^2`) and
     * this will be what your `package.json` will eventually include.
     *
     * @example [ 'typescript', '@types/express' ]
     * @default []
     * @featured
     */
    readonly devDeps?: string[];
    /**
     * Peer dependencies for this module. Dependencies listed here are required to
     * be installed (and satisfied) by the _consumer_ of this library. Using peer
     * dependencies allows you to ensure that only a single module of a certain
     * library exists in the `node_modules` tree of your consumers.
     *
     * Note that prior to npm@7, peer dependencies are _not_ automatically
     * installed, which means that adding peer dependencies to a library will be a
     * breaking change for your customers.
     *
     * Unless `peerDependencyOptions.pinnedDevDependency` is disabled (it is
     * enabled by default), projen will automatically add a dev dependency with a
     * pinned version for each peer dependency. This will ensure that you build &
     * test your module against the lowest peer version required.
     *
     * @default []
     */
    readonly peerDeps?: string[];
    /**
     * List of dependencies to bundle into this module. These modules will be
     * added both to the `dependencies` section and `bundledDependencies` section of
     * your `package.json`.
     *
     * The recommendation is to only specify the module name here (e.g.
     * `express`). This will behave similar to `pnpm add` or `npm install` in the
     * sense that it will add the module as a dependency to your `package.json`
     * file with the latest version (`^`). You can specify semver requirements in
     * the same syntax passed to `pnpm add` or `npm i` (e.g. `express@^2`) and
     * this will be what your `package.json` will eventually include.
     */
    readonly bundledDeps?: string[];
    /**
     * Options for `peerDeps`.
     */
    readonly peerDependencyOptions?: PeerDependencyOptions;
    /**
     * Allow the project to include `peerDependencies` and `bundledDependencies`.
     * This is normally only allowed for libraries. For apps, there's no meaning
     * for specifying these.
     *
     * @default true
     */
    readonly allowLibraryDependencies?: boolean;
    /**
     * Keywords to include in `package.json`.
     */
    readonly keywords?: string[];
    /**
     * Module entrypoint (`main` in `package.json`)
     *
     * Set to an empty string to not include `main` in your package.json
     *
     * @default "lib/index.js"
     */
    readonly entrypoint?: string;
    /**
     * Binary programs vended with your module.
     *
     * You can use this option to add/customize how binaries are represented in
     * your `package.json`, but unless `autoDetectBin` is `false`, every
     * executable file under `bin` will automatically be added to this section.
     */
    readonly bin?: Record<string, string>;
    /**
     * Automatically add all executables under the `bin` directory to your
     * `package.json` file under the `bin` section.
     *
     * @default true
     */
    readonly autoDetectBin?: boolean;
    /**
     * The Node Package Manager used to execute scripts
     *
     * @default - Detected from the calling process or `YARN_CLASSIC` if detection fails.
     * @pjnew $PACKAGE_MANAGER
     */
    readonly packageManager?: NodePackageManager;
    /**
     * Add a `dedupe` task that deduplicates project dependencies.
     *
     * Deduplication prevents multiple versions of the same package from being
     * installed, if a single version can satisfy all requested version ranges.
     * This prevents version proliferation and reduces the size of the dependency
     * tree.
     *
     * The behavior depends on the package manager:
     * - npm: runs `npm dedupe` after every mutating install.
     * - pnpm: runs `pnpm dedupe` after every mutating install.
     * - Yarn Berry: runs `yarn dedupe` after every mutating install. If
     *   `yarnBerryOptions.dedupePackages` is set, only the listed packages are
     *   deduplicated.
     * - Yarn Classic: `yarn install` already deduplicates, so the task only
     *   prints an informational message.
     * - Bun: not supported, enabling this option throws an error.
     *
     * @default - false, unless `yarnBerryOptions.dedupePackages` is set
     */
    readonly dedupeDeps?: boolean;
    /**
     * The repository is the location where the actual code for your package lives.
     * See https://classic.yarnpkg.com/en/docs/package-json/#toc-repository
     */
    readonly repository?: string;
    /**
     * If the package.json for your package is not in the root directory (for example if it is part of a monorepo),
     * you can specify the directory in which it lives.
     */
    readonly repositoryDirectory?: string;
    /**
     * Author's name
     */
    readonly authorName?: string;
    /**
     * Author's e-mail
     */
    readonly authorEmail?: string;
    /**
     * Author's URL / Website
     */
    readonly authorUrl?: string;
    /**
     * Is the author an organization
     */
    readonly authorOrganization?: boolean;
    /**
     * Package's Homepage / Website
     */
    readonly homepage?: string;
    /**
     * Package's Stability
     */
    readonly stability?: string;
    /**
     * The minimum node version required by this package to function.
     * Most projects should not use this option.
     *
     * The value indicates that the package is incompatible with any older versions of node.
     * This requirement is enforced via the engines field.
     *
     * You will normally not need to set this option, even if your package is incompatible with EOL versions of node.
     * Consider this option only if your package depends on a specific feature, that is not available in other LTS versions.
     * Setting this option has very high impact on the consumers of your package,
     * as package managers will actively prevent usage with node versions you have marked as incompatible.
     *
     * To change the node version of your CI/CD workflows, use `workflowNodeVersion`.
     *
     * @default - no minimum version is enforced
  
     */
    readonly minNodeVersion?: string;
    /**
     * The maximum node version supported by this package.
     * Most projects should not use this option.
     *
     * The value indicates that the package is incompatible with any newer versions of node.
     * This requirement is enforced via the engines field.
     *
     * You will normally not need to set this option.
     * Consider this option only if your package is known to not function with newer versions of node.
     *
     * @default - no maximum version is enforced
     */
    readonly maxNodeVersion?: string;
    /**
     * The version of PNPM to use if using PNPM as a package manager.
     *
     * @default "10.33.0"
     */
    readonly pnpmVersion?: string;
    /**
     * The version of Bun to use if using Bun as a package manager.
     *
     * @default "latest"
     */
    readonly bunVersion?: string;
    /**
     * License's SPDX identifier.
     * See https://github.com/projen/projen/tree/main/license-text for a list of supported licenses.
     * Use the `licensed` option if you want to no license to be specified.
     *
     * @default "Apache-2.0"
     */
    readonly license?: string;
    /**
     * Indicates if a license should be added.
     *
     * @default true
     */
    readonly licensed?: boolean;
    /**
     * The base URL of the npm package registry.
     *
     * Must be a URL (e.g. start with "https://" or "http://")
     *
     * @default "https://registry.npmjs.org"
     */
    readonly npmRegistryUrl?: string;
    /**
     * The url to your project's issue tracker.
     */
    readonly bugsUrl?: string;
    /**
     * The email address to which issues should be reported.
     */
    readonly bugsEmail?: string;
    /**
     * Access level of the npm package.
     *
     * @default - for scoped packages (e.g. `foo@bar`), the default is
     * `NpmAccess.RESTRICTED`, for non-scoped packages, the default is
     * `NpmAccess.PUBLIC`.
     */
    readonly npmAccess?: NpmAccess;
    /**
     * Should provenance statements be generated when the package is published.
     *
     * A supported package manager is required to publish a package with npm provenance statements and
     * you will need to use a supported CI/CD provider.
     *
     * Note that the projen `Release` and `Publisher` components are using `publib` to publish packages,
     * which is using npm internally and supports provenance statements independently of the package manager used.
     *
     * @see https://docs.npmjs.com/generating-provenance-statements
     * @default - true for public packages, false otherwise
     */
    readonly npmProvenance?: boolean;
    /**
     * GitHub secret which contains the NPM token to use when publishing packages.
     *
     * @default "NPM_TOKEN"
     */
    readonly npmTokenSecret?: string;
    /**
     * Use trusted publishing for publishing to npmjs.com
     * Needs to be pre-configured on npm.js to work.
     *
     * @see
     *
     * @default - false
     */
    readonly npmTrustedPublishing?: boolean;
    /**
     * Options for npm packages using AWS CodeArtifact.
     * This is required if publishing packages to, or installing scoped packages from AWS CodeArtifact
     *
     * @default - undefined
     */
    readonly codeArtifactOptions?: CodeArtifactOptions;
    /**
     * Options for privately hosted scoped packages
     *
     * @default - fetch all scoped packages from the public npm registry
     */
    readonly scopedPackagesOptions?: ScopedPackagesOptions[];
    /**
     * Options for Yarn Berry
     *
     * @default - Yarn Berry v4 with all default options
     */
    readonly yarnBerryOptions?: YarnBerryOptions;
    /**
     * Options for pnpm
     *
     * @default - all default options
     */
    readonly pnpmOptions?: PnpmOptions;
    /**
     * Configure the `devEngines` field in `package.json`.
     *
     * The `devEngines.packageManager` field is automatically populated based on
     * the resolved `packageManager` value. Any fields provided here are merged
     * with the auto-populated `packageManager` entry.
     *
     * @see https://docs.npmjs.com/cli/v10/configuring-npm/package-json#devengines
     */
    readonly devEngines?: DevEngines;
    /**
     * Automatically add the resolved `packageManager` to `devEngines.packageManager`
     * in `package.json`, setting `onFail` to `ignore`.
     *
     * @default true
     */
    readonly addPackageManagerToDevEngines?: boolean;
    /**
     * Automatically delete lockfiles from package managers that are not the
     * active one. Only triggered when the lockfile for the configured package
     * manager already exists.
     *
     * This is useful when migrating between package managers to avoid conflicts.
     *
     * @default true
     */
    readonly deleteOrphanedLockFiles?: boolean;
    /**
     * List of dependency (package) names that are allowed to run lifecycle
     * install scripts (`preinstall`, `install`, `postinstall`, `prepare`)
     * during dependency installation.
     *
     * These scripts can execute arbitrary code, making them a common
     * supply-chain attack vector. Package managers are moving toward
     * blocking them by default and requiring an explicit allowlist.
     * Configuring `allowScripts` sets up that allowlist so scripts only run
     * for the packages you have explicitly reviewed and trust.
     *
     * Support for this setting depends on the configured `packageManager`:
     *
     * - `NPM`: written to the native `allowScripts` field in `package.json`
     *   (requires npm >= 11.16; see https://docs.npmjs.com/cli/v11/commands/npm-approve-scripts).
     * - `BUN`: written to the native `trustedDependencies` field in
     *   `package.json` (see https://bun.com/docs/pm/lifecycle).
     * - `PNPM`: written to the `onlyBuiltDependencies` setting in
     *   `pnpm-workspace.yaml` (see https://pnpm.io/settings#onlybuiltdependencies).
     * - `YARN2`, `YARN_BERRY`: written to the native
     *   `dependenciesMeta.<pkg>.built` allowlist in `package.json`, combined
     *   with `enableScripts: false` in `.yarnrc.yml` (see
     *   https://yarnpkg.com/features/security#postinstalls). If you set
     *   `yarnBerryOptions.yarnRcOptions.enableScripts` explicitly, that value
     *   is respected instead of being overridden.
     * - `YARN`, `YARN_CLASSIC`: not supported. Yarn Classic has no native
     *   mechanism to allowlist install scripts for specific dependencies.
     *   Setting this option with one of these package managers throws an
     *   error at synthesis time.
     *
     * @default - all install scripts are allowed to run (package manager default)
     */
    readonly allowScripts?: string[];
}
/**
 * A dependency entry for the `devEngines` field in `package.json`.
 */
export interface DevEngineDependency {
    /**
     * The name of the dependency.
     */
    readonly name: string;
    /**
     * The version range for the dependency.
     *
     * @default "*"
     */
    readonly version?: string;
    /**
     * What action to take if validation fails.
     *
     * @default "error"
     */
    readonly onFail?: "ignore" | "warn" | "error" | "download";
}
/**
 * The `devEngines` field in `package.json`.
 *
 * @see https://docs.npmjs.com/cli/v10/configuring-npm/package-json#devengines
 */
export interface DevEngines {
    /**
     * Supported operating systems.
     */
    readonly os?: DevEngineDependency | DevEngineDependency[];
    /**
     * Supported CPU architectures.
     */
    readonly cpu?: DevEngineDependency | DevEngineDependency[];
    /**
     * Supported C standard libraries.
     */
    readonly libc?: DevEngineDependency | DevEngineDependency[];
    /**
     * Supported JavaScript runtimes.
     */
    readonly runtime?: DevEngineDependency | DevEngineDependency[];
    /**
     * Supported package managers.
     */
    readonly packageManager?: DevEngineDependency | DevEngineDependency[];
}
/**
 * Options for authorizing requests to a AWS CodeArtifact npm repository.
 */
export declare enum CodeArtifactAuthProvider {
    /**
     * Fixed credentials provided via Github secrets.
     */
    ACCESS_AND_SECRET_KEY_PAIR = "ACCESS_AND_SECRET_KEY_PAIR",
    /**
     * Ephemeral credentials provided via Github's OIDC integration with an IAM role.
     * See:
     * https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_create_oidc.html
     * https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
     */
    GITHUB_OIDC = "GITHUB_OIDC"
}
/**
 * Options for publishing npm packages to AWS CodeArtifact.
 */
export interface CodeArtifactOptions {
    /**
     * Provider to use for authorizing requests to AWS CodeArtifact.
     *
     * @default CodeArtifactAuthProvider.ACCESS_AND_SECRET_KEY_PAIR
     */
    readonly authProvider?: CodeArtifactAuthProvider;
    /**
     * GitHub secret which contains the AWS access key ID to use when publishing packages to AWS CodeArtifact.
     * This property must be specified only when publishing to AWS CodeArtifact (`npmRegistryUrl` contains AWS CodeArtifact URL).
     *
     * @default - When the `authProvider` value is set to
     * `CodeArtifactAuthProvider.ACCESS_AND_SECRET_KEY_PAIR`, the default is
     * "AWS_ACCESS_KEY_ID". For `CodeArtifactAuthProvider.GITHUB_OIDC`, this
     * value must be left undefined.
     */
    readonly accessKeyIdSecret?: string;
    /**
     * GitHub secret which contains the AWS secret access key to use when publishing packages to AWS CodeArtifact.
     * This property must be specified only when publishing to AWS CodeArtifact (`npmRegistryUrl` contains AWS CodeArtifact URL).
     *
     * @default - When the `authProvider` value is set to
     * `CodeArtifactAuthProvider.ACCESS_AND_SECRET_KEY_PAIR`, the default is
     * "AWS_SECRET_ACCESS_KEY". For `CodeArtifactAuthProvider.GITHUB_OIDC`, this
     * value must be left undefined.
     */
    readonly secretAccessKeySecret?: string;
    /**
     * ARN of AWS role to be assumed prior to get authorization token from AWS CodeArtifact
     * This property must be specified only when publishing to AWS CodeArtifact (`registry` contains AWS CodeArtifact URL).
     * When using the `CodeArtifactAuthProvider.GITHUB_OIDC` auth provider, this value must be defined.
     *
     * @default undefined
     */
    readonly roleToAssume?: string;
}
/**
 * Options for scoped packages
 */
export interface ScopedPackagesOptions {
    /**
     * Scope of the packages
     *
     * @example "@angular"
     */
    readonly scope: string;
    /**
     * URL of the registry for scoped packages
     */
    readonly registryUrl: string;
}
/**
 * Represents the npm `package.json` file.
 */
export declare class NodePackage extends Component {
    /**
     * Returns the `NodePackage` instance associated with a project or `undefined` if
     * there is no NodePackage.
     * @param project The project
     * @returns A NodePackage, or undefined
     */
    static of(project: Project): NodePackage | undefined;
    /**
     * The name of the npm package.
     */
    readonly packageName: string;
    /**
     * The module's entrypoint (e.g. `lib/index.js`).
     */
    readonly entrypoint: string;
    /**
     * Allow project to take library dependencies.
     */
    readonly allowLibraryDependencies: boolean;
    /**
     * The package manager to use.
     */
    readonly packageManager: NodePackageManager;
    /**
     * @deprecated use `addField(x, y)`
     */
    readonly manifest: any;
    /**
     * The minimum node version required by this package to function.
     *
     * This value indicates the package is incompatible with older versions.
     */
    readonly minNodeVersion?: string;
    /**
     * Maximum node version supported by this package.
     *
     * The value indicates the package is incompatible with newer versions.
     */
    readonly maxNodeVersion?: string;
    /**
     * The version of PNPM to use if using PNPM as a package manager.
     *
     * @returns `undefined` if the package manager is not PNPM.
     */
    get pnpmVersion(): string | undefined;
    /**
     * The version of Bun to use if using Bun as a package manager.
     *
     * @returns `undefined` if the package manager is not Bun.
     */
    get bunVersion(): string | undefined;
    /**
     * The version of Yarn to use if using Yarn as a package manager.
     *
     * @returns `undefined` if the package manager is not Yarn.
     */
    get yarnVersion(): string | undefined;
    private readonly _pnpmVersion;
    private readonly _bunVersion;
    private readonly _yarnBerryVersion;
    private readonly _options;
    /**
     * The SPDX license of this module. `undefined` if this package is not licensed.
     */
    readonly license?: string;
    /**
     * npm registry (e.g. `https://registry.npmjs.org`). Use `npmRegistryHost` to get just the host name.
     */
    readonly npmRegistryUrl: string;
    /**
     * The npm registry host (e.g. `registry.npmjs.org`).
     */
    readonly npmRegistry: string;
    /**
     * GitHub secret which contains the NPM token to use when publishing packages.
     */
    readonly npmTokenSecret?: string;
    /**
     * Options for npm packages using AWS CodeArtifact.
     * This is required if publishing packages to, or installing scoped packages from AWS CodeArtifact
     *
     * @default - undefined
     */
    readonly codeArtifactOptions?: CodeArtifactOptions;
    /**
     * Options for privately hosted scoped packages
     *
     * @default undefined
     */
    readonly scopedPackagesOptions?: ScopedPackagesOptions[];
    /**
     * npm package access level.
     */
    readonly npmAccess: NpmAccess;
    /**
     * Should provenance statements be generated when package is published.
     */
    readonly npmProvenance: boolean;
    /**
     * The name of the lock file.
     */
    readonly lockFile: string;
    /**
     * The task for installing project dependencies (non-frozen).
     */
    readonly installTask: Task;
    /**
     * The task for installing project dependencies (frozen).
     */
    readonly installCiTask: Task;
    /**
     * The task for deduplicating project dependencies, if configured.
     */
    readonly dedupeTask?: Task;
    /**
     * The package.json file.
     */
    readonly file: JsonFile;
    private readonly scripts;
    private readonly scriptsToBeRemoved;
    private readonly keywords;
    private readonly allowedScripts;
    private readonly bin;
    private readonly engines;
    private readonly peerDependencyOptions;
    private readonly _prev?;
    private _renderedDeps?;
    private readonly _packageManagerExplicit;
    constructor(project: Project, options?: NodePackageOptions);
    /**
     * Adds a `dedupe` task if enabled via `dedupeDeps` or implied by
     * `yarnBerryOptions.dedupePackages`.
     *
     * @returns the dedupe task, or `undefined` if not enabled.
     */
    private maybeAddDedupeTask;
    /**
     * Defines normal dependencies.
     *
     * @param deps Names modules to install. By default, the the dependency will
     * be installed in the next `pnpm projen` run and the version will be recorded
     * in your `package.json` file. You can upgrade manually or using `pnpm
     * add/update`. If you wish to specify a version range use this syntax:
     * `module@^7`.
     */
    addDeps(...deps: string[]): void;
    /**
     * Defines development/test dependencies.
     *
     * @param deps Names modules to install. By default, the the dependency will
     * be installed in the next `pnpm projen` run and the version will be recorded
     * in your `package.json` file. You can upgrade manually or using `pnpm
     * add/update`. If you wish to specify a version range use this syntax:
     * `module@^7`.
     */
    addDevDeps(...deps: string[]): void;
    /**
     * Defines peer dependencies.
     *
     * When adding peer dependencies, a devDependency will also be added on the
     * pinned version of the declared peer. This will ensure that you are testing
     * your code against the minimum version required from your consumers.
     *
     * @param deps Names modules to install. By default, the the dependency will
     * be installed in the next `pnpm projen` run and the version will be recorded
     * in your `package.json` file. You can upgrade manually or using `pnpm
     * add/update`. If you wish to specify a version range use this syntax:
     * `module@^7`.
     */
    addPeerDeps(...deps: string[]): void;
    /**
     * Defines bundled dependencies.
     *
     * Bundled dependencies will be added as normal dependencies as well as to the
     * `bundledDependencies` section of your `package.json`.
     *
     * @param deps Names modules to install. By default, the the dependency will
     * be installed in the next `pnpm projen` run and the version will be recorded
     * in your `package.json` file. You can upgrade manually or using `pnpm
     * add/update`. If you wish to specify a version range use this syntax:
     * `module@^7`.
     */
    addBundledDeps(...deps: string[]): void;
    /**
     * Adds an `engines` requirement to your package.
     * @param engine The engine (e.g. `node`)
     * @param version The semantic version requirement (e.g. `^10`)
     */
    addEngine(engine: string, version: string): void;
    /**
     * Adds keywords to package.json (deduplicated)
     * @param keywords The keywords to add
     */
    addKeywords(...keywords: string[]): void;
    /**
     * Allows the given dependency (package) names to run lifecycle install
     * scripts (`preinstall`, `install`, `postinstall`, `prepare`), in addition
     * to any already allowed via the `allowScripts` option or previous calls.
     *
     * Useful for project types that want to allowlist a package by default
     * while still letting consumers add further packages via `allowScripts`.
     *
     * @param packages The dependency (package) names to allow.
     * @see NodePackageOptions.allowScripts
     */
    addAllowedScripts(...packages: string[]): void;
    /**
     * Removes the given dependency (package) names from the `allowScripts`
     * allowlist, whether they were added via the `allowScripts` option, a
     * project type default, or a previous call to `addAllowedScripts`.
     *
     * @param packages The dependency (package) names to remove.
     * @see NodePackageOptions.allowScripts
     */
    removeAllowedScripts(...packages: string[]): void;
    addBin(bins: Record<string, string>): void;
    /**
     * Add a npm package.json script.
     *
     * @param name The script name
     * @param command The command to execute
     */
    setScript(name: string, command: string): void;
    /**
     * Removes an npm script (always successful).
     *
     * @param name The name of the script.
     */
    removeScript(name: string): void;
    /**
     * Directly set fields in `package.json`.
     * @escape
     * @param name field name
     * @param value field value
     */
    addField(name: string, value: any): void;
    /**
     * Sets the package version.
     * @param version Package version.
     */
    addVersion(version: string): void;
    /**
     * Defines resolutions for dependencies to change the normally resolved
     * version of a dependency to something else.
     *
     * @param resolutions Names resolutions to be added. Specify a version or
     * range with this syntax:
     * `module@^7`
     */
    addPackageResolutions(...resolutions: string[]): void;
    /**
     * Returns the package manager's immutable install command with a frozen lockfile, e.g. `npm ci` or `pnpm ci`.
     *
     * Prefer using `NodePackage.installCiTask`. The raw command string is intended for bootstrapping.
     */
    get installCommand(): string;
    /**
     * Returns the package manager's mutable install command with lockfile update, e.g. `npm install` or `pnpm install`.
     *
     * Prefer using `NodePackage.installTask`. The raw command string is intended for bootstrapping.
     */
    get installAndUpdateLockfileCommand(): string;
    /**
     * Attempt to resolve the currently installed version for a given dependency.
     *
     * @remarks
     * This method will first look through the current project's dependencies.
     * If found and semantically valid (not '*'), that will be used.
     * Otherwise, it will fall back to locating a `package.json` manifest for the dependency
     * through node's internal resolution reading the version from there.
     *
     * @param dependencyName Dependency to resolve for.
     */
    tryResolveDependencyVersion(dependencyName: string): string | undefined;
    synthesize(): void;
    postSynthesize(): void;
    /**
     * Checks whether dependencies need to be installed before dependency
     * resolution.
     *
     * @returns a structured trigger describing the reason, or `undefined` if
     * no install is needed.
     */
    private determineInitialInstallTrigger;
    /**
     * Logs user-facing information about why dependencies are being installed.
     * Emits an info-level summary and debug-level details (reason, diff, resolutions).
     */
    private logInstallTrigger;
    /**
     * The command prefix to use when executing binary commands for this package
     * manager (e.g. `npx`, `pnpm exec`, `yarn`, `bunx`).
     */
    get execCommand(): string;
    /**
     * Returns `true` if we are running within a CI build.
     */
    private get isAutomatedBuild();
    private determineVersion;
    /**
     * Returns `true` if this is a CI release build.
     */
    private get isReleaseBuild();
    private parseNpmOptions;
    private parseScopedPackagesOptions;
    private addCodeArtifactLoginScript;
    private addNodeEngine;
    private renderNpmRegistryPath;
    private renderInstallCommand;
    private processDeps;
    private renderDependencies;
    /**
     * Resolves any deps that do not have a specified version (e.g. `*`) and
     * updates `package.json` if needed. Does not log or install — the caller
     * is responsible for acting on the returned changes.
     *
     * @returns list of human-readable resolution changes, or `undefined` if
     * `package.json` does not exist. An empty array means no changes were made.
     */
    private resolveDepsAndWritePackageJson;
    private renderPackageResolutions;
    /**
     * Renders the native npm `allowScripts` field (`{ "pkg": true }`) from the
     * `allowScripts` allowlist.
     *
     * @see https://docs.npmjs.com/cli/v11/commands/npm-approve-scripts
     */
    private renderNpmAllowScripts;
    /**
     * Renders the native bun `trustedDependencies` field from the
     * `allowScripts` allowlist.
     *
     * @see https://bun.com/docs/pm/lifecycle
     */
    private renderBunTrustedDependencies;
    /**
     * Renders the native yarn berry per-package script allowlist via
     * `dependenciesMeta.<pkg>.built = true`. Combined with the global
     * `enableScripts: false` yarnrc setting (set in `configureYarnBerry`),
     * this allows install scripts to run only for the listed packages.
     *
     * @see https://yarnpkg.com/configuration/manifest#dependenciesMeta.built
     * @see https://yarnpkg.com/features/security#postinstalls
     */
    private renderYarnBerryDependenciesMeta;
    /**
     * Validates and configures the `allowScripts` allowlist for the resolved
     * package manager, throwing a descriptive error for package managers that
     * have no native way to allowlist install scripts per-dependency.
     */
    private configureAllowScripts;
    /**
     * Configures the `PnpmWorkspaceYaml` component, merging `onlyBuiltDependencies`
     * from `allowScripts` and any explicit `pnpmOptions.workspaceYamlOptions`.
     * The merge is resolved lazily (at synthesis time), so calls to
     * `addAllowedScripts`/`removeAllowedScripts` made after this runs are
     * still reflected. The file is only written if it ends up with actual
     * content (see `omitEmpty`), so this is safe to call unconditionally for
     * every pnpm project.
     */
    private configurePnpm;
    private renderPublishConfig;
    private renderKeywords;
    private renderEngines;
    private renderDevEngines;
    private deleteOrphanedLockFiles;
    private autoDiscoverBinaries;
    private renderAuthor;
    private renderBin;
    private renderScripts;
    /**
     * Determines the command to use for projen in package.json scripts.
     *
     * Since `node_modules/.bin` is always on PATH in npm scripts, we can use
     * bare `projen` unless the user has set a custom `projenCommand`.
     */
    private resolveScriptCommand;
    private readPackageJson;
    /**
     * Runs the install or install:ci task. Does not log — the caller is
     * responsible for informing the user before calling this method.
     *
     * @param _trigger the reason for the install, available for subclasses to act on.
     */
    protected installDependencies(_trigger: InstallTrigger): void;
    /**
     * Sets the `packageManager` field in `package.json` for corepack-managed
     * package managers (yarn berry and pnpm).
     */
    private configureCorepack;
    /**
     * Maps the current package manager to a `DevEngineDependency`.
     */
    private packageManagerToDevEngine;
    private configureYarnBerry;
    private checkForConflictingYarnOptions;
    /** See https://yarnpkg.com/getting-started/qa#which-files-should-be-gitignored */
    private configureYarnBerryGitignore;
}
export interface PeerDependencyOptions {
    /**
     * Automatically add a pinned dev dependency.
     * @default true
     */
    readonly pinnedDevDependency?: boolean;
}
/**
 * The node package manager to use.
 */
export declare enum NodePackageManager {
    /**
     * Use `yarn` as the package manager.
     *
     * @deprecated For `yarn` 1.x use `YARN_CLASSIC` for `yarn` >= 2 use `YARN_BERRY`. Currently, `NodePackageManager.YARN` means `YARN_CLASSIC`. In the future, we might repurpose it to mean `YARN_BERRY`.
     */
    YARN = "yarn",
    /**
     * Use `yarn` versions >= 2 as the package manager.
     *
     * @deprecated use YARN_BERRY instead
     */
    YARN2 = "yarn2",
    /**
     * Use `yarn` 1.x as the package manager.
     */
    YARN_CLASSIC = "yarn_classic",
    /**
     * Use `yarn` versions >= 2 as the package manager.
     */
    YARN_BERRY = "yarn_berry",
    /**
     * Use `npm` as the package manager.
     */
    NPM = "npm",
    /**
     * Use `pnpm` as the package manager.
     */
    PNPM = "pnpm",
    /**
     * Use `bun` as the package manager
     */
    BUN = "bun"
}
/**
 * Npm package access level
 */
export declare enum NpmAccess {
    /**
     * Package is public.
     */
    PUBLIC = "public",
    /**
     * Package can only be accessed with credentials.
     */
    RESTRICTED = "restricted"
}
/**
 * Configure Yarn Berry
 */
export interface YarnBerryOptions {
    /**
     * A fully specified version to use for yarn (e.g., x.x.x)
     *
     * @default - 4.13.0
     */
    readonly version?: string;
    /**
     * The yarnrc configuration.
     *
     * @default - a blank Yarn RC file
     */
    readonly yarnRcOptions?: YarnrcOptions;
    /**
     * Should zero-installs be enabled?
     * Learn more at: https://yarnpkg.com/features/caching#zero-installs
     *
     * @default false
     */
    readonly zeroInstalls?: boolean;
    /**
     * Packages to deduplicate when the `dedupe` task runs.
     *
     * This will prevent multiple versions of the same package from being
     * installed in the lock file, if a single version could satisfy all requested
     * version ranges. This will prevent version proliferation and reduce the size
     * of the dependency tree.
     *
     * Setting this implies `dedupeDeps: true` on the project, which will run
     * `yarn dedupe` after every mutating install. Set `dedupeDeps: false`
     * explicitly to disable the task.
     *
     * Supports glob patterns, e.g. `@aws-sdk/*`.
     *
     * @default - all packages are deduplicated
     */
    readonly dedupePackages?: string[];
}
/**
 * Configure pnpm
 */
export interface PnpmOptions {
    /**
     * The `pnpm-workspace.yaml` configuration.
     *
     * @default - a blank pnpm-workspace.yaml file
     */
    readonly workspaceYamlOptions?: PnpmWorkspaceYamlOptions;
}
/**
 * Why a dependency install was triggered during synthesis.
 */
export declare enum InstallReason {
    /** The node_modules directory does not exist. */
    NO_NODE_MODULES = "node_modules is missing",
    /** The package.json file was modified during synthesis. */
    PACKAGE_JSON_CHANGED = "package.json has changed",
    /** Wildcard dependency versions were resolved to concrete ranges. */
    DEPS_RESOLVED = "resolved dependency versions changed"
}
/**
 * Describes why dependencies need to be installed.
 */
export interface InstallTrigger {
    /** The reason for the install. */
    readonly reason: InstallReason;
    /**
     * A unified diff of the package.json changes.
     * Only present when reason is `PACKAGE_JSON_CHANGED`.
     */
    readonly diff?: string[];
    /**
     * Human-readable descriptions of resolved dependency version changes.
     * Only present when reason is `DEPS_RESOLVED`.
     */
    readonly resolutions?: string[];
}
export declare function defaultNpmToken(npmToken: string | undefined, registry: string | undefined): string | undefined;
