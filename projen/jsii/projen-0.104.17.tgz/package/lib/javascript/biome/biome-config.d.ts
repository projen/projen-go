/**
 * The configuration contained in `biome.json` or `biome.jsonc`.
 *
 * @schema BiomeConfiguration
 */
export interface BiomeConfiguration {
    /**
     * The JSON Schema used to validate the configuration and provide editor completion. Biome
     * emits a diagnostic when a `biomejs.dev` schema URL specifies a version that differs from the
     * running CLI version.
     *
     * @schema BiomeConfiguration#$schema
     */
    readonly schema?: string;
    /**
     * The assist configuration.
     *
     * @schema BiomeConfiguration#assist
     */
    readonly assist?: AssistConfiguration;
    /**
     * Configuration specific to CSS.
     *
     * @schema BiomeConfiguration#css
     */
    readonly css?: CssConfiguration;
    /**
     * Extends the current configuration with settings from one or more other Biome configurations.
     * Use `"//"` in a nested configuration to extend the root configuration at any nesting depth.
     * Use an array to extend configurations by relative path or installed package specifier.
     *
     * Biome merges configurations from left to right. Later configurations take precedence for
     * single-value options, list entries are combined, and the current file is applied last.
     *
     * @schema BiomeConfiguration#extends
     */
    readonly extends?: any;
    /**
     * Configures which files Biome can discover and process.
     *
     * @schema BiomeConfiguration#files
     */
    readonly files?: FilesConfiguration;
    /**
     * Configures formatting for selected files.
     *
     * @schema BiomeConfiguration#formatter
     */
    readonly formatter?: FormatterConfiguration;
    /**
     * Configuration specific to GraphQL.
     *
     * @schema BiomeConfiguration#graphql
     */
    readonly graphql?: GraphqlConfiguration;
    /**
     * Configuration specific to GritQL.
     *
     * @schema BiomeConfiguration#grit
     */
    readonly grit?: GritConfiguration;
    /**
     * Configuration specific to HTML.
     *
     * @schema BiomeConfiguration#html
     */
    readonly html?: HtmlConfiguration;
    /**
     * Configuration specific to JavaScript.
     *
     * @schema BiomeConfiguration#javascript
     */
    readonly javascript?: JsConfiguration;
    /**
     * Configuration specific to JSON.
     *
     * @schema BiomeConfiguration#json
     */
    readonly json?: JsonConfiguration;
    /**
     * The linter configuration.
     *
     * @schema BiomeConfiguration#linter
     */
    readonly linter?: LinterConfiguration;
    /**
     * Configuration specific to Markdown.
     *
     * @schema BiomeConfiguration#markdown
     */
    readonly markdown?: MarkdownConfiguration;
    /**
     * Configures settings for files selected by each override. When multiple overrides configure
     * the same single-value setting, the last matching override takes precedence.
     *
     * @schema BiomeConfiguration#overrides
     */
    readonly overrides?: OverridePattern[];
    /**
     * A list of GritQL plugins to load.
     *
     * @schema BiomeConfiguration#plugins
     */
    readonly plugins?: any[];
    /**
     * Marks whether this file is the root configuration for a Biome project. The root configuration
     * establishes the project's base settings, while `false` marks a configuration found inside the
     * project as nested rather than a second project root.
     *
     * Defaults to `true`. Biome implicitly treats `root` as `false` when a nested configuration uses
     * `"extends": "//"`. All other nested configurations must explicitly set `root` to `false`.
     *
     * @default true`. Biome implicitly treats `root` as `false` when a nested configuration uses
     * @schema BiomeConfiguration#root
     */
    readonly root?: boolean;
    /**
     * Configures how Biome recognizes Tailwind class strings.
     *
     * @schema BiomeConfiguration#tailwind
     */
    readonly tailwind?: TailwindConfiguration;
    /**
     * The version control integration configuration.
     *
     * @schema BiomeConfiguration#vcs
     */
    readonly vcs?: VcsConfiguration;
    /**
     * Configuration specific to YAML.
     *
     * @schema BiomeConfiguration#yaml
     */
    readonly yaml?: YamlConfiguration;
}
/**
 * Converts an object of type 'BiomeConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_BiomeConfiguration(obj: BiomeConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema AssistConfiguration
 */
export interface AssistConfiguration {
    /**
     * The assist-action configuration.
     *
     * @schema AssistConfiguration#actions
     */
    readonly actions?: Actions;
    /**
     * Enables configured assist actions in the CLI and editor integrations. Defaults to `true`.
     *
     * @default true`.
     * @schema AssistConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * A list of glob patterns selecting files on which assist actions can run. If omitted, all files
     * selected by `files.includes` remain eligible for assist actions. An empty list selects no
     * files. This option can only narrow the files selected by `files.includes`.
     *
     * @schema AssistConfiguration#includes
     */
    readonly includes?: string[];
}
/**
 * Converts an object of type 'AssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_AssistConfiguration(obj: AssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to CSS and languages that extend it.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema CssConfiguration
 */
export interface CssConfiguration {
    /**
     * CSS assist options.
     *
     * @schema CssConfiguration#assist
     */
    readonly assist?: CssAssistConfiguration;
    /**
     * CSS formatter options.
     *
     * @schema CssConfiguration#formatter
     */
    readonly formatter?: CssFormatterConfiguration;
    /**
     * Reserved for future CSS analyzer support. This option currently has no effect.
     *
     * @schema CssConfiguration#globals
     */
    readonly globals?: string[];
    /**
     * CSS linter options.
     *
     * @schema CssConfiguration#linter
     */
    readonly linter?: CssLinterConfiguration;
    /**
     * CSS parsing options.
     *
     * @schema CssConfiguration#parser
     */
    readonly parser?: CssParserConfiguration;
}
/**
 * Converts an object of type 'CssConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssConfiguration(obj: CssConfiguration | undefined): Record<string, any> | undefined;
/**
 * The file handling configuration.
 *
 * @schema FilesConfiguration
 */
export interface FilesConfiguration {
    /**
     * **Deprecated:** Please use _force-ignore syntax_ in `files.includes`
     * instead: <https://biomejs.dev/reference/configuration/#filesincludes>
     *
     * File or directory names that the scanner ignores unconditionally while crawling. Each value
     * matches a complete path component, not a glob. Ignored files are not added to the module graph,
     * so types are not inferred from them.
     *
     * @schema FilesConfiguration#experimentalScannerIgnores
     */
    readonly experimentalScannerIgnores?: string[];
    /**
     * Prevents Biome from emitting diagnostics for unrecognized file types. Defaults to `false`.
     *
     * @default false`.
     * @schema FilesConfiguration#ignoreUnknown
     */
    readonly ignoreUnknown?: boolean;
    /**
     * A list of glob patterns selecting which files and directories Biome can process. If omitted,
     * this option does not further restrict the supported files Biome can process. An empty list
     * selects no files. Biome ignores files under `node_modules` even when they match a pattern.
     *
     * The scanner uses these patterns and, when enabled, VCS ignore files while discovering nested
     * configuration and ignore files. When enabled rules use the `project` or `types` domains, it
     * also indexes source files and project dependencies. It may still discover required metadata or
     * index excluded source files needed for analysis. A pattern beginning with `!!` prevents the
     * scanner from indexing matching paths. Patterns are evaluated in order, and a pattern beginning
     * with `!` excludes matches.
     *
     * @schema FilesConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * The maximum source-file size in bytes. Biome skips larger files and emits a warning
     * diagnostic. Defaults to `1 MiB`.
     *
     * @default 1 MiB`.
     * @schema FilesConfiguration#maxSize
     */
    readonly maxSize?: number;
}
/**
 * Converts an object of type 'FilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_FilesConfiguration(obj: FilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * Configures formatting for selected files.
 *
 * @schema FormatterConfiguration
 */
export interface FormatterConfiguration {
    /**
     * The attribute position style in HTML-like languages. Defaults to `auto`.
     *
     * @default auto`.
     * @schema FormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Controls the placement of the closing bracket for multiline HTML and JSX opening tags. Biome
     * places the bracket at the end of the last attribute line when enabled and on its own line when
     * disabled. This also affects self-closing HTML elements, but self-closing JSX elements are
     * unaffected. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Controls spaces inside braces in supported single-line structures. The affected structures
     * vary by language. Defaults to `true`.
     *
     * @default true`.
     * @schema FormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported delimiters when their content fits on one line.
     * It doesn't add spaces before opening delimiters or inside empty delimiters.
     *
     * The affected delimiters vary by language. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Enables or disables the formatter. Defaults to `true`.
     *
     * @default true`.
     * @schema FormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Controls whether arrays and objects are formatted on one line or multiple lines.
     *
     * `auto` formats objects on multiple lines if the first property has a newline, and arrays on
     * one line if they fit.
     *
     * `always` formats arrays and objects on multiple lines.
     *
     * `never` formats arrays and objects on one line if they fit.
     *
     * Defaults to `auto`.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @default auto`.
     * @schema FormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * Allows formatting files that contain syntax errors when set to `true`. Defaults to `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#formatWithErrors
     */
    readonly formatWithErrors?: boolean;
    /**
     * A list of glob patterns selecting files to format. If omitted, all files selected by
     * `files.includes` remain eligible for formatting. An empty list selects no files. This option
     * can only narrow the files selected by `files.includes`.
     *
     * @schema FormatterConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * Uses tabs or spaces for indentation. Defaults to `tab`.
     *
     * @default tab`.
     * @schema FormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * Sets the indentation width. With space indentation, this is the number of spaces emitted per
     * indentation level. With tab indentation, Biome emits one tab per level and uses this value as
     * the tab's display width when calculating line length. Accepted values are `0` through `24`.
     * Defaults to `2`.
     *
     * @default 2`.
     * @schema FormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * Selects the line ending. `auto` uses the platform convention. Defaults to `lf`.
     *
     * @default lf`.
     * @schema FormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * Sets the preferred maximum line width used when deciding where to wrap code. Some content,
     * such as long unbreakable strings, may still exceed this width. Accepted values are `1` through
     * `320`. Defaults to `80`.
     *
     * @default 80`.
     * @schema FormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Whether to add a trailing newline at the end of the file. Defaults to `true`. Disabling
     * this option can cause compatibility problems with other tools.
     *
     * @default true`. Disabling
     * @schema FormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
    /**
     * Controls whether Biome loads formatter settings from an `.editorconfig` file. Biome reads
     * `indent_style`, `indent_size`, `end_of_line`, and `insert_final_newline`. Settings in
     * `biome.json` or `biome.jsonc` take precedence. Biome loads only one `.editorconfig`. Nested
     * cascading configurations and the EditorConfig `root` property are not supported. Defaults to
     * `false`.
     *
     * @default false`.
     * @schema FormatterConfiguration#useEditorconfig
     */
    readonly useEditorconfig?: boolean;
}
/**
 * Converts an object of type 'FormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_FormatterConfiguration(obj: FormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to GraphQL files.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema GraphqlConfiguration
 */
export interface GraphqlConfiguration {
    /**
     * GraphQL assist options.
     *
     * @schema GraphqlConfiguration#assist
     */
    readonly assist?: GraphqlAssistConfiguration;
    /**
     * GraphQL formatter options.
     *
     * @schema GraphqlConfiguration#formatter
     */
    readonly formatter?: GraphqlFormatterConfiguration;
    /**
     * GraphQL linter options.
     *
     * @schema GraphqlConfiguration#linter
     */
    readonly linter?: GraphqlLinterConfiguration;
}
/**
 * Converts an object of type 'GraphqlConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlConfiguration(obj: GraphqlConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to GritQL files.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema GritConfiguration
 */
export interface GritConfiguration {
    /**
     * GritQL assist options.
     *
     * @schema GritConfiguration#assist
     */
    readonly assist?: GritAssistConfiguration;
    /**
     * GritQL formatter options.
     *
     * @schema GritConfiguration#formatter
     */
    readonly formatter?: GritFormatterConfiguration;
    /**
     * GritQL linter options.
     *
     * @schema GritConfiguration#linter
     */
    readonly linter?: GritLinterConfiguration;
}
/**
 * Converts an object of type 'GritConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritConfiguration(obj: GritConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to HTML and languages that extend it.
 *
 * Full HTML support and the HTML formatter are experimental. Biome aims to minimize breaking
 * changes, but bug fixes and new features may change formatting output or diagnostics.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema HtmlConfiguration
 */
export interface HtmlConfiguration {
    /**
     * HTML assist options.
     *
     * @schema HtmlConfiguration#assist
     */
    readonly assist?: HtmlAssistConfiguration;
    /**
     * Enables Biome's experimental full support for `.html`, `.vue`, `.svelte`, and `.astro` files.
     * In this mode, Biome parses the complete document and can analyze or format its markup and
     * supported embedded languages.
     *
     * When disabled, `.vue`, `.svelte`, and `.astro` files use legacy handling, which extracts their
     * JavaScript or TypeScript portions and leaves the rest unchanged. This option selects how
     * these files are processed. It does not enable the HTML formatter. Set
     * `html.formatter.enabled` to `true` to format complete HTML, Vue, Svelte, and Astro files.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema HtmlConfiguration#experimentalFullSupportEnabled
     */
    readonly experimentalFullSupportEnabled?: boolean;
    /**
     * HTML formatter options.
     *
     * @schema HtmlConfiguration#formatter
     */
    readonly formatter?: HtmlFormatterConfiguration;
    /**
     * HTML linter options.
     *
     * @schema HtmlConfiguration#linter
     */
    readonly linter?: HtmlLinterConfiguration;
    /**
     * HTML parsing options.
     *
     * @schema HtmlConfiguration#parser
     */
    readonly parser?: HtmlParserConfiguration;
}
/**
 * Converts an object of type 'HtmlConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlConfiguration(obj: HtmlConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to JavaScript, TypeScript, JSX, TSX, and supported languages that embed
 * JavaScript.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema JsConfiguration
 */
export interface JsConfiguration {
    /**
     * JavaScript assist options.
     *
     * @schema JsConfiguration#assist
     */
    readonly assist?: JsAssistConfiguration;
    /**
     * Enables experimental parsing, formatting, linting, diagnostics, and fixes for CSS and
     * GraphQL snippets embedded in JavaScript and TypeScript template literals.
     *
     * Biome recognizes CSS in `css` and `styled` templates and GraphQL in `gql` and `graphql`
     * templates or calls. Templates containing interpolations are not currently supported.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema JsConfiguration#experimentalEmbeddedSnippetsEnabled
     */
    readonly experimentalEmbeddedSnippetsEnabled?: boolean;
    /**
     * JavaScript formatter options.
     *
     * @schema JsConfiguration#formatter
     */
    readonly formatter?: JsFormatterConfiguration;
    /**
     * A list of additional names that Biome's JavaScript linter treats as predefined global
     * bindings.
     *
     * Use this for globals supplied by a runtime, framework, or external script that are not
     * declared in the source file.
     *
     * @schema JsConfiguration#globals
     */
    readonly globals?: string[];
    /**
     * Configures how the analyzer accounts for imports used by JSX. This option does not transform
     * JSX or select a runtime for a build tool. Defaults to `transparent`.
     *
     * @default transparent`.
     * @schema JsConfiguration#jsxRuntime
     */
    readonly jsxRuntime?: JsxRuntime;
    /**
     * JavaScript linter options.
     *
     * @schema JsConfiguration#linter
     */
    readonly linter?: JsLinterConfiguration;
    /**
     * JavaScript parser options.
     *
     * @schema JsConfiguration#parser
     */
    readonly parser?: JsParserConfiguration;
    /**
     * JavaScript module and dependency resolver options.
     *
     * @schema JsConfiguration#resolver
     */
    readonly resolver?: JsResolverConfiguration;
}
/**
 * Converts an object of type 'JsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsConfiguration(obj: JsConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to JSON, JSONC, and recognized JSON-based configuration files.
 *
 * Language-specific settings take precedence over corresponding global settings. Global settings
 * apply when their language-specific counterparts are omitted, unless stated otherwise.
 *
 * @schema JsonConfiguration
 */
export interface JsonConfiguration {
    /**
     * Assist options
     *
     * @schema JsonConfiguration#assist
     */
    readonly assist?: JsonAssistConfiguration;
    /**
     * Formatting options
     *
     * @schema JsonConfiguration#formatter
     */
    readonly formatter?: JsonFormatterConfiguration;
    /**
     * Linting options
     *
     * @schema JsonConfiguration#linter
     */
    readonly linter?: JsonLinterConfiguration;
    /**
     * Parsing options
     *
     * @schema JsonConfiguration#parser
     */
    readonly parser?: JsonParserConfiguration;
}
/**
 * Converts an object of type 'JsonConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonConfiguration(obj: JsonConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema LinterConfiguration
 */
export interface LinterConfiguration {
    /**
     * Configures rules associated with a framework, library, project-wide analysis, or type
     * analysis. Keys are domain names and values are `all`, `recommended`, or `none`.
     * Enabling rules from the `project` or `types` domains activates project and dependency
     * scanning. The `types` domain also enables type-aware resolution.
     *
     * @schema LinterConfiguration#domains
     */
    readonly domains?: RuleDomains;
    /**
     * Enables or disables the linter. Defaults to `true`.
     *
     * @default true`.
     * @schema LinterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * A list of glob patterns selecting files to lint. If omitted, all files selected by
     * `files.includes` remain eligible for linting. An empty list selects no files. This option can
     * only narrow the files selected by `files.includes`.
     *
     * @schema LinterConfiguration#includes
     */
    readonly includes?: string[];
    /**
     * The lint-rule configuration.
     *
     * @schema LinterConfiguration#rules
     */
    readonly rules?: Rules;
}
/**
 * Converts an object of type 'LinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_LinterConfiguration(obj: LinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to Markdown files
 *
 * @schema MarkdownConfiguration
 */
export interface MarkdownConfiguration {
    /**
     * Runs the linter and assist actions on the code inside fenced code blocks, frontmatter, and
     * HTML blocks, with the rules and actions of the code's language. Defaults to `false`.
     *
     * @default false`.
     * @schema MarkdownConfiguration#analyzeEmbeds
     */
    readonly analyzeEmbeds?: boolean;
    /**
     * Formatter options
     *
     * @schema MarkdownConfiguration#formatter
     */
    readonly formatter?: MarkdownFormatterConfiguration;
    /**
     * Linter options
     *
     * @schema MarkdownConfiguration#linter
     */
    readonly linter?: MarkdownLinterConfiguration;
    /**
     * Parsing options
     *
     * @schema MarkdownConfiguration#parser
     */
    readonly parser?: MarkdownParserConfiguration;
}
/**
 * Converts an object of type 'MarkdownConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_MarkdownConfiguration(obj: MarkdownConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverridePattern
 */
export interface OverridePattern {
    /**
     * Assist settings for matched files.
     *
     * @schema OverridePattern#assist
     */
    readonly assist?: OverrideAssistConfiguration;
    /**
     * CSS-specific settings for matched files.
     *
     * @schema OverridePattern#css
     */
    readonly css?: CssConfiguration;
    /**
     * File-handling settings for matched files.
     *
     * @schema OverridePattern#files
     */
    readonly files?: OverrideFilesConfiguration;
    /**
     * Formatter settings for matched files.
     *
     * @schema OverridePattern#formatter
     */
    readonly formatter?: OverrideFormatterConfiguration;
    /**
     * GraphQL-specific settings for matched files.
     *
     * @schema OverridePattern#graphql
     */
    readonly graphql?: GraphqlConfiguration;
    /**
     * GritQL-specific settings for matched files.
     *
     * @schema OverridePattern#grit
     */
    readonly grit?: GritConfiguration;
    /**
     * HTML-specific settings for matched files.
     *
     * @schema OverridePattern#html
     */
    readonly html?: HtmlConfiguration;
    /**
     * A list of glob patterns selecting the files to which this override applies. If omitted, the
     * override applies to every file. An empty list applies to no files.
     *
     * @schema OverridePattern#includes
     */
    readonly includes?: string[];
    /**
     * JavaScript-specific settings for matched files.
     *
     * @schema OverridePattern#javascript
     */
    readonly javascript?: JsConfiguration;
    /**
     * JSON-specific settings for matched files.
     *
     * @schema OverridePattern#json
     */
    readonly json?: JsonConfiguration;
    /**
     * Linter settings for matched files.
     *
     * @schema OverridePattern#linter
     */
    readonly linter?: OverrideLinterConfiguration;
    /**
     * Specific configuration for the Markdown language
     *
     * @schema OverridePattern#markdown
     */
    readonly markdown?: MarkdownConfiguration;
    /**
     * Additional plugins for matched files.
     *
     * @schema OverridePattern#plugins
     */
    readonly plugins?: any[];
    /**
     * Specific configuration for the YAML language
     *
     * @schema OverridePattern#yaml
     */
    readonly yaml?: YamlConfiguration;
}
/**
 * Converts an object of type 'OverridePattern' to JSON representation.
 * @internal
 */
export declare function toJson_OverridePattern(obj: OverridePattern | undefined): Record<string, any> | undefined;
/**
 * Tells Biome where your code lists Tailwind CSS classes, so the Tailwind
 * lint rules know which strings to check.
 *
 * @schema TailwindConfiguration
 */
export interface TailwindConfiguration {
    /**
     * Attributes whose values are Tailwind classes, such as `class` in
     * `<div class="px-2 py-2">`.
     *
     * Defaults to `class` and `className`. In HTML, they are case-insensitive.
     *
     * @default class` and `className`. In HTML, they are case-insensitive.
     * @schema TailwindConfiguration#attributes
     */
    readonly attributes?: string[];
    /**
     * Functions that combine Tailwind classes, such as `clsx` and `cn`.
     *
     * Biome checks every string passed to these functions, like both strings
     * in `cn("px-2", "py-2")`. When an object is passed, Biome checks its
     * keys: in `cn({ "px-2": isActive })`, it checks `"px-2"`.
     *
     * Properties of these functions are checked too, so listing `tw` also
     * covers `` tw.div`px-2` `` and `tw.div("px-2")`.
     *
     * Defaults to `clsx`, `tw`, `twMerge`, `twJoin`, `cn`, `cc`, `cnb`, and
     * `ctl`.
     *
     * @default clsx`, `tw`, `twMerge`, `twJoin`, `cn`, `cc`, `cnb`, and
     * @schema TailwindConfiguration#mergeFunctions
     */
    readonly mergeFunctions?: string[];
    /**
     * The CSS file that holds your Tailwind CSS configuration, such as
     * `"./src/app.css"`. A relative path starts from the folder of the Biome
     * configuration file.
     *
     * Biome reads the `@theme`, `@utility`, and `@custom-variant` rules in
     * this file and in the files it imports with `@import`, so that the
     * Tailwind rules know your theme values, utilities, and variants.
     *
     * To read the file, Biome scans your project when a Tailwind rule is
     * enabled. Setting this option also turns on `css.parser.tailwindDirectives`,
     * unless you set that option yourself.
     *
     * @schema TailwindConfiguration#stylesheet
     */
    readonly stylesheet?: string;
    /**
     * Functions that describe a component's styles with an object, such as
     * `cva` and `tv`.
     *
     * Biome checks every string passed directly to these functions. In an
     * object passed to them, Biome checks the classes under these properties:
     *
     * - `base`, `class`, and `className`: classes that always apply.
     * - `variants`: classes for each version of the component, such as each
     * button size.
     * - `slots`: classes for each part of the component, such as its icon.
     * - `compoundVariants` and `compoundSlots`: only the `class` and
     * `className` of each entry.
     *
     * Other properties, such as `defaultVariants`, hold names rather than
     * classes, so Biome skips them. For example, Biome checks `"rounded"`,
     * `"px-2"`, and `"px-4"` here, but not `"small"`:
     *
     * ```js
     * cva("rounded", {
     * variants: {
     * size: { small: "px-2", large: "px-4" },
     * },
     * defaultVariants: { size: "small" },
     * });
     * ```
     *
     * Defaults to `cva` and `tv`.
     *
     * @default cva` and `tv`.
     * @schema TailwindConfiguration#variantFunctions
     */
    readonly variantFunctions?: string[];
}
/**
 * Converts an object of type 'TailwindConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_TailwindConfiguration(obj: TailwindConfiguration | undefined): Record<string, any> | undefined;
/**
 * Configures how Biome integrates with a version control system.
 *
 * @schema VcsConfiguration
 */
export interface VcsConfiguration {
    /**
     * Selects the version-control client. Currently, only `git` is supported.
     *
     * @schema VcsConfiguration#clientKind
     */
    readonly clientKind?: VcsClientKind;
    /**
     * Sets the base branch used by `--changed` when `--since` is not provided. If neither this option
     * nor `--since` is set, commands using `--changed` fail because Biome cannot determine the
     * comparison base.
     *
     * @schema VcsConfiguration#defaultBranch
     */
    readonly defaultBranch?: string;
    /**
     * Enables or disables version-control integration. Defaults to `false`. Enabling integration
     * requires `vcs.clientKind` to be set.
     *
     * @default false`. Enabling integration
     * @schema VcsConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Sets the directory where Biome looks for version-control files. A relative value is resolved
     * from the directory containing the current configuration file, while an absolute path is used
     * directly.
     *
     * Defaults to the directory containing `biome.json` or `biome.jsonc`. If no configuration is
     * found, Biome uses the current working directory.
     *
     * If neither directory is available, Biome disables version control integration and emits a
     * diagnostic.
     *
     * @default the directory containing `biome.json` or `biome.jsonc`. If no configuration is
     * @schema VcsConfiguration#root
     */
    readonly root?: string;
    /**
     * Controls whether Biome applies patterns from `.gitignore`, Git's local `.git/info/exclude`,
     * and supported `.ignore` files, including nested ignore files. Patterns in the root ignore file
     * are resolved from `vcs.root`. Patterns in nested ignore files are resolved from the directory
     * containing that file. Defaults to `false`.
     *
     * @default false`.
     * @schema VcsConfiguration#useIgnoreFile
     */
    readonly useIgnoreFile?: boolean;
}
/**
 * Converts an object of type 'VcsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_VcsConfiguration(obj: VcsConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options applied to Yaml files
 *
 * @schema YamlConfiguration
 */
export interface YamlConfiguration {
    /**
     * Formatter options
     *
     * @schema YamlConfiguration#formatter
     */
    readonly formatter?: YamlFormatterConfiguration;
    /**
     * @schema YamlConfiguration#linter
     */
    readonly linter?: YamlLinterConfiguration;
}
/**
 * Converts an object of type 'YamlConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_YamlConfiguration(obj: YamlConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema Actions
 */
export interface Actions {
    /**
     * Selects the baseline set of assist actions. `recommended` enables Biome's
     * recommended actions, `all` enables all actions, and `none` starts with no actions
     * enabled. Group presets and explicit action settings override this preset.
     * Defaults to `recommended`.
     *
     * @default recommended`.
     * @schema Actions#preset
     */
    readonly preset?: PresetConfig;
    /**
     * Enables or disables Biome's recommended assist actions across all action groups.
     * Defaults to `true`.
     *
     * @default true`.
     * @schema Actions#recommended
     */
    readonly recommended?: boolean;
    /**
     * Configures source-level actions such as organizing imports and sorting declarations. These actions are exposed through editor source actions and through CLI checking and application.
     *
     * @schema Actions#source
     */
    readonly source?: Source;
}
/**
 * Converts an object of type 'Actions' to JSON representation.
 * @internal
 */
export declare function toJson_Actions(obj: Actions | undefined): Record<string, any> | undefined;
/**
 * Options that change how CSS assist behaves.
 *
 * @schema CssAssistConfiguration
 */
export interface CssAssistConfiguration {
    /**
     * Enables or disables assist actions for CSS.
     *
     * @schema CssAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CssAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssAssistConfiguration(obj: CssAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS formatter behaves.
 *
 * @schema CssFormatterConfiguration
 */
export interface CssFormatterConfiguration {
    /**
     * Controls spaces inside CSS parentheses and square brackets when their content fits on one
     * line. When enabled, `rgb(0, 0, 0)` becomes `rgb( 0, 0, 0 )` and `[data-attr]` becomes
     * `[ data-attr ]`. Empty delimiters are unchanged.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema CssFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Enables or disables the formatter for CSS and languages that extend it.
     *
     * @schema CssFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to CSS and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema CssFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to CSS and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema CssFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to CSS and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema CssFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width for CSS and languages that extend it. If unset, inherits
     * the global line width.
     *
     * @schema CssFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Selects the preferred quote style for CSS strings. Biome may use the alternate quote when
     * that avoids additional escaping. Quotes in `@charset` rules are currently preserved.
     * Defaults to `double`.
     *
     * @default double`.
     * @schema CssFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema CssFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'CssFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssFormatterConfiguration(obj: CssFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS linter behaves.
 *
 * @schema CssLinterConfiguration
 */
export interface CssLinterConfiguration {
    /**
     * Enables or disables the linter for CSS.
     *
     * @schema CssLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CssLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssLinterConfiguration(obj: CssLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the CSS parser behaves.
 *
 * @schema CssParserConfiguration
 */
export interface CssParserConfiguration {
    /**
     * Enables `//` line comments in plain CSS. Standard CSS treats `//` as delimiter characters
     * rather than as a comment, and SCSS accepts `//` comments independently of this option.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema CssParserConfiguration#allowWrongLineComments
     */
    readonly allowWrongLineComments?: boolean;
    /**
     * Enables CSS Modules-specific syntax such as `:local`, `:global`, `composes`, and `@value`.
     * When unset, Biome enables this syntax automatically for files whose names end in
     * `.module.css` or `.module.scss; otherwise, it defaults to `false`. Enable it explicitly when CSS Module files
     * use another naming convention.
     *
     * @schema CssParserConfiguration#cssModules
     */
    readonly cssModules?: boolean;
    /**
     * Enables parsing Tailwind CSS 4.0 directives and functions, including `@theme`, `@utility`,
     * `@variant`, `@source`, and `@apply`. Defaults to `false`.
     *
     * @default false`.
     * @schema CssParserConfiguration#tailwindDirectives
     */
    readonly tailwindDirectives?: boolean;
}
/**
 * Converts an object of type 'CssParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CssParserConfiguration(obj: CssParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * Controls attribute placement in HTML-like languages.
 *
 * @schema AttributePosition
 */
export declare enum AttributePosition {
    /** Places attributes automatically and wraps them when needed. (auto) */
    AUTO = "auto",
    /** Places each attribute on its own line when an element has multiple attributes. (multiline) */
    MULTILINE = "multiline"
}
/**
 * @schema Expand
 */
export declare enum Expand {
    /** Objects are expanded when the first property has a leading newline. Arrays remain on one
  line if they fit. (auto) */
    AUTO = "auto",
    /** Objects and arrays are always expanded. (always) */
    ALWAYS = "always",
    /** Objects and arrays remain on one line if they fit. (never) */
    NEVER = "never"
}
/**
 * @schema IndentStyle
 */
export declare enum IndentStyle {
    /** Uses tabs for indentation. (tab) */
    TAB = "tab",
    /** Uses spaces for indentation. (space) */
    SPACE = "space"
}
/**
 * @schema LineEnding
 */
export declare enum LineEnding {
    /** Line Feed only (\n), common on Linux and macOS as well as inside git repos (lf) */
    LF = "lf",
    /** Carriage Return + Line Feed characters (\r\n), common on Windows (crlf) */
    CRLF = "crlf",
    /** Carriage Return character only (\r), used very rarely (cr) */
    CR = "cr",
    /** Automatically use CRLF on Windows and LF on other platforms (auto) */
    AUTO = "auto"
}
/**
 * Options that change how GraphQL assist behaves.
 *
 * @schema GraphqlAssistConfiguration
 */
export interface GraphqlAssistConfiguration {
    /**
     * Enables or disables assist actions for GraphQL. Defaults to `false`.
     *
     * @default false`.
     * @schema GraphqlAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GraphqlAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlAssistConfiguration(obj: GraphqlAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GraphQL formatter behaves.
 *
 * @schema GraphqlFormatterConfiguration
 */
export interface GraphqlFormatterConfiguration {
    /**
     * Controls spaces inside the braces of single-line GraphQL object values. Biome formats
     * `{name: "Biome"}` when disabled and `{ name: "Biome" }` when enabled. If unset, inherits the
     * global bracket spacing setting.
     *
     * @schema GraphqlFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Enables or disables the formatter for GraphQL.
     *
     * @schema GraphqlFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to GraphQL files. If unset, inherits the global indentation style.
     *
     * @schema GraphqlFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to GraphQL files. If unset, inherits the global indentation
     * width.
     *
     * @schema GraphqlFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to GraphQL files. If unset, inherits the global line ending.
     *
     * @schema GraphqlFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width for GraphQL files. If unset, inherits the global line
     * width.
     *
     * @schema GraphqlFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Reserved for future formatter support. The current formatter preserves standard
     * double-quoted GraphQL strings and does not use this setting.
     *
     * @schema GraphqlFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema GraphqlFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'GraphqlFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlFormatterConfiguration(obj: GraphqlFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GraphQL linter behaves.
 *
 * @schema GraphqlLinterConfiguration
 */
export interface GraphqlLinterConfiguration {
    /**
     * Enables or disables the linter for GraphQL.
     *
     * @schema GraphqlLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GraphqlLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GraphqlLinterConfiguration(obj: GraphqlLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how GritQL assist behaves.
 *
 * @schema GritAssistConfiguration
 */
export interface GritAssistConfiguration {
    /**
     * Enables or disables assist actions for GritQL.
     *
     * @schema GritAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GritAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritAssistConfiguration(obj: GritAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GritQL formatter behaves.
 *
 * @schema GritFormatterConfiguration
 */
export interface GritFormatterConfiguration {
    /**
     * Enables or disables the formatter for GritQL.
     *
     * @schema GritFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The indent style applied to GritQL files. If unset, inherits the global indentation style.
     *
     * @schema GritFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to GritQL files. If unset, inherits the global indentation
     * width.
     *
     * @schema GritFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to GritQL files. If unset, inherits the global line ending.
     *
     * @schema GritFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width for GritQL files. If unset, inherits the global line width.
     *
     * @schema GritFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema GritFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'GritFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritFormatterConfiguration(obj: GritFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the GritQL linter behaves.
 *
 * @schema GritLinterConfiguration
 */
export interface GritLinterConfiguration {
    /**
     * Enables or disables the linter for GritQL.
     *
     * @schema GritLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'GritLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_GritLinterConfiguration(obj: GritLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how HTML assist behaves.
 *
 * @schema HtmlAssistConfiguration
 */
export interface HtmlAssistConfiguration {
    /**
     * Enables or disables assist actions for HTML and languages that extend it.
     *
     * @schema HtmlAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'HtmlAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlAssistConfiguration(obj: HtmlAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML formatter behaves.
 *
 * @schema HtmlFormatterConfiguration
 */
export interface HtmlFormatterConfiguration {
    /**
     * The attribute position style in HTML elements. If unset, inherits the global attribute
     * position setting.
     *
     * @schema HtmlFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Controls the placement of the closing bracket for multiline HTML opening tags. Biome places
     * the bracket at the end of the last attribute line when enabled and on its own line after the
     * last attribute when disabled. This option also affects self-closing HTML elements. If unset,
     * inherits the global `bracketSameLine` setting.
     *
     * @schema HtmlFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Enables or disables the formatter for HTML and languages that extend it. The formatter is
     * experimental and disabled by default. Formatting complete HTML, Vue, Svelte, and Astro files
     * requires `html.experimentalFullSupportEnabled` to be `true`.
     *
     * @schema HtmlFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Controls whether the content of `<script>` and `<style>` tags is indented by one level in
     * HTML, Vue, Svelte, and Astro files. Defaults to `false`.
     *
     * @default false`.
     * @schema HtmlFormatterConfiguration#indentScriptAndStyle
     */
    readonly indentScriptAndStyle?: boolean;
    /**
     * The indent style applied to HTML and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema HtmlFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to HTML and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema HtmlFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to HTML and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema HtmlFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width for HTML and languages that extend it. If unset, inherits
     * the global line width.
     *
     * @schema HtmlFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Controls whether void elements are self-closed. Defaults to `never`.
     *
     * @default never`.
     * @schema HtmlFormatterConfiguration#selfCloseVoidElements
     */
    readonly selfCloseVoidElements?: SelfCloseVoidElements;
    /**
     * Whether to add a trailing newline at the end of the file. Unlike other language-specific
     * trailing newline settings, this option defaults to `true` instead of inheriting the global
     * setting.
     *
     * @schema HtmlFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
    /**
     * Controls how the formatter treats whitespace around text and child elements in HTML, Vue,
     * Svelte, and Astro markup. The `ignore` setting should be used only when whitespace cannot
     * affect rendered output. Defaults to `css`.
     *
     * @default css`.
     * @schema HtmlFormatterConfiguration#whitespaceSensitivity
     */
    readonly whitespaceSensitivity?: WhitespaceSensitivity;
}
/**
 * Converts an object of type 'HtmlFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlFormatterConfiguration(obj: HtmlFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML linter behaves.
 *
 * @schema HtmlLinterConfiguration
 */
export interface HtmlLinterConfiguration {
    /**
     * Enables or disables the linter for HTML and languages that extend it.
     *
     * @schema HtmlLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'HtmlLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlLinterConfiguration(obj: HtmlLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the HTML parser behaves.
 *
 * @schema HtmlParserConfiguration
 */
export interface HtmlParserConfiguration {
    /**
     * Enables double-curly interpolation expressions such as `{{ expression }}` in `.html` files.
     * Defaults to `false`.
     *
     * @default false`.
     * @schema HtmlParserConfiguration#interpolation
     */
    readonly interpolation?: boolean;
    /**
     * Enables parsing Vue syntax (`v-if`, `v-bind`, etc.) in `.html` files. Enabling this option
     * also enables `interpolation` implicitly.
     *
     * Biome will already automatically enable Vue parsing in `.vue` files, so you probably don't need
     * to enable this option. This only affects `.html` files, and does not change how `.vue`, `.svelte`,
     * or `.astro` files are parsed. Defaults to `false`.
     *
     * @default false`.
     * @schema HtmlParserConfiguration#vue
     */
    readonly vue?: boolean;
}
/**
 * Converts an object of type 'HtmlParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_HtmlParserConfiguration(obj: HtmlParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * Assist options specific to the JavaScript assist
 *
 * @schema JsAssistConfiguration
 */
export interface JsAssistConfiguration {
    /**
     * Enables or disables assist actions for JavaScript and languages that extend it.
     *
     * @schema JsAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsAssistConfiguration(obj: JsAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * Formatting options specific to JavaScript and languages that extend it.
 *
 * @schema JsFormatterConfiguration
 */
export interface JsFormatterConfiguration {
    /**
     * Controls parentheses around arrow-function parameters. `always` always prints parentheses,
     * while `asNeeded` omits them when an arrow function has one parameter and the syntax permits
     * it. Defaults to `always`.
     *
     * @default always`.
     * @schema JsFormatterConfiguration#arrowParentheses
     */
    readonly arrowParentheses?: ArrowParentheses;
    /**
     * The attribute position style in JSX elements. If unset, inherits the global attribute
     * position setting.
     *
     * @schema JsFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Controls the placement of the closing bracket for multiline JSX opening tags. Biome places
     * the bracket at the end of the last attribute line when enabled and on its own line after the
     * last attribute when disabled. Self-closing JSX elements are unaffected. If unset, inherits
     * the global bracket placement setting.
     *
     * @schema JsFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Controls spaces inside the braces of single-line object literals. Biome formats `{value: 1}`
     * when disabled and `{ value: 1 }` when enabled. If unset, inherits the global bracket spacing
     * setting.
     *
     * @schema JsFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported JavaScript and TypeScript delimiters when their
     * content fits on one line. This affects parentheses, square brackets, template
     * interpolations, TypeScript angle brackets, and JSX expression braces. Empty delimiters are
     * unchanged.
     *
     * It also controls spacing after logical NOT operators. In a chain of logical NOT operators,
     * only the final operator receives a following space. Biome doesn't add spaces before opening
     * delimiters.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema JsFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Enables or disables the formatter for JavaScript and languages that extend it.
     *
     * @schema JsFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Uses the same `auto`, `always`, and `never` behavior as the global expansion setting.
     *
     * If unset, inherits the global expansion setting.
     *
     * @schema JsFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * The indent style applied to JavaScript and languages that extend it. If unset, inherits the
     * global indentation style.
     *
     * @schema JsFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to JavaScript and languages that extend it. If unset,
     * inherits the global indentation width.
     *
     * @schema JsFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * Selects the preferred quote style for JSX attribute values. Defaults to `double`.
     *
     * @default double`.
     * @schema JsFormatterConfiguration#jsxQuoteStyle
     */
    readonly jsxQuoteStyle?: QuoteStyle;
    /**
     * The line ending applied to JavaScript and languages that extend it. If unset, inherits the
     * global line ending.
     *
     * @schema JsFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width applied to JavaScript and languages that extend it. If
     * unset, inherits the global line width.
     *
     * @schema JsFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * When breaking binary expressions into multiple lines, whether to break them before or after
     * the binary operator. Defaults to `after`.
     *
     * @default after`.
     * @schema JsFormatterConfiguration#operatorLinebreak
     */
    readonly operatorLinebreak?: OperatorLinebreak;
    /**
     * Controls whether quotes around object property names are preserved. `asNeeded` removes
     * quotes when the property name is valid without them, while `preserve` keeps quotes around
     * property names that were quoted in the input. Defaults to `asNeeded` in configuration
     * (`as-needed` on the CLI).
     *
     * @default asNeeded` in configuration
     * @schema JsFormatterConfiguration#quoteProperties
     */
    readonly quoteProperties?: QuoteProperties;
    /**
     * Selects the preferred quote style for JavaScript and TypeScript string literals. Biome may
     * use the alternate quote when that avoids additional escaping. Defaults to `double`.
     *
     * @default double`.
     * @schema JsFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Prints semicolons after every statement or only where needed to avoid automatic semicolon
     * insertion hazards. Defaults to `always`.
     *
     * @default always`.
     * @schema JsFormatterConfiguration#semicolons
     */
    readonly semicolons?: Semicolons;
    /**
     * Controls trailing commas in multiline comma-separated structures. `all` adds trailing commas
     * wherever syntax permits, including function parameters and calls. `es5` adds them only in
     * constructs supported by ES5, such as array and object literals, and excludes function
     * parameters, function calls, and TypeScript type parameters. `none` removes trailing commas.
     * Defaults to `all`.
     *
     * @default all`.
     * @schema JsFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema JsFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'JsFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsFormatterConfiguration(obj: JsFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * How Biome's analyzer accounts for imports used by JSX.
 *
 * @schema JsxRuntime
 */
export declare enum JsxRuntime {
    /** An automatic or native JSX environment that doesn't require an in-scope factory import. (transparent) */
    TRANSPARENT = "transparent",
    /** A classic React environment that requires the React import, or custom JSX factory imports
  configured in `tsconfig.json`.
  
  Corresponds to the `react` value for the `jsx` option in TypeScript's
  `tsconfig.json`.
  
  This option should only be necessary if you cannot upgrade to a React
  version that supports the new JSX runtime. For more information about
  the old vs. new JSX runtime, please see:
  <https://legacy.reactjs.org/blog/2020/09/22/introducing-the-new-jsx-transform.html> (reactClassic) */
    REACT_CLASSIC = "reactClassic"
}
/**
 * Linter options specific to the JavaScript linter
 *
 * @schema JsLinterConfiguration
 */
export interface JsLinterConfiguration {
    /**
     * Enables or disables the linter for JavaScript and languages that extend it.
     *
     * @schema JsLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsLinterConfiguration(obj: JsLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the JavaScript parser behaves.
 *
 * @schema JsParserConfiguration
 */
export interface JsParserConfiguration {
    /**
     * Controls whether `.js`, `.mjs`, and `.cjs` files may contain JSX syntax. Disabling this
     * option causes JSX in those files to raise a diagnostic. Defaults to `true`.
     *
     * @default true`.
     * @schema JsParserConfiguration#jsxEverywhere
     */
    readonly jsxEverywhere?: boolean;
    /**
     * Enables parsing decorators on class parameters. This syntax belongs to an old experimental
     * proposal and may change. Defaults to `false`.
     *
     * @default false`.
     * @schema JsParserConfiguration#unsafeParameterDecoratorsEnabled
     */
    readonly unsafeParameterDecoratorsEnabled?: boolean;
}
/**
 * Converts an object of type 'JsParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsParserConfiguration(obj: JsParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * Resolver options specific to JavaScript files
 *
 * @schema JsResolverConfiguration
 */
export interface JsResolverConfiguration {
    /**
     * Enables pnpm workspace catalog resolution for JavaScript package manifests.
     *
     * Opt-in:
     * - Set `javascript.resolver.experimentalPnpmCatalogs` to `true`.
     *
     * Scope:
     * - Resolves `catalog:` and `catalog:<name>` dependency versions from
     * `package.json`.
     * - Applies to `dependencies`, `devDependencies`, and `peerDependencies`.
     *
     * Fail-safe behavior:
     * - If `pnpm-workspace.yaml` is missing, unreadable, or cannot be parsed,
     * Biome silently falls back to the default behavior (as if this option
     * were disabled).
     * - Unknown keys and unsupported value shapes in `pnpm-workspace.yaml` are
     * ignored.
     *
     * Limitations:
     * - Only `pnpm-workspace.yaml` is read.
     * - Biome only reads top-level `catalog` / `catalogs` mappings and scalar
     * string entries.
     *
     * Defaults to `false`.
     *
     * @default false`.
     * @schema JsResolverConfiguration#experimentalPnpmCatalogs
     */
    readonly experimentalPnpmCatalogs?: boolean;
}
/**
 * Converts an object of type 'JsResolverConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsResolverConfiguration(obj: JsResolverConfiguration | undefined): Record<string, any> | undefined;
/**
 * Assist options specific to the JSON linter
 *
 * @schema JsonAssistConfiguration
 */
export interface JsonAssistConfiguration {
    /**
     * Enables or disables assist actions for JSON and languages that extend it.
     *
     * @schema JsonAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsonAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonAssistConfiguration(obj: JsonAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema JsonFormatterConfiguration
 */
export interface JsonFormatterConfiguration {
    /**
     * Whether to insert spaces inside braces in object literals. If unset, inherits the global
     * bracket spacing setting.
     *
     * @schema JsonFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces inside JSON square brackets when their content fits on one line. When
     * enabled, `[1, 2, 3]` becomes `[ 1, 2, 3 ]`. Empty brackets are unchanged.
     *
     * If unset, inherits the global delimiter spacing setting.
     *
     * @schema JsonFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Enables or disables the formatter for JSON and languages that extend it.
     *
     * @schema JsonFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Uses the same `auto`, `always`, and `never` behavior as the global expansion setting.
     *
     * If unset, inherits the global expansion setting.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @schema JsonFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * The indent style applied to JSON and languages that extend it. If unset, inherits the global
     * indentation style.
     *
     * @schema JsonFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The indentation width applied to JSON and languages that extend it. If unset, inherits the
     * global indentation width.
     *
     * @schema JsonFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending applied to JSON and languages that extend it. If unset, inherits the global
     * line ending.
     *
     * @schema JsonFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * The preferred maximum line width applied to JSON and languages that extend it. If unset,
     * inherits the global line width.
     *
     * @schema JsonFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Controls trailing commas in multiline JSON arrays and objects. `none` removes trailing
     * commas, while `all` adds them wherever the JSON formatter supports them. Use `all` only for
     * JSON variants that allow trailing commas, and ensure `json.parser.allowTrailingCommas` is
     * enabled or automatically detected for those files. Defaults to `none`.
     *
     * @default none`.
     * @schema JsonFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsonTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of the file. If unset, inherits the global
     * trailing newline setting.
     *
     * @schema JsonFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'JsonFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonFormatterConfiguration(obj: JsonFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Linter options specific to the JSON linter
 *
 * @schema JsonLinterConfiguration
 */
export interface JsonLinterConfiguration {
    /**
     * Enables or disables the linter for JSON and languages that extend it.
     *
     * @schema JsonLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'JsonLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonLinterConfiguration(obj: JsonLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the JSON parser behaves.
 *
 * @schema JsonParserConfiguration
 */
export interface JsonParserConfiguration {
    /**
     * Controls whether comments are allowed in files parsed as JSON. When unset, Biome follows the
     * file type's default behavior. An explicit value overrides that behavior, except that
     * `biome.jsonc` always allows comments.
     *
     * @schema JsonParserConfiguration#allowComments
     */
    readonly allowComments?: boolean;
    /**
     * Controls whether trailing commas are allowed in files parsed as JSON. When unset, Biome
     * follows the file type's default behavior. An explicit value overrides that behavior, except
     * that `biome.jsonc` always allows trailing commas.
     *
     * @schema JsonParserConfiguration#allowTrailingCommas
     */
    readonly allowTrailingCommas?: boolean;
}
/**
 * Converts an object of type 'JsonParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JsonParserConfiguration(obj: JsonParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema RuleDomains
 */
export interface RuleDomains {
    /**
     * @schema RuleDomains#astro
     */
    readonly astro?: RuleDomainValue;
    /**
     * @schema RuleDomains#drizzle
     */
    readonly drizzle?: RuleDomainValue;
    /**
     * @schema RuleDomains#next
     */
    readonly next?: RuleDomainValue;
    /**
     * @schema RuleDomains#playwright
     */
    readonly playwright?: RuleDomainValue;
    /**
     * @schema RuleDomains#project
     */
    readonly project?: RuleDomainValue;
    /**
     * @schema RuleDomains#qwik
     */
    readonly qwik?: RuleDomainValue;
    /**
     * @schema RuleDomains#react
     */
    readonly react?: RuleDomainValue;
    /**
     * @schema RuleDomains#reactNative
     */
    readonly reactNative?: RuleDomainValue;
    /**
     * @schema RuleDomains#solid
     */
    readonly solid?: RuleDomainValue;
    /**
     * @schema RuleDomains#svelte
     */
    readonly svelte?: RuleDomainValue;
    /**
     * @schema RuleDomains#tailwind
     */
    readonly tailwind?: RuleDomainValue;
    /**
     * @schema RuleDomains#test
     */
    readonly test?: RuleDomainValue;
    /**
     * @schema RuleDomains#turborepo
     */
    readonly turborepo?: RuleDomainValue;
    /**
     * @schema RuleDomains#types
     */
    readonly types?: RuleDomainValue;
    /**
     * @schema RuleDomains#vue
     */
    readonly vue?: RuleDomainValue;
}
/**
 * Converts an object of type 'RuleDomains' to JSON representation.
 * @internal
 */
export declare function toJson_RuleDomains(obj: RuleDomains | undefined): Record<string, any> | undefined;
/**
 * @schema Rules
 */
export interface Rules {
    /**
     * @schema Rules#a11y
     */
    readonly a11Y?: any;
    /**
     * @schema Rules#complexity
     */
    readonly complexity?: any;
    /**
     * @schema Rules#correctness
     */
    readonly correctness?: any;
    /**
     * @schema Rules#nursery
     */
    readonly nursery?: any;
    /**
     * @schema Rules#performance
     */
    readonly performance?: any;
    /**
     * Selects the baseline set of lint rules. `recommended` enables Biome's recommended
     * non-nursery rules, `all` enables all non-nursery rules, and `none` starts with no
     * rules enabled. Group-level settings and explicit rule settings override this
     * preset. Defaults to `recommended`.
     *
     * @default recommended`.
     * @schema Rules#preset
     */
    readonly preset?: PresetConfig;
    /**
     * Enables or disables Biome's recommended non-nursery rules. Defaults to `true`.
     *
     * **Deprecated:** This option will be removed in the next major version. Use
     * `linter.rules.preset` instead, or run `biome migrate` to update the configuration.
     *
     * @default true`.
     * @schema Rules#recommended
     */
    readonly recommended?: boolean;
    /**
     * @schema Rules#security
     */
    readonly security?: any;
    /**
     * @schema Rules#style
     */
    readonly style?: any;
    /**
     * @schema Rules#suspicious
     */
    readonly suspicious?: any;
}
/**
 * Converts an object of type 'Rules' to JSON representation.
 * @internal
 */
export declare function toJson_Rules(obj: Rules | undefined): Record<string, any> | undefined;
/**
 * Options that change how the Markdown formatter behaves
 *
 * @schema MarkdownFormatterConfiguration
 */
export interface MarkdownFormatterConfiguration {
    /**
     * Control the formatter for Markdown (and its super languages) files.
     *
     * @schema MarkdownFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Formats the code inside fenced code blocks, frontmatter, and HTML blocks with the formatter
     * of the code's language. Defaults to `true`.
     *
     * A block with a syntax error stays as written, and Biome still formats the rest of the file.
     *
     * When this option is `false`, Biome keeps every block as written.
     *
     * @default true`.
     * @schema MarkdownFormatterConfiguration#formatEmbeds
     */
    readonly formatEmbeds?: boolean;
    /**
     * The indent style applied to Markdown files.
     *
     * @schema MarkdownFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * The size of the indentation applied to Markdown files. Defaults to 2.
     *
     * @default 2.
     * @schema MarkdownFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The type of line ending applied to Markdown (and its super languages) files. `auto` uses CRLF on Windows and LF on other platforms.
     *
     * @schema MarkdownFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * What's the max width of a line applied to Markdown files. Defaults to 80.
     *
     * @default 80.
     * @schema MarkdownFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Controls whether Biome keeps, adds, or removes line breaks in Markdown paragraphs.
     *
     * Manual line breaks are always kept. In Markdown, a manual line break is created by ending a
     * line with two spaces or a backslash.
     *
     * @schema MarkdownFormatterConfiguration#proseWrap
     */
    readonly proseWrap?: ProseWrap;
    /**
     * Whether to add a trailing newline at the end of the file.
     *
     * Setting this option to `false` is **highly discouraged** because it could cause many problems with other tools:
     * - https://thoughtbot.com/blog/no-newline-at-end-of-file
     * - https://callmeryan.medium.com/no-newline-at-end-of-file-navigating-gits-warning-for-android-developers-af14e73dd804
     * - https://unix.stackexchange.com/questions/345548/how-to-cat-files-together-adding-missing-newlines-at-end-of-some-files
     *
     * Disable the option at your own risk.
     *
     * Defaults to true.
     *
     * @default true.
     * @schema MarkdownFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'MarkdownFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_MarkdownFormatterConfiguration(obj: MarkdownFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the Markdown linter behaves
 *
 * @schema MarkdownLinterConfiguration
 */
export interface MarkdownLinterConfiguration {
    /**
     * Control the linter for Markdown files.
     *
     * @schema MarkdownLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'MarkdownLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_MarkdownLinterConfiguration(obj: MarkdownLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the Markdown parser behaves
 *
 * @schema MarkdownParserConfiguration
 */
export interface MarkdownParserConfiguration {
    /**
     * Recognizes bold, italic, and strikethrough markers placed directly next to Chinese, Japanese, or Korean text. Defaults to `false`.
     *
     * Standard Markdown doesn't treat `**テスト。**テスト` as bold text, because the closing `**`
     * is between a punctuation mark and a letter with no space around it. Languages that don't
     * put spaces between words run into this often. When enabled, Biome follows the
     * [CommonMark CJK-friendly amendments](https://github.com/tats-u/markdown-cjk-friendly/blob/main/specification.md)
     * and treats such text as bold or italic. The option applies to `*`, `_`, and `~~` markers.
     * After a variation selector (an invisible character that picks a glyph style for the
     * character before it), Biome classifies a marker by the character before the selector.
     *
     * The option can also change markers that aren't next to Chinese, Japanese, or Korean text,
     * because a marker that can now open or close formatting can take another marker's partner
     * in the same paragraph, heading, or table cell. For example, standard Markdown shows
     * `**テスト。**テスト a**` with `テスト a` in bold. With the option enabled, `テスト。` is bold
     * and the last `**` is shown as written.
     *
     * The formatter and the linter both use this reading of the document. Enable the option only
     * when the tool that renders your Markdown also supports these amendments. Otherwise, Biome
     * treats as bold some text that your renderer shows with literal `**`, and formatting can
     * change what your renderer shows. For example, the option makes `__` after a variation
     * selector a bold marker, and the formatter rewrites it as `**`, which standard Markdown
     * shows as bold even where it showed the original `__` as written.
     *
     * @default false`.
     * @schema MarkdownParserConfiguration#cjkFriendlyEmphasis
     */
    readonly cjkFriendlyEmphasis?: boolean;
    /**
     * Enables parsing frontmatter at the start of the file. Defaults to `false`.
     *
     * @default false`.
     * @schema MarkdownParserConfiguration#frontmatter
     */
    readonly frontmatter?: boolean;
    /**
     * Enables GitHub Flavored Markdown extensions. Defaults to `true`.
     *
     * @default true`.
     * @schema MarkdownParserConfiguration#gfm
     */
    readonly gfm?: boolean;
}
/**
 * Converts an object of type 'MarkdownParserConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_MarkdownParserConfiguration(obj: MarkdownParserConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideAssistConfiguration
 */
export interface OverrideAssistConfiguration {
    /**
     * The assist-action configuration for matched files.
     *
     * @schema OverrideAssistConfiguration#actions
     */
    readonly actions?: Actions;
    /**
     * Enables or disables assist actions for matched files.
     *
     * @schema OverrideAssistConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'OverrideAssistConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideAssistConfiguration(obj: OverrideAssistConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideFilesConfiguration
 */
export interface OverrideFilesConfiguration {
    /**
     * The maximum source-file size in bytes for matched files.
     *
     * @schema OverrideFilesConfiguration#maxSize
     */
    readonly maxSize?: number;
}
/**
 * Converts an object of type 'OverrideFilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideFilesConfiguration(obj: OverrideFilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideFormatterConfiguration
 */
export interface OverrideFormatterConfiguration {
    /**
     * The attribute position style in HTML-like languages.
     *
     * @schema OverrideFormatterConfiguration#attributePosition
     */
    readonly attributePosition?: AttributePosition;
    /**
     * Controls the placement of the closing bracket for multiline HTML and JSX opening tags. Biome
     * places the bracket at the end of the last attribute line when enabled and on its own line when
     * disabled. This also affects self-closing HTML elements, but self-closing JSX elements are
     * unaffected.
     *
     * @schema OverrideFormatterConfiguration#bracketSameLine
     */
    readonly bracketSameLine?: boolean;
    /**
     * Controls spaces inside braces in supported single-line structures. The affected structures
     * vary by language.
     *
     * @schema OverrideFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Controls spaces immediately inside supported delimiters when their content fits on one line.
     * It doesn't add spaces before opening delimiters or inside empty delimiters.
     *
     * The affected delimiters vary by language. If unset, uses the configured formatter setting.
     *
     * @schema OverrideFormatterConfiguration#delimiterSpacing
     */
    readonly delimiterSpacing?: boolean;
    /**
     * Enables or disables the formatter for matched files.
     *
     * @schema OverrideFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Controls whether arrays and objects are formatted on one line or multiple lines.
     *
     * `auto` formats objects on multiple lines if the first property has a newline, and arrays on
     * one line if they fit.
     *
     * `always` formats arrays and objects on multiple lines.
     *
     * `never` formats arrays and objects on one line if they fit.
     *
     * If unset, uses the configured formatter setting.
     *
     * When formatting `package.json`, Biome uses `always` unless configured otherwise.
     *
     * @schema OverrideFormatterConfiguration#expand
     */
    readonly expand?: Expand;
    /**
     * Allows formatting matched files that contain syntax errors.
     *
     * @schema OverrideFormatterConfiguration#formatWithErrors
     */
    readonly formatWithErrors?: boolean;
    /**
     * The indentation width. Deprecated, use `indentWidth` instead.
     *
     * @schema OverrideFormatterConfiguration#indentSize
     */
    readonly indentSize?: number;
    /**
     * Uses tabs or spaces for indentation.
     *
     * @schema OverrideFormatterConfiguration#indentStyle
     */
    readonly indentStyle?: IndentStyle;
    /**
     * Sets the indentation width. With space indentation, this is the number of spaces emitted per
     * indentation level. With tab indentation, Biome emits one tab per level and uses this value as
     * the tab's display width when calculating line length. Accepted values are `0` through `24`.
     *
     * @schema OverrideFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The line ending.
     *
     * @schema OverrideFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * Sets the preferred maximum line width used when deciding where to wrap code. Some content,
     * such as long unbreakable strings, may still exceed this width. Accepted values are `1` through
     * `320`.
     *
     * @schema OverrideFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * Prints trailing commas wherever possible in multiline comma-separated structures. This is a
     * legacy override option. Prefer `javascript.formatter.trailingCommas`.
     *
     * @schema OverrideFormatterConfiguration#trailingCommas
     */
    readonly trailingCommas?: JsTrailingCommas;
    /**
     * Whether to add a trailing newline at the end of matched files. Disabling this option can
     * cause compatibility problems with other tools.
     *
     * @schema OverrideFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'OverrideFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideFormatterConfiguration(obj: OverrideFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema OverrideLinterConfiguration
 */
export interface OverrideLinterConfiguration {
    /**
     * The lint-domain configuration for matched files.
     *
     * @schema OverrideLinterConfiguration#domains
     */
    readonly domains?: RuleDomains;
    /**
     * Enables or disables the linter for matched files.
     *
     * @schema OverrideLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The lint-rule configuration for matched files.
     *
     * @schema OverrideLinterConfiguration#rules
     */
    readonly rules?: Rules;
}
/**
 * Converts an object of type 'OverrideLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_OverrideLinterConfiguration(obj: OverrideLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Integration with Git as the version control client.
 *
 * @schema VcsClientKind
 */
export declare enum VcsClientKind {
    /** git */
    GIT = "git"
}
/**
 * Options that change how the Yaml formatter behaves
 *
 * @schema YamlFormatterConfiguration
 */
export interface YamlFormatterConfiguration {
    /**
     * Whether to insert spaces inside non-empty flow mappings (`{ key: value }`)
     * and sequences (`[ item ]`) that fit on one line. If unset, inherits the
     * global bracket spacing setting. When neither is set, mappings have spaces
     * and sequences do not.
     *
     * @schema YamlFormatterConfiguration#bracketSpacing
     */
    readonly bracketSpacing?: boolean;
    /**
     * Control the formatter for Yaml (and its super languages) files.
     *
     * @schema YamlFormatterConfiguration#enabled
     */
    readonly enabled?: boolean;
    /**
     * The size of the indentation applied to Yaml files. Defaults to 2.
     *
     * @default 2.
     * @schema YamlFormatterConfiguration#indentWidth
     */
    readonly indentWidth?: number;
    /**
     * The type of line ending applied to Yaml (and its super languages) files. `auto` uses CRLF on Windows and LF on other platforms.
     *
     * @schema YamlFormatterConfiguration#lineEnding
     */
    readonly lineEnding?: LineEnding;
    /**
     * What's the max width of a line applied to Yaml files. Defaults to 80.
     *
     * @default 80.
     * @schema YamlFormatterConfiguration#lineWidth
     */
    readonly lineWidth?: number;
    /**
     * The type of quotes used in YAML code. Defaults to `double`.
     *
     * @default double`.
     * @schema YamlFormatterConfiguration#quoteStyle
     */
    readonly quoteStyle?: QuoteStyle;
    /**
     * Whether to add a trailing newline at the end of the file.
     *
     * Setting this option to `false` is **highly discouraged** because it could cause many problems with other tools:
     * - https://thoughtbot.com/blog/no-newline-at-end-of-file
     * - https://callmeryan.medium.com/no-newline-at-end-of-file-navigating-gits-warning-for-android-developers-af14e73dd804
     * - https://unix.stackexchange.com/questions/345548/how-to-cat-files-together-adding-missing-newlines-at-end-of-some-files
     *
     * Disable the option at your own risk.
     *
     * Defaults to true.
     *
     * @default true.
     * @schema YamlFormatterConfiguration#trailingNewline
     */
    readonly trailingNewline?: boolean;
}
/**
 * Converts an object of type 'YamlFormatterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_YamlFormatterConfiguration(obj: YamlFormatterConfiguration | undefined): Record<string, any> | undefined;
/**
 * Options that change how the Yaml linter behaves
 *
 * @schema YamlLinterConfiguration
 */
export interface YamlLinterConfiguration {
    /**
     * Control the linter for Yaml files.
     *
     * @schema YamlLinterConfiguration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'YamlLinterConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_YamlLinterConfiguration(obj: YamlLinterConfiguration | undefined): Record<string, any> | undefined;
/**
 * A preset configuration for enabling a set of rules.
 *
 * @schema PresetConfig
 */
export declare enum PresetConfig {
    /** recommended */
    RECOMMENDED = "recommended",
    /** all */
    ALL = "all",
    /** none */
    NONE = "none"
}
/**
 * Configures one group of assist actions.
 *
 * @schema Source
 */
export interface Source {
    /**
     * Remove repeated CSS class names from HTML class attributes.
     * See https://biomejs.dev/assist/actions/no-duplicate-classes
     *
     * @schema Source#noDuplicateClasses
     */
    readonly noDuplicateClasses?: any;
    /**
     * Organize imports and exports in JavaScript and TypeScript files.
     * See https://biomejs.dev/assist/actions/organize-imports
     *
     * @schema Source#organizeImports
     */
    readonly organizeImports?: any;
    /**
     * Selects the baseline set of assist actions for this group. `recommended` enables
     * the group's recommended actions, `all` enables all actions in the group, and
     * `none` starts with no actions enabled in the group. Explicit action settings
     * override this group preset, which overrides `assist.actions.preset` for the group.
     *
     * @schema Source#preset
     */
    readonly preset?: PresetConfig;
    /**
     * Enables or disables the recommended actions in this group. The group's `preset`
     * setting takes precedence when both options are set.
     *
     * @schema Source#recommended
     */
    readonly recommended?: boolean;
    /**
     * Sort the arguments of GraphQL fields and directives in natural order.
     * See https://biomejs.dev/assist/actions/use-graphql-sorted-arguments
     *
     * @schema Source#useGraphqlSortedArguments
     */
    readonly useGraphqlSortedArguments?: any;
    /**
     * Sort the named definitions in a GraphQL document.
     * See https://biomejs.dev/assist/actions/use-graphql-sorted-definitions
     *
     * @schema Source#useGraphqlSortedDefinitions
     */
    readonly useGraphqlSortedDefinitions?: any;
    /**
     * Sort the variable definitions of GraphQL operations in natural order.
     * See https://biomejs.dev/assist/actions/use-graphql-sorted-variables
     *
     * @schema Source#useGraphqlSortedVariables
     */
    readonly useGraphqlSortedVariables?: any;
    /**
     * Sort HTML attributes and framework directives into a consistent order.
     * See https://biomejs.dev/assist/actions/use-sorted-attributes
     *
     * @schema Source#useSortedAttributes
     */
    readonly useSortedAttributes?: any;
    /**
     * Sort GraphQL enum values in natural order.
     * See https://biomejs.dev/assist/actions/use-sorted-enum-members
     *
     * @schema Source#useSortedEnumMembers
     */
    readonly useSortedEnumMembers?: any;
    /**
     * Sort named members of a TypeScript interface.
     * See https://biomejs.dev/assist/actions/use-sorted-interface-members
     *
     * @schema Source#useSortedInterfaceMembers
     */
    readonly useSortedInterfaceMembers?: any;
    /**
     * Sort keys in a JSON object.
     * See https://biomejs.dev/assist/actions/use-sorted-keys
     *
     * @schema Source#useSortedKeys
     */
    readonly useSortedKeys?: any;
    /**
     * Organize package.json fields according to established conventions.
     * See https://biomejs.dev/assist/actions/use-sorted-package-json
     *
     * @schema Source#useSortedPackageJson
     */
    readonly useSortedPackageJson?: any;
    /**
     * Sort CSS properties and nested rules into a consistent order.
     * See https://biomejs.dev/assist/actions/use-sorted-properties
     *
     * @schema Source#useSortedProperties
     */
    readonly useSortedProperties?: any;
    /**
     * Sort selections inside GraphQL operations and fragments.
     * See https://biomejs.dev/assist/actions/use-sorted-selection-set
     *
     * @schema Source#useSortedSelectionSet
     */
    readonly useSortedSelectionSet?: any;
    /**
     * Sort fields in GraphQL type definitions by name.
     * See https://biomejs.dev/assist/actions/use-sorted-type-fields
     *
     * @schema Source#useSortedTypeFields
     */
    readonly useSortedTypeFields?: any;
}
/**
 * Converts an object of type 'Source' to JSON representation.
 * @internal
 */
export declare function toJson_Source(obj: Source | undefined): Record<string, any> | undefined;
/**
 * @schema QuoteStyle
 */
export declare enum QuoteStyle {
    /** double */
    DOUBLE = "double",
    /** single */
    SINGLE = "single"
}
/**
 * Controls whether HTML void elements such as `<img>` and `<input>` include a slash before `>`.
 *
 * @schema SelfCloseVoidElements
 */
export declare enum SelfCloseVoidElements {
    /** Removes the slash, for example `<img src="image.png">`. (never) */
    NEVER = "never",
    /** Adds the slash, for example `<img src="image.png" />`. (always) */
    ALWAYS = "always"
}
/**
 * Controls how the formatter treats whitespace around text and child elements in HTML, Vue,
 * Svelte, and Astro markup.
 *
 * The following two cases won't produce the same output:
 *
 * |                |      html      |    output    |
 * | -------------- | :------------: | :----------: |
 * | with spaces    | `1<b> 2 </b>3` | 1<b> 2 </b>3 |
 * | without spaces |  `1<b>2</b>3`  |  1<b>2</b>3  |
 *
 * This happens because whitespace is significant in inline elements.
 *
 * As a consequence of this, the formatter must format blocks that look like this (assume a small line width, <20):
 * ```html
 * <span>really long content</span>
 * ```
 * as this, where the content hugs the tags:
 * ```html
 * <span
 * >really long content</span
 * >
 * ```
 *
 * Note that this is only necessary for inline elements. Block elements do not have this restriction.
 *
 * @schema WhitespaceSensitivity
 */
export declare enum WhitespaceSensitivity {
    /** Treats whitespace as significant for elements that browsers display inline by default. (css) */
    CSS = "css",
    /** Treats leading and trailing whitespace as significant for every element. Existing whitespace
  is preserved as at least one character and absent whitespace is not added.
  
  Example of text hugging the tags:
  ```html
  <b
      >content</b
  >
  ``` (strict) */
    STRICT = "strict",
    /** Treats whitespace as insignificant, allowing the formatter to add or remove it. Use this only
  when whitespace cannot affect rendered output. (ignore) */
    IGNORE = "ignore"
}
/**
 * @schema ArrowParentheses
 */
export declare enum ArrowParentheses {
    /** Always prints parentheses around arrow-function parameters. (always) */
    ALWAYS = "always",
    /** Omits parentheses when an arrow function has one parameter and the syntax permits it. (asNeeded) */
    AS_NEEDED = "asNeeded"
}
/**
 * @schema OperatorLinebreak
 */
export declare enum OperatorLinebreak {
    /** The operator is placed after the expression (after) */
    AFTER = "after",
    /** The operator is placed before the expression (before) */
    BEFORE = "before"
}
/**
 * @schema QuoteProperties
 */
export declare enum QuoteProperties {
    /** Removes quotes when the property name is valid without them. (asNeeded) */
    AS_NEEDED = "asNeeded",
    /** Preserves quotes around property names that were quoted in the input. (preserve) */
    PRESERVE = "preserve"
}
/**
 * @schema Semicolons
 */
export declare enum Semicolons {
    /** always */
    ALWAYS = "always",
    /** asNeeded */
    AS_NEEDED = "asNeeded"
}
/**
 * Print trailing commas wherever possible in multi-line comma-separated syntactic structures for JavaScript/TypeScript files.
 *
 * @schema JsTrailingCommas
 */
export declare enum JsTrailingCommas {
    /** all */
    ALL = "all",
    /** es5 */
    ES5 = "es5",
    /** none */
    NONE = "none"
}
/**
 * Controls trailing commas in multiline JSON arrays and objects. Use `all` only for JSON variants that allow trailing commas, and ensure `json.parser.allowTrailingCommas` is enabled or automatically detected for those files.
 *
 * @schema JsonTrailingCommas
 */
export declare enum JsonTrailingCommas {
    /** none */
    NONE = "none",
    /** all */
    ALL = "all"
}
/**
 * @schema RuleDomainValue
 */
export declare enum RuleDomainValue {
    /** Enables all rules in the domain. (all) */
    ALL = "all",
    /** Disables the domain. (none) */
    NONE = "none",
    /** Enables the domain's recommended non-nursery rules. (recommended) */
    RECOMMENDED = "recommended"
}
/**
 * Controls whether Biome keeps, adds, or removes line breaks in Markdown paragraphs.
 *
 * Manual line breaks are always kept. In Markdown, a manual line break is created by ending a
 * line with two spaces or a backslash.
 *
 * @schema ProseWrap
 */
export declare enum ProseWrap {
    /** Keep line breaks as written in the source file. This is the default. (preserve) */
    PRESERVE = "preserve",
    /** Wrap paragraphs to fit the configured `lineWidth`. (always) */
    ALWAYS = "always",
    /** Remove line breaks from paragraphs so that each paragraph is on one line. (never) */
    NEVER = "never"
}
