import type { Project } from "../../project";
export declare function secretToString(secretName: string): string;
export declare function context(value: string): string;
/**
 * Turn any JavaScript value into a GitHub expression
 */
export declare function toGitHubExpr(x: NonNullable<any>): string;
/**
 * Returns the relative path of a project from the root of the repository
 *
 * This is a bit of hack at the moment, because projects currently don't have the concept of a repository.
 * The `.github` directory is always created within the outdir of the root project.
 * Consequently this means a GitHub root project cannot really have an outdir and GH Workflows at the same time.
 * Or in other words, the outdir of the root project is to be assumed the repository root.
 *
 * This helper function can be used to retrieve the correct `working-directory` for a given project.
 *
 * @returns path to be used as `working-directory` of a GitHub workflow, this is never empty and will return `./` for the root project
 */
export declare function projectPathRelativeToRepoRoot(project: Project): string;
