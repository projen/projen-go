/**
 * The shell used to run a task's commands - including its `condition` and any
 * `$(...)` environment-variable evaluation.
 *
 * Choose one of the built-in shells, or provide an explicit shell invocation:
 *
 * - {@link TaskShell.projen} (the default) - the built-in cross-platform shell.
 * - {@link TaskShell.system} - the operating system's native shell.
 * - {@link TaskShell.bash} / {@link TaskShell.sh} - common POSIX shells.
 * - {@link TaskShell.command} - an arbitrary shell invocation given as an
 *   explicit argument list, e.g. `TaskShell.command(["npx", "-c"])`.
 *
 * A `shell` can be set at the project (tasks), task and step level, and the
 * nearest declared level wins (it is a scalar override, not merged).
 */
export declare class TaskShell {
    private readonly value;
    /**
     * The built-in cross-platform shell (the default). It interprets POSIX-style
     * task syntax (`mkdir -p`, `&&`, `$VAR`, ...) identically on every platform,
     * including Windows.
     */
    static projen(): TaskShell;
    /**
     * The operating system's native shell (`/bin/sh` on POSIX, `cmd.exe` on
     * Windows).
     *
     * Use this to opt out of the cross-platform shell and run commands through
     * whatever shell the host provides.
     *
     * Steps given as an argv (`execArgs`) are spawned without a shell, so on
     * Windows they cannot run `.cmd`/`.bat` shims such as npm-installed CLIs.
     */
    static system(): TaskShell;
    /**
     * Runs commands through `bash -c`.
     */
    static bash(): TaskShell;
    /**
     * Runs commands through `sh -c`.
     */
    static sh(): TaskShell;
    /**
     * An arbitrary shell invocation, given as an explicit argument list. The task
     * command is appended as the final argument, so the invocation must accept
     * the command as its last argument (e.g. `bash -c`, `sh -c`, `npx -c`,
     * `yarn exec`).
     *
     *
     * @example TaskShell.command(["bash", "-c"]);
     * @example TaskShell.command(["npx", "-c"]);
     *
     * @param command The shell program followed by its arguments. Must not be
     * empty.
     */
    static command(command: string[]): TaskShell;
    private constructor();
    /**
     * Renders the shell to its `tasks.json` representation: a built-in keyword
     * string (`"projen"` or `"system"`) for the built-ins, or an explicit
     * argument list for a custom shell invocation.
     *
     * @internal
     */
    _render(): string | string[];
}
