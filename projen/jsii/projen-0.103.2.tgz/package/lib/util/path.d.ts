/**
 * Helper function to format a path as dot notation regardless of how it
 * was handed in.
 *
 * @param path - can be formatted as "path", "./path" (but not "/path", as it is absolute)
 * @returns "./path"
 */
export declare function ensureRelativePathStartsWithDot(path: string): string;
/**
 * Checks if part of the file path is hidden
 */
export declare function isHiddenPath(path: string): boolean;
/**
 * Helper to assert a path is not hidden
 */
export declare function ensureNotHiddenPath(value: string, name: string): void;
/**
 * Checks if `file` is strictly inside `dir` (the directory itself does not count).
 *
 * Purely lexical: does not consult the filesystem, so symlinks are not
 * resolved. Relative paths are resolved against the current working directory.
 */
export declare function isPathInside(dir: string, file: string): boolean;
/**
 * Resolves symlinks in `p`, falling back to the closest existing ancestor for
 * paths that do not exist (yet).
 */
export declare function realpathOfClosestExisting(p: string): string;
/**
 * Asserts that a path stays strictly inside a project directory.
 *
 * Use this before passing a user-configurable path to a destructive command
 * (e.g. `rm -fr`): an absolute path or a path traversing outside of the
 * project directory (via `..` or a symlink) could otherwise delete files
 * anywhere on the machine. The project directory itself (`.`) is also
 * rejected.
 *
 * The check resolves both paths on the filesystem (symlinks in existing path
 * segments are followed). The last segment of the path is intentionally kept
 * as-is: a symlink inside the project only affects the link itself.
 *
 * @param value the path to check, relative to the project directory
 * @param name name of the option, used in the error message
 * @param projectDir the project directory the path must stay inside of
 * @throws if the path is absolute or does not stay inside the project directory
 */
export declare function ensurePathInsideProject(value: string, name: string, projectDir: string): void;
