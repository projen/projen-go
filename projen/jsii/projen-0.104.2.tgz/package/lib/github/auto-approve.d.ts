import type { GitHub } from "./github";
import { GithubCredentials } from "./github-credentials";
import { PullRequestSource } from "./pull-request-source";
import { Component } from "../component";
import type { RunsOnOptions } from "../runner-options";
/**
 * Options for 'AutoApprove'
 */
export interface AutoApproveOptions extends RunsOnOptions {
    /**
     * Only pull requests from one of these sources will be auto-approved.
     *
     * Components that create pull requests can add more sources with `AutoApprove.addSource()`.
     * Providing sources, either here or with `addSource()`, replaces the default source.
     *
     * @default [PullRequestSource.fromUsers({ logins: ["github-actions[bot]"] })]
     */
    readonly sources?: PullRequestSource[];
    /**
     * Only pull requests authored by these Github usernames will be auto-approved.
     *
     * An empty list approves pull requests from any user.
     *
     * @default ['github-actions[bot]']
     * @deprecated Use `sources` with `PullRequestSource.fromUsers({ logins })` instead.
     */
    readonly allowedUsernames?: string[];
    /**
     * Only pull requests with this label will be auto-approved.
     *
     * This is required in addition to matching one of the `sources`.
     *
     * @default 'auto-approve'
     */
    readonly label?: string;
    /**
     * The credentials used to approve pull requests.
     *
     * Github forbids an identity to approve its own pull request.
     * These credentials must belong to a different identity than the one creating the pull requests.
     * Use `environment` on the credentials to restrict which branches can access them.
     *
     * @default - the workflow's `GITHUB_TOKEN`
     */
    readonly credentials?: GithubCredentials;
    /**
     * A GitHub secret name which contains a GitHub Access Token
     * with write permissions for the `pull_request` scope.
     *
     * This token is used to approve pull requests.
     *
     * Github forbids an identity to approve its own pull request.
     * If your project produces automated pull requests using the Github default token -
     * {@link https://docs.github.com/en/actions/reference/authentication-in-a-workflow `GITHUB_TOKEN` }
     * - that you would like auto approved, such as when using the `depsUpgrade` property in
     * `NodeProjectOptions`, then you must use a different token here.
     *
     * @default "GITHUB_TOKEN"
     * @deprecated Use `credentials` with `GithubCredentials.fromPersonalAccessToken({ secret })` instead.
     */
    readonly secret?: string;
}
/**
 * Auto approve pull requests that meet a criteria
 */
export declare class AutoApprove extends Component {
    readonly label: string;
    private readonly workflow;
    private readonly sources;
    private sourcesProvided;
    private readonly allowedUsernames?;
    constructor(github: GitHub, options?: AutoApproveOptions);
    /**
     * Auto-approve pull requests from this source, in addition to the configured sources.
     *
     * Adding a source replaces the default source.
     */
    addSource(source: PullRequestSource): void;
    private renderCondition;
}
