/**
 * Options for `PullRequestSource.fromBranch`
 */
export interface PullRequestSourceBranchOptions {
    /**
     * The exact branch the pull request comes from.
     *
     * @default - use `branchPrefix`
     */
    readonly branch?: string;
    /**
     * A prefix the branch the pull request comes from must start with.
     *
     * Make sure to include a separator at the end like `/` or `-`.
     *
     * @default - use `branch`
     */
    readonly branchPrefix?: string;
    /**
     * The branches the pull request may target.
     *
     * @default - any target branch
     */
    readonly targetBranches?: string[];
    /**
     * The GitHub usernames that may author the pull request.
     *
     * @default - any author
     */
    readonly authors?: string[];
}
/**
 * Options for `PullRequestSource.fromUsers`
 */
export interface PullRequestSourceUsersOptions {
    /**
     * The GitHub usernames that may author the pull request.
     */
    readonly logins: string[];
}
/**
 * Describes where a pull request comes from.
 *
 * Used to select which pull requests a workflow acts on, e.g. which pull requests are auto-approved.
 */
export declare class PullRequestSource {
    private readonly condition;
    /**
     * Pull requests from a head branch in this repository.
     *
     * Anyone who can push to the head branch controls the content of the pull request.
     * Protect the matching branches with a ruleset that only allows the intended automation
     * to create, update and delete them.
     */
    static fromBranch(options: PullRequestSourceBranchOptions): PullRequestSource;
    /**
     * Pull requests authored by any of the given users.
     *
     * Anyone with access to the credentials of these users can author a matching pull request.
     */
    static fromUsers(options: PullRequestSourceUsersOptions): PullRequestSource;
    private constructor();
    /**
     * A GitHub Actions expression that is true for pull requests from this source.
     *
     * Only valid in workflows triggered by `pull_request` or `pull_request_target` events.
     *
     * @internal
     */
    _toCondition(): string;
}
