import { Component } from "../component";
import { JsonFile } from "../json";
import type { Project } from "../project";
import type { NodeConfigSchema } from "./node-config";
/**
 * Options for `NodeConfigFile`.
 *
 * @see https://nodejs.org/api/cli.html#configuration-via-nodeconfig
 */
export interface NodeConfigFileOptions extends NodeConfigSchema {
    /**
     * The path of the generated Node.js configuration file.
     *
     * @default "node.config.json"
     */
    readonly filePath?: string;
}
/**
 * Represents a Node.js configuration file, loaded via
 * `--experimental-config-file`.
 *
 * @see https://nodejs.org/api/cli.html#configuration-via-nodeconfig
 */
export declare class NodeConfigFile extends Component {
    /**
     * Returns the `NodeConfigFile` instance associated with a project or
     * `undefined` if there is none.
     */
    static of(project: Project): NodeConfigFile | undefined;
    /**
     * Escape hatch for the generated configuration file.
     */
    readonly config: NodeConfigSchema;
    /**
     * The underlying Node.js configuration file.
     */
    readonly file: JsonFile;
    constructor(project: Project, options?: NodeConfigFileOptions);
}
