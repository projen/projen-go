import * as path from "path";
export interface WriteFileOptions {
    /**
     * Whether the generated file should be marked as executable.
     *
     * @default false
     */
    executable?: boolean;
    /**
     * Whether the generated file should be readonly.
     *
     * @default false
     */
    readonly?: boolean;
}
export declare function getFilePermissions(options: WriteFileOptions): string;
export declare function writeFile(filePath: string, data: any, options?: WriteFileOptions): void;
/**
 * Decamelizes the keys of an object structure, recursing through child objects and arrays.
 * @experimental
 */
export interface DecamelizeRecursivelyOptions {
    /**
     * Max depth to recurse before erroring.
     * @default 10
     */
    maxDepth?: number;
    /**
     * Returns true when a key should be decamelized
     * @default - all keys are decamelized
     */
    shouldDecamelize?: (path: string[], value: any) => boolean;
    /**
     * Separator for decamelizing.
     * @default "_"
     */
    separator?: string;
    /**
     * Current path.
     * @internal
     */
    path?: string[];
}
export declare function decamelizeKeysRecursively(input: any, opt?: DecamelizeRecursivelyOptions): any;
/**
 * Recursively flattens a nested object into dot-separated key/value pairs.
 *
 * For example, `{ sonar: { sources: "src" } }` becomes `[["sonar.sources", "src"]]`.
 * Leaf values (strings, numbers, booleans) are emitted as entries.
 * Null/undefined values are skipped. Arrays of scalars are joined with a
 * comma; arrays containing non-scalar elements throw.
 */
export declare function flattenToDotNotation(obj: Record<string, any>, prefix?: string): Array<[string, string]>;
/**
 * Returns false if value is unset or a falsey value, and true otherwise.
 * @param value an environment variable
 */
export declare function isTruthy(value: string | undefined): boolean;
/**
 * Type of a map mapping strings to some arbitrary type
 */
export type Obj<T> = {
    [key: string]: T;
};
/**
 * Return whether the given value is a plain struct object
 *
 * Even though arrays and instances of classes technically are objects, we
 * usually want to treat them differently, so we return false in those cases.
 */
export declare function isObject(x: any): x is Obj<any>;
/**
 * Configure the behavior of `deepMerge`.
 */
interface MergeOptions {
    /**
     * Whether to delete keys with `undefined` values.
     *
     * @default false
     */
    readonly destructive?: boolean;
    /**
     * Whether to merge arrays.
     *
     * @default false
     */
    readonly mergeArrays?: boolean;
}
/**
 * Recursively merge objects together
 *
 * The leftmost object is mutated and returned.
 *
 * If an object is merged into something other than an object, the non-object is lost.
 * Arrays are overwritten not merged; set `mergeArrays: true` to merge arrays and deduplicate the result.
 * An `undefined` key in a source object will persist; set `destructive: true` to fully remove the key instead.
 * Empty objects as values are preserved in the output; set `destructive: true` to remove them instead.
 */
export declare function deepMerge(objects: Array<Obj<any> | undefined>, { destructive, mergeArrays }?: MergeOptions): Obj<any>;
export declare function dedupArray<T>(array: T[]): T[];
/**
 * Returns a sorted version of `x` or `undefined` if it is an empty array or object.
 */
export declare function sorted<T>(x: T): unknown[] | T | undefined;
export declare function formatAsPythonModule(name: string): string;
/**
 * Extract git version number from command line
 *
 * @param gitVersionOutput the output from `git version` CLI
 * @returns the version of git
 */
export declare function getGitVersion(gitVersionOutput: string): string;
export declare function kebabCaseKeys<T = unknown>(obj: T, recursive?: boolean): T;
export declare function snakeCaseKeys<T = unknown>(obj: T, recursive?: boolean, exclusiveForRecordKeys?: string[]): T;
export declare function tryReadFile(file: string): Promise<string>;
export declare function tryReadFileSync(file: string): string | undefined;
export declare function isWritable(file: string): boolean;
/**
 * Asserts that the file should be executable. Always returns true on Windows.
 *
 * In Windows, the executable attribute is stored in the system setting PATHEXT, not in each file. Then, checking for executability is equivalent to checking for existence. To bypass checking for executability, we always return true on Windows.
 *
 * @param filePath The path to the file
 * @param shouldBeExecutable Whether the file should be executable
 * @returns true if `filePath` executable attribute matches `shouldBeExecutable` or if the platform is Windows, false otherwise
 */
export declare function assertExecutablePermissions(filePath: string, shouldBeExecutable: boolean): boolean;
export declare function isExecutable(file: string): boolean;
export declare function getNodeMajorVersion(): number | undefined;
export declare function anySelected(options: (boolean | undefined)[]): boolean;
export declare function multipleSelected(options: (boolean | undefined)[]): boolean;
/**
 * Checks if a path is a FS root
 *
 * Optional uses a provided OS specific path implementation,
 * defaults to use the implementation for the current OS.
 *
 * @internal
 */
export declare function isRoot(dir: string, osPathLib?: typeof path): boolean;
/**
 * Run up project tree to find a file or directory
 *
 * @param lookFor the file or directory to look for
 * @param cwd current working directory, must be an absolute path
 * @returns path to the file or directory we are looking for, undefined if not found
 */
export declare function findUp(lookFor: string, cwd?: string): string | undefined;
/**
 * Normalizes a path that is going to be persisted to have a cross platform representation.
 *
 * Normalized paths can be persisted and doesn't need to be modified when the platform changes.
 * `normalizePersistedPath` takes care of platform-specific properties like directory separator.
 * It uses `path.posix.sep` that is supported both in Windows and Unix platforms.
 *
 *
 * @param p the path to be normalized
 * @returns the normalized path
 */
export declare function normalizePersistedPath(p: string): string;
export {};
