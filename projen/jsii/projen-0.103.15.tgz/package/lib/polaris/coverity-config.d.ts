/**
 * @schema PolarisCoveritySchema
 */
export interface PolarisCoveritySchema {
    /**
     * @schema PolarisCoveritySchema#analyze
     */
    readonly analyze?: AnalysisConfiguration;
    /**
     * @schema PolarisCoveritySchema#caching
     */
    readonly caching?: CachingConfiguration;
    /**
     * @schema PolarisCoveritySchema#capture
     */
    readonly capture?: CaptureConfiguration;
    /**
     * @schema PolarisCoveritySchema#commit
     */
    readonly commit: CommitConfiguration;
    /**
     * Specifies the version of the configuration file in use.
     *
     * @schema PolarisCoveritySchema#version
     */
    readonly version?: number;
}
/**
 * Converts an object of type 'PolarisCoveritySchema' to JSON representation.
 * @internal
 */
export declare function toJson_PolarisCoveritySchema(obj: PolarisCoveritySchema | undefined): Record<string, any> | undefined;
/**
 * Specifies how the project should be analyzed.
 *
 * @schema analysis-configuration
 */
export interface AnalysisConfiguration {
    /**
     * Specifies the aggressiveness level for the analysis. The aggressiveness level causes the analysis to make more or less aggressive assumptions during the analysis where the higher the aggressiveness level the more defects are reported.
     *
     * @schema analysis-configuration#aggressiveness-level
     */
    readonly aggressivenessLevel?: AnalysisConfigurationAggressivenessLevel;
    /**
     * Enables analysis of calls to function pointers for defects.
     *
     * @schema analysis-configuration#c-cpp-fnptr
     */
    readonly cCppFnptr?: boolean;
    /**
     * Enables full virtual-call resolution for C++.
     *
     * @schema analysis-configuration#c-cpp-virtual
     */
    readonly cCppVirtual?: boolean;
    /**
     * Enables callgraph metrics output in the intermediate directory.
     *
     * @schema analysis-configuration#callgraph-metrics
     */
    readonly callgraphMetrics?: boolean;
    /**
     * If no checker configuration is specified, the CLI will enable a set of checkers based on the files that were captured.
     *
     * @schema analysis-configuration#checkers
     */
    readonly checkers?: CheckerConfiguration;
    /**
     * If specified, the analysis will scan the code for compliance according to the given coding standard configuration. If this configuration is present, the capture "emit-complementary-info" flag will be set to true.
     *
     * @schema analysis-configuration#coding-standards
     */
    readonly codingStandards?: CodingStandardConfiguration;
    /**
     * Coverity Connect configuration to use when performing analysis in Coverity Connect.
     *
     * @schema analysis-configuration#connect
     */
    readonly connect?: AnalyzeConnectConfiguration;
    /**
     * Enables additional filtering of defects by using an additional false-path pruner. If set to true, the constraint FPP is enabled.
     *
     * @schema analysis-configuration#constraint-fpp
     */
    readonly constraintFpp?: boolean;
    /**
     * Additional arguments to pass to cov-analyze when doing analysis.
     *
     * @schema analysis-configuration#cov-analyze-args
     */
    readonly covAnalyzeArgs?: string[];
    /**
     * Additional arguments to pass to cov-collect-models following analysis when "output-model-file" is specified.
     *
     * @schema analysis-configuration#cov-collect-models-args
     */
    readonly covCollectModelsArgs?: string[];
    /**
     * Specifies directives to use for the analysis, including for web application security analysis.
     *
     * @schema analysis-configuration#directives
     */
    readonly directives?: DirectivesConfiguration[];
    /**
     * Specifies which files to analyze when the "analyze.mode" setting is "hfi". Analysis will be performed for only these files.
     *
     * @schema analysis-configuration#files
     */
    readonly files?: AnalyzeFilesConfiguration;
    /**
     * Specifies analysis worker parallelism.
     *
     * @schema analysis-configuration#jobs
     */
    readonly jobs?: JobsConfiguration[];
    /**
     * Specifies whether the analysis should be done locally, in Coverity Connect, or in Software Risk Manager. The possible values are as follows: connect - Run the analysis in the Coverity Connect job farm; srm - Run the analysis in the Software Risk Manager job farm; local - Run the analysis locally
     *
     * @schema analysis-configuration#location
     */
    readonly location?: AnalysisConfigurationLocation;
    /**
     * Analysis mode: "pfi" (perfect fidelity incremental) for complete analysis; or "hfi" (high fidelity incremental) for analysis of only specific files specified by analyze.files settings, omitting any other files which may have been incidentally captured by the build. An "hfi" analysis can be faster but may produce results which are incomplete or inconsistent, due to the lack of context, and should be used only when speed is more important than accuracy.
     *
     * @schema analysis-configuration#mode
     */
    readonly mode?: AnalysisConfigurationMode;
    /**
     * File containing function models. This overrides models specified in the default location of "config/user_models.xmldb".
     *
     * @schema analysis-configuration#model-file
     */
    readonly modelFile?: string;
    /**
     * If set to to true, only one TU (translation unit) will be analyzed per source file name. If set to false, all translation units will be analyzed.
     *
     * @schema analysis-configuration#one-tu-per-psf
     */
    readonly oneTuPerPsf?: boolean;
    /**
     * Output file to which function models for the project should be written following analysis.
     *
     * @schema analysis-configuration#output-model-file
     */
    readonly outputModelFile?: string;
    /**
     * Specifies how parse warnings are handled.
     *
     * @schema analysis-configuration#parse-warnings
     */
    readonly parseWarnings?: ParseWarningsConfiguration;
    /**
     * Specifies whether to enable the collection of scan transparency data for analysis. This setting must be enabled if the Coverity Connect instance has 'scan.transparency.enabled=true' in its configuration.
     *
     * @schema analysis-configuration#scan-transparency
     */
    readonly scanTransparency?: boolean;
    /**
     * Specifies options for Sigma analysis.
     *
     * @schema analysis-configuration#sigma
     */
    readonly sigma?: SigmaConfiguration;
    /**
     * This is a map from trust option name to boolean to indicate whether the particular trust property should be trusted or distrusted. The trust option "all" controls whether all trust options should be trusted or distrusted.
     *
     * @schema analysis-configuration#trust
     */
    readonly trust?: any;
}
/**
 * Converts an object of type 'AnalysisConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_AnalysisConfiguration(obj: AnalysisConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies how the CLI should handle caching when performing capture/analysis.
 *
 * @schema caching-configuration
 */
export interface CachingConfiguration {
    /**
     * A true value indicates caching will be used when performing remote analysis.
     *
     * @schema caching-configuration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CachingConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CachingConfiguration(obj: CachingConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies how the project should be captured.
 *
 * @schema capture-configuration
 */
export interface CaptureConfiguration {
    /**
     * Specifies whether to enable or disable build command inference. If build command inference is disabled and no build command is provided then no attempt at build capture will be made.
     *
     * @schema capture-configuration#build-command-inference
     */
    readonly buildCommandInference?: boolean;
    /**
     * Specifies which compilers to configure. By default, template compilers are configured.
     *
     * @schema capture-configuration#compiler-configuration
     */
    readonly compilerConfiguration?: CompilerConfiguration;
    /**
     * @schema capture-configuration#cov-translate
     */
    readonly covTranslate?: CovTranslateConfiguration;
    /**
     * Records additional information during the emit process needed for the compliance checkers. If a "coding-standards" configuration is present then this flag will automatically be set to true.
     *
     * @schema capture-configuration#emit-complementary-info
     */
    readonly emitComplementaryInfo?: boolean;
    /**
     * Specifies the encoding to use when parsing and emitting the source files.
     *
     * @schema capture-configuration#encoding
     */
    readonly encoding?: string;
    /**
     * Specifies the minimum percentage of files that must be captured in order to proceed with the analysis.
     *
     * @schema capture-configuration#failure-threshold-percent
     */
    readonly failureThresholdPercent?: number;
    /**
     * Specifies which non-compiled files to capture. By default, all files are captured.
     *
     * @schema capture-configuration#files
     */
    readonly files?: FilesConfiguration;
    /**
     * Force resolution of Maven, Gradle and MSBuild dependencies even if this is not needed based on the detected source languages in the project.
     *
     * @schema capture-configuration#force-dependency-resolution
     */
    readonly forceDependencyResolution?: boolean;
    /**
     * Specifies which languages to include or exclude for capture. By default, all languages are captured.
     *
     * @schema capture-configuration#languages
     */
    readonly languages?: LanguagesConfiguration;
    /**
     * Specifies how to import data about source file changes from the source control management system.
     *
     * @schema capture-configuration#import-scm
     */
    readonly importScm?: ImportScmConfiguration;
    /**
     * Specifies whether to limit the group of emitted JAR files to those needed for compilation of the Java files. The default behavior without this option is to emit all the JAR files in the classpath regardless of whether they are referenced by a Java file in the compilation.
     *
     * @schema capture-configuration#minimal-classpath-emit
     */
    readonly minimalClasspathEmit?: boolean;
    /**
     * Specifies whether to do a complete capture or a record with source capture.
     *
     * @schema capture-configuration#record-with-source
     */
    readonly recordWithSource?: boolean;
    /**
     * Enables or disables security dynamic analysis. If set to true (the default), security dynamic analysis is run as part of the capture step. If set to false, security dynamic analysis is not run.
     *
     * @schema capture-configuration#security-da
     */
    readonly securityDa?: boolean;
    /**
     * @schema capture-configuration#build-capture
     */
    readonly buildCapture?: BuildConfiguration;
}
/**
 * Converts an object of type 'CaptureConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CaptureConfiguration(obj: CaptureConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies where the analysis results should be sent.
 *
 * @schema commit-configuration
 */
export interface CommitConfiguration {
    /**
     * Coverity Connect configuration to use when committing defects to Coverity Connect.
     *
     * @schema commit-configuration#connect
     */
    readonly connect?: CommitConfigurationConnect;
    /**
     * Software Risk Manager configuration to use when storing defects in Software Risk Manager.
     *
     * @schema commit-configuration#srm
     */
    readonly srm?: CommitConfigurationSrm;
    /**
     * Local configuration to use when saving defects to the local file system.
     *
     * @schema commit-configuration#local
     */
    readonly local?: CommitConfigurationLocal;
}
/**
 * Converts an object of type 'CommitConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CommitConfiguration(obj: CommitConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies the aggressiveness level for the analysis. The aggressiveness level causes the analysis to make more or less aggressive assumptions during the analysis where the higher the aggressiveness level the more defects are reported.
 *
 * @schema AnalysisConfigurationAggressivenessLevel
 */
export declare enum AnalysisConfigurationAggressivenessLevel {
    /** low */
    LOW = "low",
    /** medium */
    MEDIUM = "medium",
    /** high */
    HIGH = "high"
}
/**
 * @schema checker-configuration
 */
export interface CheckerConfiguration {
    /**
     * Indicates whether all checkers should be enabled.
     *
     * @schema checker-configuration#all
     */
    readonly all?: boolean;
    /**
     * Indicates whether all security checkers should be enabled. This includes the Security, Android Security, and Web App Security categories, and other security checkers that require explicit enablement.
     *
     * @schema checker-configuration#all-security
     */
    readonly allSecurity?: boolean;
    /**
     * If set to true, enables android security checkers.
     *
     * @schema checker-configuration#android-security
     */
    readonly androidSecurity?: boolean;
    /**
     * Enables audit checkers.
     *
     * @schema checker-configuration#audit
     */
    readonly audit?: boolean;
    /**
     * Indicates whether the brakeman checkers should be enabled or disabled.
     *
     * @schema checker-configuration#brakeman
     */
    readonly brakeman?: boolean;
    /**
     * Enables C, C++, Objective-C, Objective-C++ security-related checkers that are disabled by default.
     *
     * @schema checker-configuration#c-family-security
     */
    readonly cFamilySecurity?: boolean;
    /**
     * Map from checker name to configuration for the checker.
     * The configuration indicates whether the checker should be enabled or not and allows users to set options used to configure the checker.
     *
     * @schema checker-configuration#checker-config
     */
    readonly checkerConfig?: any;
    /**
     * Specifies CodeXM (.cxm) files to use in the analysis.
     *
     * @schema checker-configuration#codexm
     */
    readonly codexm?: string[];
    /**
     * Enables C, C++ concurrency checkers that are disabled by default.
     *
     * @schema checker-configuration#concurrency
     */
    readonly concurrency?: boolean;
    /**
     * Specifies whether to enable the default set of checkers. If set to true, the default set of checkers is enabled. Set to false to get more control over which checkers are enabled.
     *
     * @schema checker-configuration#default
     */
    readonly default?: boolean;
    /**
     * Enables or disables PMD for Apex analysis.
     *
     * @schema checker-configuration#pmd
     */
    readonly pmd?: boolean;
    /**
     * Enables or disables recommended security checkers.
     *
     * @schema checker-configuration#recommended-security-checkers
     */
    readonly recommendedSecurityCheckers?: boolean;
    /**
     * Enables C, C++ rule checkers.
     *
     * @schema checker-configuration#rule
     */
    readonly rule?: boolean;
    /**
     * Specifies how web application security analysis should be done.
     *
     * @schema checker-configuration#webapp-security
     */
    readonly webappSecurity?: CheckerConfigurationWebappSecurity;
}
/**
 * Converts an object of type 'CheckerConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CheckerConfiguration(obj: CheckerConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema coding-standard-configuration
 */
export interface CodingStandardConfiguration {
    /**
     * Enables AUTOSAR code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#autosarcpp14
     */
    readonly autosarcpp14?: SpecificCodingStandardConfiguration;
    /**
     * Enables CERT-C code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#cert-c
     */
    readonly certC?: SpecificCodingStandardConfiguration;
    /**
     * Enables CERT-C Recommendation code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#cert-c-recommendation
     */
    readonly certCRecommendation?: SpecificCodingStandardConfiguration;
    /**
     * Enables CERT-CPP code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#cert-cpp
     */
    readonly certCpp?: SpecificCodingStandardConfiguration;
    /**
     * Enables CERT-Java code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#cert-java
     */
    readonly certJava?: SpecificCodingStandardConfiguration;
    /**
     * Enables HYUNDAI-C code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#hyundai-c
     */
    readonly hyundaiC?: SpecificCodingStandardConfiguration;
    /**
     * Enables HYUNDAI-CPP code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#hyundai-cpp
     */
    readonly hyundaiCpp?: SpecificCodingStandardConfiguration;
    /**
     * Enables HYUNDAI-Java code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#hyundai-java
     */
    readonly hyundaiJava?: SpecificCodingStandardConfiguration;
    /**
     * If set to true, any defects found in code annotated using the #pragma Coverity compliance directive will not be reported in Coverity Connect. Information about the defects that were suppressed can then be found in two files: deviations.txt deviations-warnings.txt
     *
     * @schema coding-standard-configuration#ignore-deviated-findings
     */
    readonly ignoreDeviatedFindings?: boolean;
    /**
     * Enables ISO TS 17961 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#iso-ts17961
     */
    readonly isoTs17961?: SpecificCodingStandardConfiguration;
    /**
     * Enables MISRA C 2004 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#misrac2004
     */
    readonly misrac2004?: SpecificCodingStandardConfiguration;
    /**
     * Enables MISRA C 2012 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#misrac2012
     */
    readonly misrac2012?: SpecificCodingStandardConfiguration;
    /**
     * Enables MISRA C 2023 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#misrac2023
     */
    readonly misrac2023?: SpecificCodingStandardConfiguration;
    /**
     * Enables MISRA C++ 2008 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#misracpp2008
     */
    readonly misracpp2008?: SpecificCodingStandardConfiguration;
    /**
     * Enables MISRA C++ 2023 code compliance checking according to the given configuration.
     *
     * @schema coding-standard-configuration#misracpp2023
     */
    readonly misracpp2023?: SpecificCodingStandardConfiguration;
}
/**
 * Converts an object of type 'CodingStandardConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CodingStandardConfiguration(obj: CodingStandardConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema analyze-connect-configuration
 */
export interface AnalyzeConnectConfiguration {
    /**
     * The authentication key file to use when authenticating to Coverity Connect to perform analysis. By default, the file located at $HOME/.coverity/ak-<hostname>-<port> is used.
     *
     * @schema analyze-connect-configuration#auth-key-file
     */
    readonly authKeyFile?: string;
    /**
     * File containing additional certificates to trust in addition to the ones in the system certificate store and the Coverity TFT store. By default system CA certificates are used.
     *
     * @schema analyze-connect-configuration#ca-certs-file
     */
    readonly caCertsFile?: string;
    /**
     * File containing the client certificate in PEM format, that should be presented to the proxy when making a request.
     *
     * @schema analyze-connect-configuration#proxy-client-cert-file
     */
    readonly proxyClientCertFile?: string;
    /**
     * File containing the client certificate private key in PEM format, for the proxy-client-cert-file.
     *
     * @schema analyze-connect-configuration#proxy-client-key-file
     */
    readonly proxyClientKeyFile?: string;
    /**
     * URL for a forward proxy to use when communicating with Coverity Connect.  Must be an https URL.
     *
     * @schema analyze-connect-configuration#proxy-url
     */
    readonly proxyUrl?: string;
    /**
     * Artifacts to upload following analysis when the analysis location is Connect.
     *
     * @schema analyze-connect-configuration#upload-artifacts
     */
    readonly uploadArtifacts?: AnalyzeConnectConfigurationUploadArtifacts;
    /**
     * Absolute URL of where to perform Coverity Connect analysis.
     *
     * @schema analyze-connect-configuration#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'AnalyzeConnectConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_AnalyzeConnectConfiguration(obj: AnalyzeConnectConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema directives-configuration
 */
export interface DirectivesConfiguration {
    /**
     * Security directives configuration to use during the analysis. This key is mutually exclusive with the "file" key and is specified in the case where the user wants to in-line the security directives configuration in the file.
     *
     * @schema directives-configuration#config
     */
    readonly config?: DirectivesConfigurationConfig;
    /**
     * File containing security directives to use during the analysis. This key is mutually exclusive with the "config" key.
     *
     * @schema directives-configuration#file
     */
    readonly file?: string;
}
/**
 * Converts an object of type 'DirectivesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_DirectivesConfiguration(obj: DirectivesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema analyze-files-configuration
 */
export interface AnalyzeFilesConfiguration {
    /**
     * Glob pattern that specifies the set of source files to exclude from analysis. Note that any include glob patterns and regular expressions are processed prior to handling exclude glob patterns and regular expressions.
     *
     * @schema analyze-files-configuration#exclude-glob
     */
    readonly excludeGlob?: string;
    /**
     * Regular expression that specifies the set of source files to exclude from analysis. Note that any include glob patterns and regular expressions are processed prior to handling exclude glob patterns and regular expressions.
     *
     * @schema analyze-files-configuration#exclude-regex
     */
    readonly excludeRegex?: string;
    /**
     * Paths of source files to analyze. Include and exclude glob patterns and regular expressions are applied to determine which of these files are actually analyzed.
     *
     * @schema analyze-files-configuration#include-files
     */
    readonly includeFiles?: string;
    /**
     * Glob pattern that specifies the set of source files to analyze.
     *
     * @schema analyze-files-configuration#include-glob
     */
    readonly includeGlob?: string;
    /**
     * File containing the paths of source files to analyze, one per line. Include and exclude glob patterns and regular expressions are applied to determine which of these files are actually analyzed.
     *
     * @schema analyze-files-configuration#include-list-file
     */
    readonly includeListFile?: string;
    /**
     * Regular expression that specifies the set of source files to analyze.
     *
     * @schema analyze-files-configuration#include-regex
     */
    readonly includeRegex?: string;
}
/**
 * Converts an object of type 'AnalyzeFilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_AnalyzeFilesConfiguration(obj: AnalyzeFilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema jobs-configuration
 */
export interface JobsConfiguration {
    /**
     * If true, the number of analysis workers to run in parallel is based on the amount of memory and number of logical processors in the machine. This is the default for a non-Flexnet license. This key is mutually exclusive with the "count" and "max" keys.
     *
     * @schema jobs-configuration#auto
     */
    readonly auto?: boolean;
    /**
     * Number of analysis workers to run in parallel. This key is mutually exclusive with the "auto" and "max" keys.
     *
     * @schema jobs-configuration#count
     */
    readonly count?: number;
    /**
     * Maximum number of analysis worker to run in parallel, subject to limits on the amount of memory and number of logical processors in the machine. A value of 8 is the default for a Flexnet license. This key is mutually exclusive with the "auto" and "count" keys.
     *
     * @schema jobs-configuration#max
     */
    readonly max?: number;
    /**
     * Allows the number of analysis workers to exceed the recommended value. This key may only be used with the "count" key.
     *
     * @schema jobs-configuration#override-worker-limit
     */
    readonly overrideWorkerLimit?: boolean;
}
/**
 * Converts an object of type 'JobsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_JobsConfiguration(obj: JobsConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies whether the analysis should be done locally, in Coverity Connect, or in Software Risk Manager. The possible values are as follows: connect - Run the analysis in the Coverity Connect job farm; srm - Run the analysis in the Software Risk Manager job farm; local - Run the analysis locally
 *
 * @schema AnalysisConfigurationLocation
 */
export declare enum AnalysisConfigurationLocation {
    /** local */
    LOCAL = "local",
    /** connect */
    CONNECT = "connect",
    /** srm */
    SRM = "srm"
}
/**
 * Analysis mode: "pfi" (perfect fidelity incremental) for complete analysis; or "hfi" (high fidelity incremental) for analysis of only specific files specified by analyze.files settings, omitting any other files which may have been incidentally captured by the build. An "hfi" analysis can be faster but may produce results which are incomplete or inconsistent, due to the lack of context, and should be used only when speed is more important than accuracy.
 *
 * @schema AnalysisConfigurationMode
 */
export declare enum AnalysisConfigurationMode {
    /** hfi */
    HFI = "hfi",
    /** pfi */
    PFI = "pfi"
}
/**
 * @schema parse-warnings-configuration
 */
export interface ParseWarningsConfiguration {
    /**
     * Enables parse warnings, recovery warnings, and semantic warnings that are produced by the cov-build command so that they appear as defects in Coverity Connect. By default, this is disabled if the aggressiveness level is low, and enabled if the aggressiveness level is medium or high.
     *
     * @schema parse-warnings-configuration#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'ParseWarningsConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_ParseWarningsConfiguration(obj: ParseWarningsConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema sigma-configuration
 */
export interface SigmaConfiguration {
    /**
     * List of check sets to enable.
     *
     * @schema sigma-configuration#enable-check-set
     */
    readonly enableCheckSet?: SigmaConfigurationEnableCheckSet[];
    /**
     * List of files containing malicious URL patterns.
     *
     * @schema sigma-configuration#malicious-url-patterns-file
     */
    readonly maliciousUrlPatternsFile?: string[];
}
/**
 * Converts an object of type 'SigmaConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_SigmaConfiguration(obj: SigmaConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema compiler-configuration
 */
export interface CompilerConfiguration {
    /**
     * Specifies a list of arguments to pass to "cov-configure" to generate the compiler configuration to use during capture. This key is mutually exclusive with the "file" key.
     *
     * @schema compiler-configuration#cov-configure
     */
    readonly covConfigure?: string[][];
    /**
     * Specifies a pre-generated compiler configuration file to use. This key is mutually exclusive with the "cov-configure" key.
     *
     * @schema compiler-configuration#file
     */
    readonly file?: string;
}
/**
 * Converts an object of type 'CompilerConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CompilerConfiguration(obj: CompilerConfiguration | undefined): Record<string, any> | undefined;
/**
 * Command to invoke that will invoke "cov-translate" to capture the project.
 *
 * @schema cov-translate-configuration
 */
export interface CovTranslateConfiguration {
    /**
     * This key specifies a command to invoke that will invoke "cov-translate" in the case where the user is doing a "cov-translate" capture.
     *
     * @schema cov-translate-configuration#command
     */
    readonly command: string;
    /**
     * Additional arguments to pass to cov-build when invoking the provided command.
     *
     * @schema cov-translate-configuration#cov-build-args
     */
    readonly covBuildArgs?: string[];
    /**
     * Specifies whether the build should only record the decompilations of byte code during the build and not attempt to decompile and emit the byte code. During the analysis phase, cov-build will be rerun with --replay-decomp to decompile and emit the byte code.
     *
     * @schema cov-translate-configuration#defer-decomp
     */
    readonly deferDecomp?: boolean;
    /**
     * Specifies how to parallelize translation of C and C++ code.
     *
     * @schema cov-translate-configuration#parallel-translate
     */
    readonly parallelTranslate?: ParallelTranslateConfiguration;
    /**
     * Specifies whether to enable the collection of scan transparency data for cov-translate capture. This setting must be enabled if the Coverity Connect instance has 'scan.transparency.enabled=true' in its configuration.
     *
     * @schema cov-translate-configuration#scan-transparency
     */
    readonly scanTransparency?: boolean;
}
/**
 * Converts an object of type 'CovTranslateConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_CovTranslateConfiguration(obj: CovTranslateConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema files-configuration
 */
export interface FilesConfiguration {
    /**
     * Specifies whether to enable capture of minified JavaScript files.
     *
     * @schema files-configuration#emit-minified-js
     */
    readonly emitMinifiedJs?: boolean;
    /**
     * Glob pattern that specifies the set of source files to exclude from capture. Note that any include glob patterns and regular expressions are processed prior to handling exclude glob patterns and regular expressions.
     *
     * @schema files-configuration#exclude-glob
     */
    readonly excludeGlob?: string;
    /**
     * Regular expression that specifies the set of source files to exclude from capture. Note that any include glob patterns and regular expressions are processed prior to handling exclude glob patterns and regular expressions.
     *
     * @schema files-configuration#exclude-regex
     */
    readonly excludeRegex?: string;
    /**
     * List of directory basenames to include for capture, which would normally have been excluded. By default, directories named "vendor" or "node_modules" are excluded, as are directories whose names begin with "."
     *
     * @schema files-configuration#include-dirs
     */
    readonly includeDirs?: string[];
    /**
     * Glob pattern that specifies the set of source files to capture.
     *
     * @schema files-configuration#include-glob
     */
    readonly includeGlob?: string;
    /**
     * File containing the paths of source files to capture, one per line. Include and exclude glob patterns and regular expressions are applied to determine which of these files are actually captured.
     *
     * @schema files-configuration#include-list-file
     */
    readonly includeListFile?: string;
    /**
     * Regular expression that specifies the set of source files to capture.
     *
     * @schema files-configuration#include-regex
     */
    readonly includeRegex?: string;
    /**
     * Specifies the Java version to use when parsing and emitting Java source files with buildless capture.
     *
     * @schema files-configuration#java-version
     */
    readonly javaVersion?: string;
    /**
     * List of directories to look in for dependencies to use during capture.
     *
     * @schema files-configuration#library-dirs
     */
    readonly libraryDirs?: string[];
    /**
     * List of file dependencies to use during capture.
     *
     * @schema files-configuration#library-files
     */
    readonly libraryFiles?: string[];
    /**
     * Specifies information about which web-application archives should be captured. By default all webapp archives are captured.
     *
     * @schema files-configuration#webapp-archives
     */
    readonly webappArchives?: WebappArchiveConfiguration[];
}
/**
 * Converts an object of type 'FilesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_FilesConfiguration(obj: FilesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema languages-configuration
 */
export interface LanguagesConfiguration {
    /**
     * Specifies the languages for which the source code should be excluded in the capture. This key is mutually exclusive with the "include" key.
     *
     * @schema languages-configuration#exclude
     */
    readonly exclude?: LanguagesConfigurationExclude[];
    /**
     * Specifies the languages for which the source code should be included in the capture. This key is mutually exclusive with the "exclude" key.
     *
     * @schema languages-configuration#include
     */
    readonly include?: LanguagesConfigurationInclude[];
}
/**
 * Converts an object of type 'LanguagesConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_LanguagesConfiguration(obj: LanguagesConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema import-scm-configuration
 */
export interface ImportScmConfiguration {
    /**
     * Additional arguments to pass to cov-import-scm following capture.
     *
     * @schema import-scm-configuration#cov-import-scm-args
     */
    readonly covImportScmArgs?: string[];
    /**
     * Regular expression that specifies the set of files for which to import change information.
     *
     * @schema import-scm-configuration#filename-regex
     */
    readonly filenameRegex?: string;
    /**
     * Delay in milliseconds between calls to the underlying SCM.
     *
     * @schema import-scm-configuration#ms-delay
     */
    readonly msDelay?: number;
    /**
     * The name of the source control management system.
     *
     * @schema import-scm-configuration#scm
     */
    readonly scm?: string;
}
/**
 * Converts an object of type 'ImportScmConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_ImportScmConfiguration(obj: ImportScmConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies that build capture should be used to capture the project and provides the build configuration to use. If not specified and the project directory contains compiled source files then automatic build capture will be used to capture compiled source files in the project directory.
 *
 * @schema build-configuration
 */
export interface BuildConfiguration {
    /**
     * Specifies whether to enable or disable the automatic invocation of Aspnet_compiler.exe for any ASP.NET 4 and earlier Web applications that are detected in the build. The output of Aspnet_compiler.exe is required by the C# and Visual Basic security checkers.
     *
     * @schema build-configuration#aspnet-compiler
     */
    readonly aspnetCompiler?: boolean;
    /**
     * Specifies whether to enable Bazel capture.
     *
     * @schema build-configuration#bazel
     */
    readonly bazel?: boolean;
    /**
     * The build command will be invoked to use build capture to capture the project. A build command specified on the command-line will override this setting.
     *
     * @schema build-configuration#build-command
     */
    readonly buildCommand: string;
    /**
     * The clean command will be invoked prior to doing build capture to capture the project.
     *
     * @schema build-configuration#clean-command
     */
    readonly cleanCommand?: string;
    /**
     * Additional arguments to pass to cov-build when doing build capture.
     *
     * @schema build-configuration#cov-build-args
     */
    readonly covBuildArgs?: string[];
    /**
     * Specifies whether the build should only record the decompilations of byte code during the build and not attempt to decompile and emit the byte code. During the analysis phase, cov-build will be rerun with --replay-decomp to decompile and emit the byte code.
     *
     * @schema build-configuration#defer-decomp
     */
    readonly deferDecomp?: boolean;
    /**
     * Specifies whether to use the instrumentation mode instead of the debugger. For certain builds, this configuration can significantly improve build times. This setting is applicable only on Windows.
     *
     * @schema build-configuration#instrument
     */
    readonly instrument?: boolean;
    /**
     * Specifies how to parallelize translation of C and C++ code.
     *
     * @schema build-configuration#parallel-translate
     */
    readonly parallelTranslate?: ParallelTranslateConfiguration;
    /**
     * Specifies whether to enable the collection of scan transparency data for build capture. This setting must be enabled if the Coverity Connect instance has 'scan.transparency.enabled=true' in its configuration.
     *
     * @schema build-configuration#scan-transparency
     */
    readonly scanTransparency?: boolean;
}
/**
 * Converts an object of type 'BuildConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_BuildConfiguration(obj: BuildConfiguration | undefined): Record<string, any> | undefined;
/**
 * Coverity Connect configuration to use when committing defects to Coverity Connect.
 *
 * @schema CommitConfigurationConnect
 */
export interface CommitConfigurationConnect {
    /**
     * The authentication key file to use when authenticating to Coverity Connect to commit defects. By default, the file located at $HOME/.coverity/ak-<hostname>-<port> is used.
     *
     * @schema CommitConfigurationConnect#auth-key-file
     */
    readonly authKeyFile?: string;
    /**
     * File containing additional certificates to trust in addition to the ones in the system certificate store and the Coverity TFT store. By default system CA certificates are used.
     *
     * @schema CommitConfigurationConnect#ca-certs-file
     */
    readonly caCertsFile?: string;
    /**
     * If true, analysis results will not be committed to Coverity Connect.  Instead, results compared to a reference snapshot may be saved locally as specified by the "commit.local" settings.
     *
     * @schema CommitConfigurationConnect#comparison-only
     */
    readonly comparisonOnly?: boolean;
    /**
     * Output file to which analysis results should be written instead of being committed to Coverity Connect. The output includes a comparison against the latest snapshot for the specified stream.
     *
     * @schema CommitConfigurationConnect#comparison-report
     */
    readonly comparisonReport?: string;
    /**
     * Additional arguments to pass to "cov-commit-defects" during the commit phase.
     *
     * @schema CommitConfigurationConnect#cov-commit-defects-args
     */
    readonly covCommitDefectsArgs?: string[];
    /**
     * A description for the committed snapshot.
     *
     * @schema CommitConfigurationConnect#description
     */
    readonly description?: string;
    /**
     * Indicates whether to trust self-signed certificates presented by Coverity Connect that are not currently trusted.
     *
     * @schema CommitConfigurationConnect#on-new-cert
     */
    readonly onNewCert?: CommitConfigurationConnectOnNewCert;
    /**
     * The name of the project to use when creating a new stream. Ignored when stream creation is not needed. By default the stream name is used.
     *
     * @schema CommitConfigurationConnect#project
     */
    readonly project?: string;
    /**
     * File containing the client certificate in PEM format, that should be presented to the proxy when making a request.
     *
     * @schema CommitConfigurationConnect#proxy-client-cert-file
     */
    readonly proxyClientCertFile?: string;
    /**
     * File containing the client certificate private key in PEM format, for the proxy-client-cert-file.
     *
     * @schema CommitConfigurationConnect#proxy-client-key-file
     */
    readonly proxyClientKeyFile?: string;
    /**
     * URL for a forward proxy to use when communicating with Coverity Connect.  Must be an https URL.
     *
     * @schema CommitConfigurationConnect#proxy-url
     */
    readonly proxyUrl?: string;
    /**
     * The name of the source control management system.
     *
     * @schema CommitConfigurationConnect#scm
     */
    readonly scm?: CommitConfigurationConnectScm;
    /**
     * Specifies how to select a reference snapshot to use for a comparison report.
     *
     * @schema CommitConfigurationConnect#snapshot
     */
    readonly snapshot?: SnapshotConfiguration;
    /**
     * The name of the stream to commit the results to.
     *
     * @schema CommitConfigurationConnect#stream
     */
    readonly stream: string;
    /**
     * Specifies how new defects should be handled.
     *
     * @schema CommitConfigurationConnect#triage
     */
    readonly triage?: CommitConfigurationConnectTriage;
    /**
     * Artifacts to upload following analysis when the analysis location is Connect.
     *
     * @schema CommitConfigurationConnect#upload-artifacts
     */
    readonly uploadArtifacts?: CommitConfigurationConnectUploadArtifacts;
    /**
     * Absolute URL of where to commit the Coverity Connect results.
     *
     * @schema CommitConfigurationConnect#url
     */
    readonly url: string;
    /**
     * A project version for the committed snapshot.
     *
     * @schema CommitConfigurationConnect#version
     */
    readonly version?: string;
}
/**
 * Converts an object of type 'CommitConfigurationConnect' to JSON representation.
 * @internal
 */
export declare function toJson_CommitConfigurationConnect(obj: CommitConfigurationConnect | undefined): Record<string, any> | undefined;
/**
 * Software Risk Manager configuration to use when storing defects in Software Risk Manager.
 *
 * @schema CommitConfigurationSrm
 */
export interface CommitConfigurationSrm {
    /**
     * The name of the branch to associate the analysis results with in Software Risk Manager.
     *
     * @schema CommitConfigurationSrm#branch
     */
    readonly branch?: string;
    /**
     * The name of the parent branch of the actual branch.
     *
     * @schema CommitConfigurationSrm#parent-branch
     */
    readonly parentBranch?: string;
    /**
     * The name of the project to associate the analysis results with in Software Risk Manager.
     *
     * @schema CommitConfigurationSrm#project-name
     */
    readonly projectName?: string;
    /**
     * The ID of the project to associate the analysis results with in Software Risk Manager.
     *
     * @schema CommitConfigurationSrm#project-id
     */
    readonly projectId?: number;
    /**
     * The name of the file to read the Software Risk Manager API key from. By default, the file located at $HOME/.bridge/srm-token.txt is used.
     *
     * @schema CommitConfigurationSrm#token-file
     */
    readonly tokenFile?: string;
    /**
     * The URL of the Software Risk Manager to use for the analysis (if doing a remote analysis) and the analysis results.
     *
     * @schema CommitConfigurationSrm#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'CommitConfigurationSrm' to JSON representation.
 * @internal
 */
export declare function toJson_CommitConfigurationSrm(obj: CommitConfigurationSrm | undefined): Record<string, any> | undefined;
/**
 * Local configuration to use when saving defects to the local file system.
 *
 * @schema CommitConfigurationLocal
 */
export interface CommitConfigurationLocal {
    /**
     * Directory (for "html" format) or file (for "json" format) in which to save defects.
     *
     * @schema CommitConfigurationLocal#path
     */
    readonly path: string;
    /**
     * Format in which to save defects. Either "html" or "json".
     *
     * @schema CommitConfigurationLocal#format
     */
    readonly format?: CommitConfigurationLocalFormat;
}
/**
 * Converts an object of type 'CommitConfigurationLocal' to JSON representation.
 * @internal
 */
export declare function toJson_CommitConfigurationLocal(obj: CommitConfigurationLocal | undefined): Record<string, any> | undefined;
/**
 * Specifies how web application security analysis should be done.
 *
 * @schema CheckerConfigurationWebappSecurity
 */
export interface CheckerConfigurationWebappSecurity {
    /**
     * Sets the web application checkers aggressiveness level.
     *
     * @schema CheckerConfigurationWebappSecurity#aggressiveness-level
     */
    readonly aggressivenessLevel?: CheckerConfigurationWebappSecurityAggressivenessLevel;
    /**
     * Enables the checkers that are used for web application security analysis.
     *
     * @schema CheckerConfigurationWebappSecurity#enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'CheckerConfigurationWebappSecurity' to JSON representation.
 * @internal
 */
export declare function toJson_CheckerConfigurationWebappSecurity(obj: CheckerConfigurationWebappSecurity | undefined): Record<string, any> | undefined;
/**
 * @schema specific-coding-standard-configuration
 */
export interface SpecificCodingStandardConfiguration {
    /**
     * This key specifies the coding standard configuration for the given coding standard. The actual type of this key is specific to the particular coding standard. This key is mutually exclusive with the "file" key. A temporary configuration file will be generated containing the in-line configuration and then passed to "cov-analyze" using the "--coding-standard-config <config_file>" option.
     *
     * @schema specific-coding-standard-configuration#config
     */
    readonly config?: ResolvedCodingStandardConfiguration;
    /**
     * This specifies the filename containing the configuration to use for the corresponding coding standard. This key is mutually exclusive with the "config" key.
     *
     * @schema specific-coding-standard-configuration#file
     */
    readonly file?: string;
    /**
     * This key specifies the name of a "pre-canned" coding standard configuration to use. The available pre-canned coding standard configurations depend on the coding standard in question. Refer to Coverity's documentation for details on the "pre-canned" configurations.
     *
     * @schema specific-coding-standard-configuration#pre-canned
     */
    readonly preCanned?: string;
}
/**
 * Converts an object of type 'SpecificCodingStandardConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_SpecificCodingStandardConfiguration(obj: SpecificCodingStandardConfiguration | undefined): Record<string, any> | undefined;
/**
 * Artifacts to upload following analysis when the analysis location is Connect.
 *
 * @schema AnalyzeConnectConfigurationUploadArtifacts
 */
export declare enum AnalyzeConnectConfigurationUploadArtifacts {
    /** All */
    ALL = "All",
    /** LogsOnly */
    LOGS_ONLY = "LogsOnly",
    /** None */
    NONE = "None",
    /** OnFailure */
    ON_FAILURE = "OnFailure"
}
/**
 * Security directives configuration to use during the analysis. This key is mutually exclusive with the "file" key and is specified in the case where the user wants to in-line the security directives configuration in the file.
 *
 * @schema DirectivesConfigurationConfig
 */
export interface DirectivesConfigurationConfig {
    /**
     * Specify a particular analysis behavior.
     *
     * @schema DirectivesConfigurationConfig#directives
     */
    readonly directives: any[];
    /**
     * Version of the directives format.
     *
     * @schema DirectivesConfigurationConfig#format_version
     */
    readonly formatVersion?: number;
    /**
     * Language or language family to which directives apply.
     *
     * @schema DirectivesConfigurationConfig#language
     */
    readonly language: string;
    /**
     * Must be the string "Coverity analysis configuration".
     *
     * @schema DirectivesConfigurationConfig#type
     */
    readonly type?: DirectivesConfigurationConfigType;
}
/**
 * Converts an object of type 'DirectivesConfigurationConfig' to JSON representation.
 * @internal
 */
export declare function toJson_DirectivesConfigurationConfig(obj: DirectivesConfigurationConfig | undefined): Record<string, any> | undefined;
/**
 * @schema SigmaConfigurationEnableCheckSet
 */
export declare enum SigmaConfigurationEnableCheckSet {
    /** all */
    ALL = "all",
    /** cis */
    CIS = "cis",
    /** default */
    DEFAULT = "default",
    /** empty */
    EMPTY = "empty"
}
/**
 * @schema parallel-translate-configuration
 */
export interface ParallelTranslateConfiguration {
    /**
     * Specifies whether cov-translate parallelization should be enabled.
     *
     * @schema parallel-translate-configuration#enabled
     */
    readonly enabled?: boolean;
    /**
     * Specifies the number of cov-emit processes to be run in parallel by cov-translate when multiple files are seen on a single native compiler invocation. A value of 0 will use the number of logical processors in the machine.
     *
     * @schema parallel-translate-configuration#processes
     */
    readonly processes?: number;
}
/**
 * Converts an object of type 'ParallelTranslateConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_ParallelTranslateConfiguration(obj: ParallelTranslateConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema webapp-archive-configuration
 */
export interface WebappArchiveConfiguration {
    /**
     * Specifies the path to the web application archive file or path to the directory containing the exploded web application.
     *
     * @schema webapp-archive-configuration#path
     */
    readonly path?: string;
    /**
     * Indicates whether the web-app should be checked to see if it is valid during capture. The validation check checks that there is a "/WEB-INF/web.xml" file and that > 20% of classes for the web application were captured.
     *
     * @schema webapp-archive-configuration#validate-webapp
     */
    readonly validateWebapp?: boolean;
}
/**
 * Converts an object of type 'WebappArchiveConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_WebappArchiveConfiguration(obj: WebappArchiveConfiguration | undefined): Record<string, any> | undefined;
/**
 * @schema LanguagesConfigurationExclude
 */
export declare enum LanguagesConfigurationExclude {
    /** apex */
    APEX = "apex",
    /** c-family */
    C_HYPHEN_FAMILY = "c-family",
    /** csharp */
    CSHARP = "csharp",
    /** dart */
    DART = "dart",
    /** go */
    GO = "go",
    /** java */
    JAVA = "java",
    /** javascript */
    JAVASCRIPT = "javascript",
    /** kotlin */
    KOTLIN = "kotlin",
    /** php */
    PHP = "php",
    /** python */
    PYTHON = "python",
    /** ruby */
    RUBY = "ruby",
    /** swift */
    SWIFT = "swift",
    /** vb */
    VB = "vb",
    /** configuration */
    CONFIGURATION = "configuration"
}
/**
 * @schema LanguagesConfigurationInclude
 */
export declare enum LanguagesConfigurationInclude {
    /** apex */
    APEX = "apex",
    /** c-family */
    C_HYPHEN_FAMILY = "c-family",
    /** csharp */
    CSHARP = "csharp",
    /** dart */
    DART = "dart",
    /** go */
    GO = "go",
    /** java */
    JAVA = "java",
    /** javascript */
    JAVASCRIPT = "javascript",
    /** kotlin */
    KOTLIN = "kotlin",
    /** php */
    PHP = "php",
    /** python */
    PYTHON = "python",
    /** ruby */
    RUBY = "ruby",
    /** swift */
    SWIFT = "swift",
    /** vb */
    VB = "vb",
    /** configuration */
    CONFIGURATION = "configuration"
}
/**
 * Indicates whether to trust self-signed certificates presented by Coverity Connect that are not currently trusted.
 *
 * @schema CommitConfigurationConnectOnNewCert
 */
export declare enum CommitConfigurationConnectOnNewCert {
    /** trust */
    TRUST = "trust",
    /** distrust */
    DISTRUST = "distrust"
}
/**
 * The name of the source control management system.
 *
 * @schema CommitConfigurationConnectScm
 */
export declare enum CommitConfigurationConnectScm {
    /** ads */
    ADS = "ads",
    /** clearcase */
    CLEARCASE = "clearcase",
    /** cvs */
    CVS = "cvs",
    /** git */
    GIT = "git",
    /** hg */
    HG = "hg",
    /** perforce */
    PERFORCE = "perforce",
    /** plastic */
    PLASTIC = "plastic",
    /** plastic-distributed */
    PLASTIC_HYPHEN_DISTRIBUTED = "plastic-distributed",
    /** svn */
    SVN = "svn",
    /** tfs */
    TFS = "tfs"
}
/**
 * @schema snapshot-configuration
 */
export interface SnapshotConfiguration {
    /**
     * Date and time of snapshot to use for comparison report. The value should be of the form "YYYY-MM-DDThh:mm:ss" where date and time are separated by a "T", optionally followed by a time zone specification consisting of either "Z" denoting UTC or a "+" or "-" character followed by colon-separated hours and minutes east of UTC. Example: "2023-12-27T13:21:05-08:00". If no time zone is specified, the local time zone is assumed. This key is mutually exclusive with the "id" and "reference" keys.
     *
     * @schema snapshot-configuration#date
     */
    readonly date?: string;
    /**
     * ID of snapshot to use for comparison report. This key is mutually exclusive with the "date" and "reference" keys.
     *
     * @schema snapshot-configuration#id
     */
    readonly id?: number;
    /**
     * One of "idir", "latest", or "scm". "idir" will use the snapshot created closest to, but not after, the creation date of the intermediate directory. "latest" will use the snapshot with the latest code-version date in the specified stream. "scm" will query the SCM to determine the version that was most recently checked out or updated, and then use the closest snapshot. This key is mutually exclusive with the "date" and "id" keys.
     *
     * @schema snapshot-configuration#reference
     */
    readonly reference?: any;
}
/**
 * Converts an object of type 'SnapshotConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_SnapshotConfiguration(obj: SnapshotConfiguration | undefined): Record<string, any> | undefined;
/**
 * Specifies how new defects should be handled.
 *
 * @schema CommitConfigurationConnectTriage
 */
export interface CommitConfigurationConnectTriage {
    /**
     * User to whom any new defects will be assigned. The specified user must already exist in the Coverity Connect database. The default is the current user.
     *
     * @schema CommitConfigurationConnectTriage#new-defect-owner
     */
    readonly newDefectOwner?: string;
    /**
     * Limit on the number of defects to assign to the specified user. If the number of discovered defects is more than the limit, then no assignment is done.
     *
     * @schema CommitConfigurationConnectTriage#new-defect-owner-limit
     */
    readonly newDefectOwnerLimit?: number;
    /**
     * If true, the owner for newly detected defects that exist locally is set to the specified user.
     *
     * @schema CommitConfigurationConnectTriage#set-new-defect-owner
     */
    readonly setNewDefectOwner?: boolean;
}
/**
 * Converts an object of type 'CommitConfigurationConnectTriage' to JSON representation.
 * @internal
 */
export declare function toJson_CommitConfigurationConnectTriage(obj: CommitConfigurationConnectTriage | undefined): Record<string, any> | undefined;
/**
 * Artifacts to upload following analysis when the analysis location is Connect.
 *
 * @schema CommitConfigurationConnectUploadArtifacts
 */
export declare enum CommitConfigurationConnectUploadArtifacts {
    /** All */
    ALL = "All",
    /** LogsOnly */
    LOGS_ONLY = "LogsOnly",
    /** None */
    NONE = "None",
    /** OnFailure */
    ON_FAILURE = "OnFailure"
}
/**
 * Format in which to save defects. Either "html" or "json".
 *
 * @schema CommitConfigurationLocalFormat
 */
export declare enum CommitConfigurationLocalFormat {
    /** html */
    HTML = "html",
    /** json */
    JSON = "json"
}
/**
 * Sets the web application checkers aggressiveness level.
 *
 * @schema CheckerConfigurationWebappSecurityAggressivenessLevel
 */
export declare enum CheckerConfigurationWebappSecurityAggressivenessLevel {
    /** low */
    LOW = "low",
    /** medium */
    MEDIUM = "medium",
    /** high */
    HIGH = "high"
}
/**
 * @schema resolved-coding-standard-configuration
 */
export interface ResolvedCodingStandardConfiguration {
    /**
     * List of deviations for this standard.
     *
     * @schema resolved-coding-standard-configuration#deviations
     */
    readonly deviations?: CodingStandardDeviation[];
    /**
     * Name of this code compliance configuration.
     *
     * @schema resolved-coding-standard-configuration#title
     */
    readonly title: string;
    /**
     * Version of this code compliance configuration.
     *
     * @schema resolved-coding-standard-configuration#version
     */
    readonly version?: string;
}
/**
 * Converts an object of type 'ResolvedCodingStandardConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_ResolvedCodingStandardConfiguration(obj: ResolvedCodingStandardConfiguration | undefined): Record<string, any> | undefined;
/**
 * Must be the string "Coverity analysis configuration".
 *
 * @schema DirectivesConfigurationConfigType
 */
export declare enum DirectivesConfigurationConfigType {
    /** Coverity analysis configuration */
    COVERITY_ANALYSIS_CONFIGURATION = "Coverity analysis configuration"
}
/**
 * @schema coding-standard-deviation
 */
export interface CodingStandardDeviation {
    /**
     * The name of the rule to deviate from.
     *
     * @schema coding-standard-deviation#deviation
     */
    readonly deviation: string;
    /**
     * The reason that the rule is being deviated from.
     *
     * @schema coding-standard-deviation#reason
     */
    readonly reason: string;
}
/**
 * Converts an object of type 'CodingStandardDeviation' to JSON representation.
 * @internal
 */
export declare function toJson_CodingStandardDeviation(obj: CodingStandardDeviation | undefined): Record<string, any> | undefined;
