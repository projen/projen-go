import { Component } from "../component";
import type { Project } from "../project";
import { YamlFile } from "../yaml";
import type { PolarisCoveritySchema } from "./coverity-config";
/**
 * Options for `PolarisCoverity`.
 */
export interface PolarisCoverityOptions extends PolarisCoveritySchema {
}
/**
 * Manages `coverity.yml`, the configuration file for Coverity on Polaris
 * (Black Duck's SAST scanning tool).
 *
 * @see https://docs.blackduck.com/r/cov_polaris/latest/coverity-on-polaris/configuration-file-schema.html
 */
export declare class PolarisCoverity extends Component {
    /**
     * The YAML file for the Coverity on Polaris configuration.
     */
    readonly file: YamlFile;
    constructor(project: Project, options: PolarisCoverityOptions);
}
