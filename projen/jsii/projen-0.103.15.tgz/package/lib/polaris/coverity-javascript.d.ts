import { PolarisCoverity } from "./coverity";
import type { PolarisCoverityOptions } from "./coverity";
import type { Project } from "../project";
/**
 * Options for `PolarisCoverityJavascript`.
 *
 * Extends base options with JavaScript/TypeScript-specific defaults.
 */
export interface PolarisCoverityJavascriptOptions extends PolarisCoverityOptions {
}
/**
 * A Coverity on Polaris configuration preset for JavaScript/TypeScript
 * projects.
 *
 * Provides sensible defaults for JavaScript/TypeScript analysis:
 * - `capture.languages.include` = `[javascript]`
 * - `capture.files.excludeRegex` excludes `node_modules`, `lib`, `dist`,
 *   `coverage` and other build artifacts, based on the paths projen's
 *   `TypeScriptProject` excludes from git by default
 *
 * All defaults can be overridden via options. Nested options (e.g.
 * `capture`) are deep-merged with the defaults, so overriding one nested
 * field does not drop the other defaults in that subtree.
 *
 * @example
 * new PolarisJavascriptCoverity(project, {
 *   commit: {},
 * });
 */
export declare class PolarisJavascriptCoverity extends PolarisCoverity {
    constructor(project: Project, options: PolarisCoverityJavascriptOptions);
}
