import type { IConstruct } from "constructs";
import { SonarqubeProperties } from "./sonarqube";
import type { SonarqubePropertiesOptions } from "./sonarqube";
/**
 * Options for `SonarqubeTypescriptProperties`.
 *
 * Extends base options with TypeScript-specific defaults.
 */
export interface SonarqubeTypescriptPropertiesOptions extends SonarqubePropertiesOptions {
}
/**
 * A SonarQube configuration preset for TypeScript projects.
 *
 * Provides sensible defaults for TypeScript analysis:
 * - `sonar.language` = `ts`
 * - `sonar.sources` = `src`
 * - `sonar.tests` = `test`
 * - `sonar.sourceEncoding` = `UTF-8`
 * - `sonar.profile` = `Sonar Way`
 * - `sonar.scm.provider` = `git`
 * - `sonar.typescript.tsconfigPath` = `tsconfig.json`
 * - Typical exclusions for `node_modules`, `coverage`, test files
 * - `sonar.javascript.lcov.reportPaths` = `coverage/lcov.info`
 *
 * All defaults can be overridden via options. Nested options (e.g. `coverage`,
 * `javascript`) are deep-merged with the defaults, so overriding one nested
 * field does not drop the other defaults in that subtree.
 *
 * @example
 * new SonarqubeTypescriptProperties(project, {
 *   projectKey: 'my-org_my-ts-project',
 * });
 */
export declare class SonarqubeTypescriptProperties extends SonarqubeProperties {
    constructor(scope: IConstruct, options: SonarqubeTypescriptPropertiesOptions);
}
