/**
 * Feature flags as of v1.130.0
 */
export declare const FEATURE_FLAGS_V1: {
    "aws-cdk:enableDiffNoFail": boolean;
    "@aws-cdk/aws-apigateway:usagePlanKeyOrderInsensitiveId": boolean;
    "@aws-cdk/core:enableStackNameDuplicates": boolean;
    "@aws-cdk/core:stackRelativeExports": boolean;
    "@aws-cdk/aws-ecr-assets:dockerIgnoreSupport": boolean;
    "@aws-cdk/aws-secretsmanager:parseOwnedSecretName": boolean;
    "@aws-cdk/aws-kms:defaultKeyPolicies": boolean;
    "@aws-cdk/aws-s3:grantWriteWithoutAcl": boolean;
    "@aws-cdk/aws-ecs-patterns:removeDefaultDesiredCount": boolean;
    "@aws-cdk/aws-rds:lowercaseDbIdentifier": boolean;
    "@aws-cdk/aws-efs:defaultEncryptionAtRest": boolean;
    "@aws-cdk/aws-lambda:recognizeVersionProps": boolean;
    "@aws-cdk/aws-cloudfront:defaultSecurityPolicyTLSv1.2_2021": boolean;
};
/**
 * Feature flags for V2
 */
export declare const FEATURE_FLAGS_V2: {
    "@aws-cdk/aws-signer:signingProfileNamePassedToCfn": boolean;
    "@aws-cdk/aws-ecs-patterns:secGroupsDisablesImplicitOpenListener": boolean;
    "@aws-cdk/aws-lambda:recognizeLayerVersion": boolean;
    "@aws-cdk/core:checkSecretUsage": boolean;
    "@aws-cdk/core:target-partitions": string[];
    "@aws-cdk-containers/ecs-service-extensions:enableDefaultLogDriver": boolean;
    "@aws-cdk/aws-ec2:uniqueImdsv2TemplateName": boolean;
    "@aws-cdk/aws-ecs:arnFormatIncludesClusterName": boolean;
    "@aws-cdk/aws-iam:minimizePolicies": boolean;
    "@aws-cdk/core:validateSnapshotRemovalPolicy": boolean;
    "@aws-cdk/aws-codepipeline:crossAccountKeyAliasStackSafeResourceName": boolean;
    "@aws-cdk/aws-s3:createDefaultLoggingPolicy": boolean;
    "@aws-cdk/aws-sns-subscriptions:restrictSqsDescryption": boolean;
    "@aws-cdk/aws-apigateway:disableCloudWatchRole": boolean;
    "@aws-cdk/core:enablePartitionLiterals": boolean;
    "@aws-cdk/aws-events:eventsTargetQueueSameAccount": boolean;
    "@aws-cdk/aws-ecs:disableExplicitDeploymentControllerForCircuitBreaker": boolean;
    "@aws-cdk/aws-iam:importedRoleStackSafeDefaultPolicyName": boolean;
    "@aws-cdk/aws-s3:serverAccessLogsUseBucketPolicy": boolean;
    "@aws-cdk/aws-route53-patters:useCertificate": boolean;
    "@aws-cdk/customresources:installLatestAwsSdkDefault": boolean;
    "@aws-cdk/aws-rds:databaseProxyUniqueResourceName": boolean;
    "@aws-cdk/aws-codedeploy:removeAlarmsFromDeploymentGroup": boolean;
    "@aws-cdk/aws-apigateway:authorizerChangeDeploymentLogicalId": boolean;
    "@aws-cdk/aws-ec2:launchTemplateDefaultUserData": boolean;
    "@aws-cdk/aws-secretsmanager:useAttachedSecretResourcePolicyForSecretTargetAttachments": boolean;
    "@aws-cdk/aws-redshift:columnId": boolean;
    "@aws-cdk/aws-stepfunctions-tasks:enableEmrServicePolicyV2": boolean;
    "@aws-cdk/aws-ec2:restrictDefaultSecurityGroup": boolean;
    "@aws-cdk/aws-apigateway:requestValidatorUniqueId": boolean;
    "@aws-cdk/aws-kms:aliasNameRef": boolean;
    "@aws-cdk/aws-kms:applyImportedAliasPermissionsToPrincipal": boolean;
    "@aws-cdk/aws-autoscaling:generateLaunchTemplateInsteadOfLaunchConfig": boolean;
    "@aws-cdk/core:includePrefixInUniqueNameGeneration": boolean;
    "@aws-cdk/aws-efs:denyAnonymousAccess": boolean;
    "@aws-cdk/aws-opensearchservice:enableOpensearchMultiAzWithStandby": boolean;
    "@aws-cdk/aws-lambda-nodejs:useLatestRuntimeVersion": boolean;
    "@aws-cdk/aws-efs:mountTargetOrderInsensitiveLogicalId": boolean;
    "@aws-cdk/aws-rds:auroraClusterChangeScopeOfInstanceParameterGroupWithEachParameters": boolean;
    "@aws-cdk/aws-appsync:useArnForSourceApiAssociationIdentifier": boolean;
    "@aws-cdk/aws-rds:preventRenderingDeprecatedCredentials": boolean;
    "@aws-cdk/aws-codepipeline-actions:useNewDefaultBranchForCodeCommitSource": boolean;
    "@aws-cdk/aws-cloudwatch-actions:changeLambdaPermissionLogicalIdForLambdaAction": boolean;
    "@aws-cdk/aws-codepipeline:crossAccountKeysDefaultValueToFalse": boolean;
    "@aws-cdk/aws-codepipeline:defaultPipelineTypeToV2": boolean;
    "@aws-cdk/aws-kms:reduceCrossAccountRegionPolicyScope": boolean;
    "@aws-cdk/aws-eks:nodegroupNameAttribute": boolean;
    "@aws-cdk/aws-eks:useNativeOidcProvider": boolean;
    "@aws-cdk/aws-ec2:ebsDefaultGp3Volume": boolean;
    "@aws-cdk/aws-ecs:removeDefaultDeploymentAlarm": boolean;
    "@aws-cdk/custom-resources:logApiResponseDataPropertyTrueDefault": boolean;
    "@aws-cdk/aws-s3:keepNotificationInImportedBucket": boolean;
    "@aws-cdk/core:explicitStackTags": boolean;
    "@aws-cdk/aws-ecs:reduceEc2FargateCloudWatchPermissions": boolean;
    "@aws-cdk/aws-dynamodb:resourcePolicyPerReplica": boolean;
    "@aws-cdk/aws-ec2:ec2SumTImeoutEnabled": boolean;
    "@aws-cdk/aws-appsync:appSyncGraphQLAPIScopeLambdaPermission": boolean;
    "@aws-cdk/aws-rds:setCorrectValueForDatabaseInstanceReadReplicaInstanceResourceId": boolean;
    "@aws-cdk/core:cfnIncludeRejectComplexResourceUpdateCreatePolicyIntrinsics": boolean;
    "@aws-cdk/aws-lambda-nodejs:sdkV3ExcludeSmithyPackages": boolean;
    "@aws-cdk/aws-stepfunctions-tasks:fixRunEcsTaskPolicy": boolean;
    "@aws-cdk/aws-ec2:bastionHostUseAmazonLinux2023ByDefault": boolean;
    "@aws-cdk/aws-route53-targets:userPoolDomainNameMethodWithoutCustomResource": boolean;
    "@aws-cdk/aws-elasticloadbalancingV2:albDualstackWithoutPublicIpv4SecurityGroupRulesDefault": boolean;
    "@aws-cdk/aws-iam:oidcRejectUnauthorizedConnections": boolean;
    "@aws-cdk/core:enableAdditionalMetadataCollection": boolean;
    "@aws-cdk/aws-lambda:createNewPoliciesWithAddToRolePolicy": boolean;
    "@aws-cdk/aws-s3:setUniqueReplicationRoleName": boolean;
    "@aws-cdk/aws-events:requireEventBusPolicySid": boolean;
    "@aws-cdk/core:aspectPrioritiesMutating": boolean;
    "@aws-cdk/aws-dynamodb:retainTableReplica": boolean;
    "@aws-cdk/aws-stepfunctions:useDistributedMapResultWriterV2": boolean;
    "@aws-cdk/s3-notifications:addS3TrustKeyPolicyForSnsSubscriptions": boolean;
    "@aws-cdk/aws-ec2:requirePrivateSubnetsForEgressOnlyInternetGateway": boolean;
    "@aws-cdk/aws-s3:publicAccessBlockedByDefault": boolean;
    "@aws-cdk/aws-lambda:useCdkManagedLogGroup": boolean;
    "@aws-cdk/aws-elasticloadbalancingv2:networkLoadBalancerWithSecurityGroupByDefault": boolean;
    "@aws-cdk/aws-ecs-patterns:uniqueTargetGroupId": boolean;
    "@aws-cdk/aws-route53-patterns:useDistribution": boolean;
    "@aws-cdk/aws-cloudfront:defaultFunctionRuntimeV2_0": boolean;
    "@aws-cdk/aws-elasticloadbalancingv2:usePostQuantumTlsPolicy": boolean;
};
/**
 * Suffix for AWS Lambda handlers.
 */
export declare const TYPESCRIPT_LAMBDA_EXT = ".lambda.ts";
/**
 * Suffix for AWS Edge Lambda handlers.
 */
export declare const TYPESCRIPT_EDGE_LAMBDA_EXT = ".edge-lambda.ts";
/**
 * Suffix for AWS singleton Lambda handlers.
 */
export declare const TYPESCRIPT_SINGLETON_LAMBDA_EXT = ".singleton-lambda.ts";
/**
 * Suffix for AWS Lambda Extensions.
 */
export declare const TYPESCRIPT_LAMBDA_EXTENSION_EXT = ".lambda-extension.ts";
/**
 * Converts the given path string to posix if it wasn't already.
 */
export declare function convertToPosixPath(p: string): string;
/**
 * Creates a deterministic UUID from project name and lambda entrypoint.
 */
export declare function toDeterministicSingletonUuid(projectName: string, entrypoint: string): string;
