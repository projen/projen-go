import { IConstruct } from "constructs";
import { TomlFile } from "../toml";
import { PyprojectToml } from "./pyproject-toml";
import { IResolver } from "../file";
/**
 * Represents configuration of a pyproject.toml file
 *
 * @see https://packaging.python.org/en/latest/guides/writing-pyproject-toml/
 */
export declare class PyprojectTomlFile extends TomlFile {
    constructor(scope: IConstruct, config: PyprojectToml);
    protected synthesizeContent(resolver: IResolver): string | undefined;
}
