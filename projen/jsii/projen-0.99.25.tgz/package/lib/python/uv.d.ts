import { IConstruct } from "constructs";
import { IPythonDeps } from "./python-deps";
import { IPythonEnv } from "./python-env";
import { IPythonPackaging } from "./python-packaging";
import { Component } from "../component";
import { UvConfiguration } from "./uv-config";
import { Task } from "../task";
import { BuildSystem, PyprojectTomlProject } from "./pyproject-toml";
import { PyprojectTomlFile } from "./pyproject-toml-file";
import { PythonExecutableOptions } from "./python-project";
/**
 * Options for UV project
 */
export interface UvOptions extends PythonExecutableOptions {
    /**
     * The project's basic metadata configuration.
     */
    readonly project?: PyprojectTomlProject;
    /**
     * Declares any Python level dependencies that must be installed in order to run the project’s build system successfully.
     *
     * @default - no build system
     */
    readonly buildSystem?: BuildSystem;
    /**
     * The configuration and metadata for uv.
     */
    readonly uv?: UvConfiguration;
}
/**
 * Manage project dependencies, virtual environments, and packaging through uv.
 */
export declare class Uv extends Component implements IPythonDeps, IPythonEnv, IPythonPackaging {
    /**
     * The `pyproject.toml` file
     */
    readonly file: PyprojectTomlFile;
    readonly installTask: Task;
    readonly installCiTask: Task;
    readonly publishTask: Task;
    readonly publishTestTask: Task;
    private readonly venvPython;
    constructor(scope: IConstruct, options: UvOptions);
    /** Formats dependencies in UV style. */
    private formatDependency;
    private getDependencies;
    private synthDependencies;
    private synthDependencyGroups;
    addDependency(spec: string): void;
    addDevDependency(spec: string): void;
    setupEnvironment(): void;
    installDependencies(): void;
}
