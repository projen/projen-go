import { DockerComposeService } from "./docker-compose-service";
export declare function renderDockerComposeFile(serviceDescriptions: Record<string, DockerComposeService>, version?: string): object;
