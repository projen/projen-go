import { ICompareString } from "../compare";
import { Component } from "../component";
import { NodeProject } from "../javascript";
import { ObjectFile } from "../object-file";
import { Project } from "../project";
import { Task } from "../task";
export interface EslintOptions {
    /**
     * Path to `tsconfig.json` which should be used by eslint.
     * @default "./tsconfig.json"
     */
    readonly tsconfigPath?: string;
    /**
     * Files or glob patterns or directories with source files to lint (e.g. [ "src" ])
     */
    readonly dirs: string[];
    /**
     * Files or glob patterns or directories with source files that include tests and build tools
     *
     * These sources are linted but may also import packages from `devDependencies`.
     * @default []
     */
    readonly devdirs?: string[];
    /**
     * File types that should be linted (e.g. [ ".js", ".ts" ])
     * @default [".ts"]
     */
    readonly fileExtensions?: string[];
    /**
     * Options for eslint command executed by eslint task
     */
    readonly commandOptions?: EslintCommandOptions;
    /**
     * List of file patterns that should not be linted, using the same syntax
     * as .gitignore patterns.
     *
     * @default [ '*.js', '*.d.ts', 'node_modules/', '*.generated.ts', 'coverage' ]
     */
    readonly ignorePatterns?: string[];
    /**
     * Projenrc file to lint. Use empty string to disable.
     * @default "projenrc.js"
     * @deprecated provide as `devdirs`
     */
    readonly lintProjenRcFile?: string;
    /**
     * Should we lint .projenrc.js
     *
     * @default true
     * @deprecated set to `false` to remove any automatic rules and add manually
     */
    readonly lintProjenRc?: boolean;
    /**
     * Enable prettier for code formatting
     * @default false
     */
    readonly prettier?: boolean;
    /**
     * The extends array in eslint is order dependent.
     * This option allows to sort the extends array in any way seen fit.
     *
     * @default - Use known ESLint best practices to place "prettier" plugins at the end of the array
     */
    readonly sortExtends?: ICompareString;
    /**
     * Enable import alias for module paths
     * @default undefined
     */
    readonly aliasMap?: {
        [key: string]: string;
    };
    /**
     * Enable import alias for module paths
     * @default undefined
     */
    readonly aliasExtensions?: string[];
    /**
     * Always try to resolve types under `<root>@types` directory even it doesn't contain any source code.
     * This prevents `import/no-unresolved` eslint errors when importing a `@types/*` module that would otherwise remain unresolved.
     * @default true
     */
    readonly tsAlwaysTryTypes?: boolean;
    /**
     * Write eslint configuration as YAML instead of JSON
     * @default false
     */
    readonly yaml?: boolean;
}
export interface EslintCommandOptions {
    /**
     * Whether to fix eslint issues when running the eslint task
     * @default true
     */
    readonly fix?: boolean;
    /**
     * Extra flag arguments to pass to eslint command
     */
    readonly extraArgs?: string[];
}
/**
 * eslint rules override
 */
export interface EslintOverride {
    /**
     * Files or file patterns on which to apply the override
     */
    readonly files: string[];
    /**
     * Pattern(s) to exclude from this override.
     * If a file matches any of the excluded patterns, the configuration won’t apply.
     */
    readonly excludedFiles?: string[];
    /**
     * The overridden rules
     */
    readonly rules?: {
        [rule: string]: any;
    };
    /**
     * The overridden parser
     */
    readonly parser?: string;
    /**
     * Config(s) to extend in this override
     */
    readonly extends?: string[];
    /**
     * `plugins` override
     */
    readonly plugins?: string[];
}
/**
 * Represents eslint configuration.
 */
export declare class Eslint extends Component {
    /**
     * Returns the singleton Eslint component of a project or undefined if there is none.
     */
    static of(project: Project): Eslint | undefined;
    /**
     * The underlying config file
     */
    readonly file: ObjectFile;
    /**
     * eslint rules.
     */
    readonly rules: {
        [rule: string]: any;
    };
    /**
     * eslint overrides.
     */
    readonly overrides: EslintOverride[];
    /**
     * eslint task.
     */
    readonly eslintTask: Task;
    /**
     * Direct access to the eslint configuration (escape hatch)
     */
    readonly config: any;
    /**
     * File patterns that should not be linted
     */
    readonly ignorePatterns: string[];
    private _formattingRules;
    private readonly _allowDevDeps;
    private readonly _plugins;
    private readonly _extends;
    private readonly _fileExtensions;
    private readonly _flagArgs;
    private readonly _lintPatterns;
    private readonly nodeProject;
    private readonly sortExtends;
    constructor(project: NodeProject, options: EslintOptions);
    /**
     * Returns an immutable copy of the lintPatterns being used by this eslint configuration.
     */
    get lintPatterns(): string[];
    /**
     * Add a file, glob pattern or directory with source files to lint (e.g. [ "src" ])
     */
    addLintPattern(pattern: string): void;
    /**
     * Add an eslint rule.
     */
    addRules(rules: {
        [rule: string]: any;
    }): void;
    /**
     * Adds an eslint plugin
     * @param plugins The names of plugins to add
     */
    addPlugins(...plugins: string[]): void;
    /**
     * Add an eslint override.
     */
    addOverride(override: EslintOverride): void;
    /**
     * Do not lint these files.
     */
    addIgnorePattern(pattern: string): void;
    /**
     * Adds an `extends` item to the eslint configuration.
     * @param extendList The list of "extends" to add.
     */
    addExtends(...extendList: string[]): void;
    /**
     * Add a glob file pattern which allows importing dev dependencies.
     * @param pattern glob pattern.
     */
    allowDevDeps(pattern: string): void;
    /**
     * Enables prettier for code formatting.
     */
    private enablePrettier;
    private renderDevDepsAllowList;
    /**
     * Update the task with the current list of lint patterns and file extensions
     */
    private updateTask;
    /**
     * In case of external editing of the eslint task step, we preserve those changes.
     * Otherwise, we return the default task step options.
     *
     * @param taskExecCommand The command that the ESLint tasks executes
     * @returns Either the externally edited, or the default task step options
     */
    private buildTaskStepOptions;
}
