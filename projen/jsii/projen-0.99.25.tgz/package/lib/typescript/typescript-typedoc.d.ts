import { TypeScriptProject } from "../typescript";
/**
  Adds a simple Typescript documentation generator
 */
export declare class TypedocDocgen {
    constructor(project: TypeScriptProject);
}
