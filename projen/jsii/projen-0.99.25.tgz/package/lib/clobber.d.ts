import { Component } from "./component";
import { Project } from "./project";
export declare class Clobber extends Component {
    constructor(project: Project);
}
