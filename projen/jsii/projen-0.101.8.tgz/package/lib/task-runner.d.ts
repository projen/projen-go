import type { IConstruct } from "constructs";
import { Component } from "./component";
import type { Task } from "./task";
import type { TasksManifest } from "./task-model";
export interface ITaskRunner {
    /**
     * Runs a task.
     * @param task The task to run.
     * @param args List of arguments passed to the task, if supported.
     */
    runTask(task: Task, args?: Array<string | number>): void;
}
export declare class ProjenTaskRunner extends Component implements ITaskRunner {
    /**
     * The project-relative path of the tasks manifest file.
     */
    static readonly MANIFEST_FILE: string;
    constructor(scope: IConstruct, id?: string);
    /**
     * Runs a task by shelling out to the projen CLI. The CLI owns the task
     * runtime, which keeps `src/` decoupled from `src/cli/`.
     */
    runTask(task: Task, args?: Array<string | number>): void;
    protected get tasksManifest(): TasksManifest;
}
