import type { IConstruct } from "constructs";
import type { IResolver } from "./file";
import type { ObjectFileOptions } from "./object-file";
import { ObjectFile } from "./object-file";
/**
 * Options for `JsonFile`.
 */
export interface JsonFileOptions extends ObjectFileOptions {
    /**
     * Adds a newline at the end of the file.
     * @default true
     */
    readonly newline?: boolean;
    /**
     * Allow the use of comments in this file.
     * @default - false for .json files, true for .json5 and .jsonc files
     */
    readonly allowComments?: boolean;
}
/**
 * Represents a JSON file.
 */
export declare class JsonFile extends ObjectFile {
    private readonly newline;
    private allowComments;
    /**
     * Indicates if the files supports comments.
     */
    get supportsComments(): boolean;
    constructor(scope: IConstruct, filePath: string, options: JsonFileOptions);
    /**
     * Helper to enable/disable supportsComments from other parts of the codebase.
     */
    private configureComments;
    protected synthesizeContent(resolver: IResolver): string | undefined;
}
