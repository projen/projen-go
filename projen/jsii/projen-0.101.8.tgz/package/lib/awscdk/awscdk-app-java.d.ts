import type { AwsCdkDeps, AwsCdkDepsCommonOptions } from "./awscdk-deps";
import type { CdkConfigCommonOptions } from "./cdk-config";
import { CdkConfig } from "./cdk-config";
import { CdkTasks } from "./cdk-tasks";
import type { JavaProjectOptions } from "../java";
import { JavaProject } from "../java";
export interface AwsCdkJavaAppOptions extends JavaProjectOptions, CdkConfigCommonOptions, AwsCdkDepsCommonOptions {
    /**
     * The name of the Java class with the static `main()` method. This method
     * should call `app.synth()` on the CDK app.
     *
     * @default "org.acme.MyApp"
     */
    readonly mainClass: string;
}
/**
 * AWS CDK app in Java.
 *
 * @pjid awscdk-app-java
 */
export declare class AwsCdkJavaApp extends JavaProject {
    /**
     * The `cdk.json` file.
     */
    readonly cdkConfig: CdkConfig;
    /**
     * CDK dependency management helper class
     */
    readonly cdkDeps: AwsCdkDeps;
    /**
     * The full name of the main class of the java app (package.Class).
     */
    readonly mainClass: string;
    /**
     * CDK tasks.
     */
    readonly cdkTasks: CdkTasks;
    /**
     * The name of the Java package that includes the main class.
     */
    readonly mainPackage: string;
    /**
     * The name of the Java class with the static `main()` method.
     */
    readonly mainClassName: string;
    constructor(options: AwsCdkJavaAppOptions);
    private addSample;
}
