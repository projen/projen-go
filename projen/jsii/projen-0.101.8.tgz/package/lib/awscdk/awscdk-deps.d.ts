import { Component } from "../component";
import { DependencyType } from "../dependencies";
import type { Project } from "../project";
/**
 * Options for `AwsCdkDeps`
 */
export interface AwsCdkDepsCommonOptions {
    /**
     * Minimum version of the AWS CDK to depend on.
     *
     * @default "2.189.1"
     */
    readonly cdkVersion: string;
    /**
     * Version range of the AWS CDK CLI to depend on.
     *
     * Can be either a specific version, or an NPM version range.
     *
     * By default, the latest 2.x version will be installed; you can use this
     * option to restrict it to a specific version or version range.
     *
     * @default "^2"
     */
    readonly cdkCliVersion?: string;
    /**
     * Minimum version of the `constructs` library to depend on.
     *
     * @default - for CDK 1.x the default is "3.2.27", for CDK 2.x the default is
     * "10.5.1".
     */
    readonly constructsVersion?: string;
    /**
     * Use pinned version instead of caret version for CDK.
     *
     * You can use this to prevent mixed versions for your CDK dependencies and to prevent auto-updates.
     * If you use experimental features this will let you define the moment you include breaking changes.
     */
    readonly cdkVersionPinning?: boolean;
}
export interface AwsCdkDepsOptions extends AwsCdkDepsCommonOptions {
    /**
     * The type of dependency to use for runtime AWS CDK and `constructs` modules.
     *
     * For libraries, use peer dependencies and for apps use runtime dependencies.
     */
    readonly dependencyType: DependencyType;
}
/**
 * Language-specific AWS CDK package names.
 */
export interface AwsCdkPackageNames {
    /**
     * Fully qualified name of the core framework package for CDKv2
     */
    readonly coreV2: string;
    /**
     * Fully qualified name of the constructs library package
     */
    readonly constructs: string;
}
/**
 * Manages dependencies on the AWS CDK.
 */
export declare abstract class AwsCdkDeps extends Component {
    /**
     * The dependency requirement for AWS CDK (e.g. `^2.0.0`).
     */
    readonly cdkVersion: string;
    /**
     * The dependency requirement for the CDK CLI (e.g. '^2.3.4').
     *
     * Will return `^2` if the version was unspecified by the user.
     */
    readonly cdkCliVersion: string;
    /**
     * The minimum version of the AWS CDK (e.g. `2.0.0`).
     */
    readonly cdkMinimumVersion: string;
    /**
     * The major version of the AWS CDK (e.g. 1, 2, ...)
     */
    readonly cdkMajorVersion: number;
    private readonly dependencyType;
    private readonly _packageNames;
    constructor(project: Project, options: AwsCdkDepsOptions);
    preSynthesize(): void;
    private addConstructsDependency;
    /**
     * Adds a dependency on the AWS CDK framework (`aws-cdk-lib` for V2).
     */
    private addFrameworkDependency;
    /**
     * Return a configuration object with information about package naming in various languages
     */
    protected abstract packageNames(): AwsCdkPackageNames;
}
