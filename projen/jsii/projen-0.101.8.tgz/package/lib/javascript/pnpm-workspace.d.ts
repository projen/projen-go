import { Component } from "../component";
import type { Project } from "../project";
import type { PnpmWorkspaceYamlSchema } from "./pnpm-workspace-config";
/**
 * Options for `PnpmWorkspaceYaml`.
 *
 * @see https://pnpm.io/pnpm-workspace_yaml
 */
export interface PnpmWorkspaceYamlOptions extends PnpmWorkspaceYamlSchema {
}
/**
 * Represents a `pnpm-workspace.yaml` file.
 *
 * @see https://pnpm.io/pnpm-workspace_yaml
 */
export declare class PnpmWorkspaceYaml extends Component {
    /**
     * Returns the `PnpmWorkspaceYaml` instance associated with a project or
     * `undefined` if there is none.
     */
    static of(project: Project): PnpmWorkspaceYaml | undefined;
    constructor(project: Project, options?: PnpmWorkspaceYamlOptions);
}
