/**
 * Recursively determines whether a directory contains at least one file,
 * optionally filtered by file extension.
 *
 * @param dir The directory to search. If it does not exist, `false` is
 * returned.
 * @param ext Optional file extension (e.g. `".ts"`) used to filter files. When
 * provided, only files whose name ends with this extension are considered.
 * @returns `true` if a matching file is found anywhere in the tree, otherwise
 * `false` (including when the directory only contains empty subdirectories).
 */
export declare function dirContainsFile(dir: string, ext?: string): boolean;
