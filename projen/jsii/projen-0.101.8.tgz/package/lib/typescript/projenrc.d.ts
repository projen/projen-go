import { TypescriptConfig } from "../javascript";
import type { TypeScriptProject } from "./typescript";
import { ProjenrcFile } from "../projenrc";
import { TypeScriptRunner } from "./typescript-runner";
export interface ProjenrcOptions {
    /**
     * The name of the projenrc file.
     * @default ".projenrc.ts"
     */
    readonly filename?: string;
    /**
     * A directory tree that may contain *.ts files that can be referenced from
     * your projenrc typescript file.
     *
     * @default "projenrc"
     */
    readonly projenCodeDir?: string;
    /**
     * Whether to use `SWC` for ts-node.
     *
     * @default false
     * @deprecated Use `runner: TypeScriptRunner.tsNode({ swc: true })` instead.
     */
    readonly swc?: boolean;
    /**
     * The runner to use for executing TypeScript files.
     *
     * @default - the project's runner
     */
    readonly runner?: TypeScriptRunner;
}
/**
 * A projenrc file written in TypeScript
 *
 * This component is used within TypeScriptProject.
 */
export declare class Projenrc extends ProjenrcFile {
    readonly filePath: string;
    readonly tsconfig: TypescriptConfig;
    private readonly _projenCodeDir;
    private readonly _tsProject;
    private readonly _runner;
    constructor(project: TypeScriptProject, options?: ProjenrcOptions);
    private addDefaultTask;
    private getRunner;
    preSynthesize(): void;
    private generateProjenrc;
}
