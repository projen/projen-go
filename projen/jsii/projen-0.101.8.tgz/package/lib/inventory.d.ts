type JsiiTypes = {
    [name: string]: JsiiType;
};
export interface ProjectOption {
    readonly name: string;
    readonly fqn?: string;
    readonly docs?: string;
    readonly default?: string;
    readonly optional?: boolean;
    readonly deprecated?: boolean;
    readonly featured?: boolean;
    readonly initialValue?: string;
    readonly type: any;
}
export interface ProjectType {
    readonly moduleName: string;
    readonly pjid: string;
    readonly fqn: string;
    readonly typename: string;
    readonly options: ProjectOption[];
    readonly docs?: string;
    readonly docsurl: string;
}
export interface InventoryProjectOption extends ProjectOption {
    readonly path: string[];
    readonly parent: string;
    readonly switch: string;
    readonly jsonLike?: boolean;
    /** Simple type name, e.g. "string", "boolean", "number", "EslintOptions", "MyEnum". Collections are "unknown" */
    readonly simpleType: string;
    /** Full JSII type, e.g. { primitive: "string" } or { collection: { elementtype: { primitive: 'string' }, kind: 'map' } } */
    readonly type: JsiiPropertyType;
    readonly kind?: "class" | "enum" | "interface";
}
export interface InventoryProjectType extends ProjectType {
    moduleName: string;
    pjid: string;
    fqn: string;
    typename: string;
    options: InventoryProjectOption[];
    docs?: string;
    docsurl: string;
}
interface JsiiType {
    name: string;
    assembly: string;
    kind: string;
    abstract?: boolean;
    base?: string;
    fqn: string;
    interfaces?: string[];
    initializer?: {
        parameters?: Array<{
            name: string;
            type?: {
                fqn?: string;
            };
        }>;
    };
    properties?: Array<{
        name: string;
        docs: {
            summary?: string;
            default?: string;
            deprecated?: string;
            stability?: string;
            custom?: {
                [name: string]: string;
            };
        };
        optional?: boolean;
        type?: JsiiPropertyType;
    }>;
    docs?: {
        summary?: string;
        deprecated?: string;
        custom?: {
            pjid?: string;
            pjnew?: string;
        };
    };
}
export interface JsiiPropertyType {
    primitive?: string;
    fqn?: string;
    collection?: {
        elementtype: JsiiPropertyType;
        kind: string;
    };
}
/**
 * Returns a list of project types exported the modules defined in `moduleDirs`.
 * This list will always also include the built-in projen project types.
 * Modules without a .jsii manifest are skipped.
 *
 * @param moduleDirs A list of npm module directories
 */
export declare function discover(...moduleDirs: string[]): InventoryProjectType[];
export declare function readManifest(dir: string): any;
export declare function resolveProjectType(projectFqn: string): InventoryProjectType;
export declare function toProjectType(jsii: JsiiTypes, fqn: string): InventoryProjectType;
export declare function readJsiiManifest(jsiiFqn: string): any;
export {};
