import type { TaskRuntime } from "../task-runtime";
export interface SynthOptions {
    /**
     * Execute post synthesis commands.
     * @default true
     */
    readonly post?: boolean;
    /**
     * Start watching .projenrc.js and re-synth when changed.
     * @default false
     */
    readonly watch?: boolean;
}
export declare function synth(runtime: TaskRuntime, options: SynthOptions): Promise<void>;
