import type { TasksManifest, TaskSpec } from "../task-model";
/**
 * The runtime component of the tasks engine.
 */
export declare class TaskRuntime {
    /**
     * The project-relative path of the tasks manifest file.
     */
    static readonly MANIFEST_FILE: string;
    /**
     * One-shot entrypoint for the standalone task runner.
     *
     * Creates a runtime rooted at the current working directory, runs the named
     * task, and converts any failure into a non-zero process exit code. This is
     * the single line invoked by the bundled `scripts/run-task.cjs` that
     * "projen eject" emits, which keeps the generated bundle footer trivial.
     *
     * @param name The name of the task to run. Defaults to `process.argv[2]`.
     */
    static main(name?: string): Promise<void>;
    /**
     * The contents of tasks.json
     */
    private _manifest;
    /**
     * The raw contents of the currently loaded manifest, used to detect changes
     * on disk so the runtime can reload a regenerated manifest mid-run.
     */
    private _identity?;
    /**
     * The root directory of the project and the cwd for executing tasks.
     */
    readonly workdir: string;
    constructor(workdir: string);
    /**
     * The contents of tasks.json
     */
    get manifest(): TasksManifest;
    /**
     * The absolute path of the tasks manifest file.
     */
    private get manifestPath();
    /**
     * The tasks in this project.
     */
    get tasks(): TaskSpec[];
    /**
     * Find a task by name, or `undefined` if not found.
     */
    tryFindTask(name: string): TaskSpec | undefined;
    /**
     * Runs the task.
     * @param name The task name.
     */
    runTask(name: string, parents?: string[], args?: Array<string | number>, env?: {
        [name: string]: string;
    }): Promise<void>;
    /**
     * Re-reads the tasks manifest from disk if its contents changed since it was
     * last loaded, verifying its schema version along the way.
     *
     * Change detection compares the raw file contents, so an unchanged manifest
     * is not re-verified or re-adopted.
     */
    private reloadManifestIfChanged;
    /**
     * Validates a freshly read manifest:
     *
     * - Legacy manifests (no `manifestVersion`) are accepted as-is for backwards
     *   compatibility.
     * - Manifests from a newer projen (a higher `manifestVersion`) are accepted
     *   with a warning, since this runtime may not understand the schema.
     */
    private verifyManifest;
}
