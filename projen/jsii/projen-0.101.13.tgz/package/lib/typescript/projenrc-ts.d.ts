import { TypescriptConfig } from "../javascript";
import { TypeScriptRunner } from "./typescript-runner";
import type { InitProject, Project } from "../project";
import { ProjenrcFile } from "../projenrc";
export interface ProjenrcTsOptions {
    /**
     * The name of the projenrc file.
     * @default ".projenrc.ts"
     */
    readonly filename?: string;
    /**
     * A directory tree that may contain *.ts files that can be referenced from
     * your projenrc typescript file.
     *
     * @default "projenrc"
     */
    readonly projenCodeDir?: string;
    /**
     * The name of the tsconfig file that will be used by the runner
     * when compiling projen source files.
     *
     * @default "tsconfig.projen.json"
     * @deprecated Use `runner` to configure the tsconfigFileName directly.
     */
    readonly tsconfigFileName?: string;
    /**
     * The runner to use for executing TypeScript files.
     *
     * @default TypeScriptRunner.tsNode()
     */
    readonly runner?: TypeScriptRunner;
}
/**
 * A projenrc file written in TypeScript
 *
 * This component can be instantiated in any type of project
 * and has no expectations around the project's main language.
 */
export declare class ProjenrcTs extends ProjenrcFile {
    /**
     * TypeScript configuration file used to compile projen source files
     */
    readonly tsconfig: TypescriptConfig;
    readonly filePath: string;
    private readonly _projenCodeDir;
    private readonly _runner;
    constructor(project: Project, options?: ProjenrcTsOptions);
    projectCreation(initProject: InitProject): void;
    private getRunner;
    preSynthesize(): void;
    private generateProjenrc;
}
