/**
 * @schema PyprojectToml
 */
export interface PyprojectToml {
    /**
     * There are three kinds of metadata: _static_, _dynamic_, and _partially dynamic_.
     * - Static metadata is listed in the `[project]` table directly and cannot be specified or changed by a tool.
     * - Dynamic metadata key names are listed inside the `dynamic` key and represents metadata that a tool will later provide.
     * - Partially dynamic metadata is specified in the `[project]` table as a list or table, and also listed in `dynamic`, allowing the build backend to add entries but not modify or remove existing ones.
     *
     * @schema PyprojectToml#project
     */
    readonly project?: PyprojectTomlProject;
    /**
     * Named groups of dependencies, similar to `requirements.txt` files, which launchers, IDEs, and other tools can find and identify by name. Each item in `[dependency-groups]` is defined as mapping of group name to list of [dependency specifiers](https://packaging.python.org/en/latest/specifications/dependency-specifiers/).
     *
     * @schema PyprojectToml#dependency-groups
     */
    readonly dependencyGroups?: PyprojectTomlDependencyGroups;
    /**
     * @schema PyprojectToml#build-system
     */
    readonly buildSystem?: BuildSystem;
    /**
     * Every tool that is used by the project can have users specify configuration data as long as they use a sub-table within `[tool]`. Generally a project can use the subtable `tool.$NAME` if, and only if, they own the entry for `$NAME` in the Cheeseshop/PyPI.
     *
     * @schema PyprojectToml#tool
     */
    readonly tool?: PyprojectTomlTool;
}
/**
 * Converts an object of type 'PyprojectToml' to JSON representation.
 * @internal
 */
export declare function toJson_PyprojectToml(obj: PyprojectToml | undefined): Record<string, any> | undefined;
/**
 * There are three kinds of metadata: _static_, _dynamic_, and _partially dynamic_.
 * - Static metadata is listed in the `[project]` table directly and cannot be specified or changed by a tool.
 * - Dynamic metadata key names are listed inside the `dynamic` key and represents metadata that a tool will later provide.
 * - Partially dynamic metadata is specified in the `[project]` table as a list or table, and also listed in `dynamic`, allowing the build backend to add entries but not modify or remove existing ones.
 *
 * @schema PyprojectTomlProject
 */
export interface PyprojectTomlProject {
    /**
     * Valid name consists only of ASCII letters and numbers, period, underscore and hyphen. It must start and end with a letter or number.
     *
     * @schema PyprojectTomlProject#name
     */
    readonly name: string;
    /**
     * Version of the project, as defined in the [Version specifier specification](https://packaging.python.org/en/latest/specifications/version-specifiers/), and preferably [already normalized](https://packaging.python.org/en/latest/specifications/version-specifiers/#normalization).
     *
     * @schema PyprojectTomlProject#version
     */
    readonly version?: string;
    /**
     * Summary description of the project in one line. Tools may not accept multiple lines.
     *
     * @schema PyprojectTomlProject#description
     */
    readonly description?: string;
    /**
     * Value can be a relative path to text / markdown (`.md` suffix) / reStructuredText (`.rst` suffix) readme file, or a table with either:
     * - `file` key containing path of aforementioned readme file, or
     * - `text` key containing the full readme text embedded inside `pyproject.toml`.
     *
     * @schema PyprojectTomlProject#readme
     */
    readonly readme?: any;
    /**
     * Specifies the Python version(s) that the distribution is compatible with. Must be in the format specified in [Version specifiers](https://packaging.python.org/en/latest/specifications/version-specifiers/).
     *
     * @schema PyprojectTomlProject#requires-python
     */
    readonly requiresPython?: string;
    /**
     * A string containing a valid [SPDX license expression](https://spdx.github.io/spdx-spec/v2.2.2/SPDX-license-expressions/) (recommended), or a table with either:
     * - `file` key specifying a relative path to a license file (deprecated per PEP 639), or
     * - `text` key containing full license content (deprecated per PEP 639)
     *
     * @schema PyprojectTomlProject#license
     */
    readonly license?: any;
    /**
     * Relative paths or globs to paths of license files. Can be an empty list.
     *
     * @schema PyprojectTomlProject#license-files
     */
    readonly licenseFiles?: string[];
    /**
     * People or organizations considered as 'authors' of the project. Each author is a table with `name` key, `email` key, or both.
     *
     * @schema PyprojectTomlProject#authors
     */
    readonly authors?: ProjectAuthor[];
    /**
     * People or organizations considered as 'maintainers' of the project. Each maintainer is a table with `name` key, `email` key, or both.
     *
     * @schema PyprojectTomlProject#maintainers
     */
    readonly maintainers?: ProjectAuthor[];
    /**
     * List of keywords or tags that describe the project. They could be used by search engines to categorize the project.
     *
     * @schema PyprojectTomlProject#keywords
     */
    readonly keywords?: string[];
    /**
     * List of [Trove classifiers](https://pypi.org/classifiers/) that describe the project. PyPI use the classifiers to categorize projects.
     *
     * @schema PyprojectTomlProject#classifiers
     */
    readonly classifiers?: string[];
    /**
     * Table consisting one or multiple `label: URL` pairs. Common indexes like PyPI uses [well-known Project URLs](https://packaging.python.org/en/latest/specifications/well-known-project-urls/#well-known-labels) when presenting project pages.
     *
     * @schema PyprojectTomlProject#urls
     */
    readonly urls?: {
        [key: string]: string;
    };
    /**
     * Table of [entry points](https://packaging.python.org/en/latest/specifications/entry-points/) that allows package installers to create a command-line wrapper for. Each key is the name of the script to be created, and each value is the function or object to all, in form of either `importable.module` or `importable.module:object.attr`. Windows platform treats `console_scripts` specially in that they are wrapped in a console executable, so they are attached to a console and can use `sys.stdin`, `sys.stdout` and `sys.stderr` for I/O.
     *
     * @schema PyprojectTomlProject#scripts
     */
    readonly scripts?: {
        [key: string]: string;
    };
    /**
     * Table of [entry points](https://packaging.python.org/en/latest/specifications/entry-points/) that allows package installers to create a GUI wrapper for. Each key is the name of the script to be created, and each value is the function or object to all, in form of either `importable.module` or `importable.module:object.attr`. Windows platform treats `gui_scripts` specially in that they are wrapped in a GUI executable, so they can be started without a console, but cannot use standard streams unless application code redirects them.
     *
     * @schema PyprojectTomlProject#gui-scripts
     */
    readonly guiScripts?: {
        [key: string]: string;
    };
    /**
     * Extra [entry point groups](https://packaging.python.org/en/latest/specifications/entry-points/) that allow applications to load plugins. For example, Pygments (a syntax highlighting tool) can use additional styles from separately installed packages through `[project.entry-points."pygments.styles"]`. Each key is the name of the entry-point group, and each value is a table of entry points.
     *
     * @schema PyprojectTomlProject#entry-points
     */
    readonly entryPoints?: any;
    /**
     * An array of [dependency specifier](https://packaging.python.org/en/latest/specifications/dependency-specifiers/) strings, each representing a mandatory dependent package of the project.
     *
     * @schema PyprojectTomlProject#dependencies
     */
    readonly dependencies?: string[];
    /**
     * Each entry is a key/value pair, with the key specifying [extra feature name](https://packaging.python.org/en/latest/specifications/core-metadata/#provides-extra-multiple-use) (such as `socks` in `requests[socks]`), and value is an array of [dependency specifier](https://packaging.python.org/en/latest/specifications/dependency-specifiers/) strings.
     *
     * @schema PyprojectTomlProject#optional-dependencies
     */
    readonly optionalDependencies?: any;
    /**
     * An array of strings specifying the import names that the project exclusively provides when installed.
     *
     * @schema PyprojectTomlProject#import-names
     */
    readonly importNames?: string[];
    /**
     * An array of strings specifying the import names that the project provides when installed, but not exclusively.
     *
     * @schema PyprojectTomlProject#import-namespaces
     */
    readonly importNamespaces?: string[];
    /**
     * Specifies which keys are intentionally unspecified under `[project]` table so build backend can/will provide such metadata dynamically. Each key must be listed only once. It is an error to both list a key in `dynamic` and use the key directly in `[project]` unless the key is a list or table with arbitrary entries (PEP 808), in which case the build backend may extend it.
     * One of the most common usage is `version`, which allows build backend to retrieve project version from source code or version control system instead of hardcoding it in `pyproject.toml`.
     *
     * @schema PyprojectTomlProject#dynamic
     */
    readonly dynamic?: PyprojectTomlProjectDynamic[];
}
/**
 * Converts an object of type 'PyprojectTomlProject' to JSON representation.
 * @internal
 */
export declare function toJson_PyprojectTomlProject(obj: PyprojectTomlProject | undefined): Record<string, any> | undefined;
/**
 * Named groups of dependencies, similar to `requirements.txt` files, which launchers, IDEs, and other tools can find and identify by name. Each item in `[dependency-groups]` is defined as mapping of group name to list of [dependency specifiers](https://packaging.python.org/en/latest/specifications/dependency-specifiers/).
 *
 * @schema PyprojectTomlDependencyGroups
 */
export interface PyprojectTomlDependencyGroups {
    /**
     * @schema PyprojectTomlDependencyGroups#dev
     */
    readonly dev?: any[];
}
/**
 * Converts an object of type 'PyprojectTomlDependencyGroups' to JSON representation.
 * @internal
 */
export declare function toJson_PyprojectTomlDependencyGroups(obj: PyprojectTomlDependencyGroups | undefined): Record<string, any> | undefined;
/**
 * Declares any Python level dependencies that must be installed in order to run the project’s build system successfully.
 *
 * @schema BuildSystem
 */
export interface BuildSystem {
    /**
     * List of strings following the version specifier specification, representing dependencies required to execute the build system.
     *
     * @schema BuildSystem#requires
     */
    readonly requires: string[];
    /**
     * String is formatted following the same `module:object` syntax as a `setuptools` entry point. It’s also legal to leave out the `:object` part.
     *
     * @schema BuildSystem#build-backend
     */
    readonly buildBackend?: string;
    /**
     * list of directories to prepend to `sys.path` when loading the build backend, relative to project root
     *
     * @schema BuildSystem#backend-path
     */
    readonly backendPath?: string[];
}
/**
 * Converts an object of type 'BuildSystem' to JSON representation.
 * @internal
 */
export declare function toJson_BuildSystem(obj: BuildSystem | undefined): Record<string, any> | undefined;
/**
 * Every tool that is used by the project can have users specify configuration data as long as they use a sub-table within `[tool]`. Generally a project can use the subtable `tool.$NAME` if, and only if, they own the entry for `$NAME` in the Cheeseshop/PyPI.
 *
 * @schema PyprojectTomlTool
 */
export interface PyprojectTomlTool {
    /**
     * The uncompromising Python code formatter.
     *
     * @schema PyprojectTomlTool#black
     */
    readonly black?: any;
    /**
     * Build Python wheels for all platforms.
     *
     * @schema PyprojectTomlTool#cibuildwheel
     */
    readonly cibuildwheel?: any;
    /**
     * FastAPI web framework configuration.
     *
     * @schema PyprojectTomlTool#fastapi
     */
    readonly fastapi?: any;
    /**
     * Scheduled jobs in Python's `pyproject.toml`.
     *
     * This is a specification for declaring recurring scheduled jobs in Python projects, in `pyproject.toml`.
     *
     * It defines how jobs are declared and how providers would run them.
     *
     * It does not provide a specific implementation for running scheduled jobs, because that is provider specific.
     *
     * For example, a file at `app/jobs.py` could define:
     *
     * ```python
     * def clean_files():
     * print("Running cleanup...")
     * ```
     *
     * You could define a scheduled job to run that function once per day with:
     *
     * ```toml
     * [tool.scheduled.clean-files]
     * every = "day"
     * entrypoint = "app.jobs:clean_files"
     * ```
     *
     * @schema PyprojectTomlTool#scheduled
     */
    readonly scheduled?: any;
    /**
     * Optional static typing for Python.
     *
     * @schema PyprojectTomlTool#mypy
     */
    readonly mypy?: any;
    /**
     * An extremely fast Python linter and formatter, written in Rust.
     *
     * @schema PyprojectTomlTool#ruff
     */
    readonly ruff?: any;
    /**
     * An extremely fast Python type checker, written in Rust.
     *
     * @schema PyprojectTomlTool#ty
     */
    readonly ty?: any;
    /**
     * Modern, extensible Python project management.
     *
     * @schema PyprojectTomlTool#hatch
     */
    readonly hatch?: any;
    /**
     * Build and publish crates with pyo3, cffi and uniffi bindings as well as rust binaries as python packages
     *
     * @schema PyprojectTomlTool#maturin
     */
    readonly maturin?: any;
    /**
     * Improved build system generator for Python C/C++/Fortran extensions
     *
     * @schema PyprojectTomlTool#scikit-build
     */
    readonly scikitBuild?: any;
    /**
     * Easily download, build, install, upgrade, and uninstall Python packages.
     *
     * @schema PyprojectTomlTool#setuptools
     */
    readonly setuptools?: any;
    /**
     * Manage Python package versions using SCM (e.g. Git).
     *
     * @schema PyprojectTomlTool#setuptools_scm
     */
    readonly setuptoolsScm?: any;
    /**
     * A package manager and task runner.
     *
     * @schema PyprojectTomlTool#pixi
     */
    readonly pixi?: any;
    /**
     * A task runner that works well with `pyproject.toml` files.
     *
     * @schema PyprojectTomlTool#poe
     */
    readonly poe?: any;
    /**
     * Python dependency management and packaging made easy.
     *
     * @schema PyprojectTomlTool#poetry
     */
    readonly poetry?: any;
    /**
     * A modern Python package manager with PEP 621 support.
     *
     * @schema PyprojectTomlTool#pdm
     */
    readonly pdm?: any;
    /**
     * Static type checker for Python.
     *
     * @schema PyprojectTomlTool#pyright
     */
    readonly pyright?: any;
    /**
     * Standardized automated testing of Python packages
     *
     * @schema PyprojectTomlTool#pytest
     */
    readonly pytest?: any;
    /**
     * Review a repository for best practices.
     *
     * @schema PyprojectTomlTool#repo-review
     */
    readonly repoReview?: any;
    /**
     * The complementary task runner for python.
     *
     * @schema PyprojectTomlTool#taskipy
     */
    readonly taskipy?: any;
    /**
     * Tombi is a toolkit for TOML; providing a formatter/linter and language server
     *
     * @schema PyprojectTomlTool#tombi
     */
    readonly tombi?: any;
    /**
     * Standardized automated testing of Python packages
     *
     * @schema PyprojectTomlTool#tox
     */
    readonly tox?: any;
    /**
     * An extremely fast Python package installer and resolver, written in Rust.
     *
     * @schema PyprojectTomlTool#uv
     */
    readonly uv?: any;
    /**
     * A CLI tool to check and validate Python docstring formatting and completeness
     *
     * @schema PyprojectTomlTool#dfc
     */
    readonly dfc?: any;
    /**
     * A CLI tool to check and validate Python docstring formatting and completeness
     *
     * @schema PyprojectTomlTool#docstring-format-checker
     */
    readonly docstringFormatChecker?: any;
    /**
     * A CLI tool to run code files instantly without typing complex commands in terminal.
     *
     * @schema PyprojectTomlTool#quikrun
     */
    readonly quikrun?: any;
}
/**
 * Converts an object of type 'PyprojectTomlTool' to JSON representation.
 * @internal
 */
export declare function toJson_PyprojectTomlTool(obj: PyprojectTomlTool | undefined): Record<string, any> | undefined;
/**
 * @schema projectAuthor
 */
export interface ProjectAuthor {
    /**
     * @schema projectAuthor#name
     */
    readonly name?: string;
    /**
     * @schema projectAuthor#email
     */
    readonly email?: string;
}
/**
 * Converts an object of type 'ProjectAuthor' to JSON representation.
 * @internal
 */
export declare function toJson_ProjectAuthor(obj: ProjectAuthor | undefined): Record<string, any> | undefined;
/**
 * @schema PyprojectTomlProjectDynamic
 */
export declare enum PyprojectTomlProjectDynamic {
    /** version */
    VERSION = "version",
    /** description */
    DESCRIPTION = "description",
    /** readme */
    README = "readme",
    /** requires-python */
    REQUIRES_HYPHEN_PYTHON = "requires-python",
    /** license */
    LICENSE = "license",
    /** license-files */
    LICENSE_HYPHEN_FILES = "license-files",
    /** authors */
    AUTHORS = "authors",
    /** maintainers */
    MAINTAINERS = "maintainers",
    /** keywords */
    KEYWORDS = "keywords",
    /** classifiers */
    CLASSIFIERS = "classifiers",
    /** urls */
    URLS = "urls",
    /** scripts */
    SCRIPTS = "scripts",
    /** gui-scripts */
    GUI_HYPHEN_SCRIPTS = "gui-scripts",
    /** entry-points */
    ENTRY_HYPHEN_POINTS = "entry-points",
    /** dependencies */
    DEPENDENCIES = "dependencies",
    /** optional-dependencies */
    OPTIONAL_HYPHEN_DEPENDENCIES = "optional-dependencies",
    /** import-names */
    IMPORT_HYPHEN_NAMES = "import-names",
    /** import-namespaces */
    IMPORT_HYPHEN_NAMESPACES = "import-namespaces"
}
