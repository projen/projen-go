import { Component } from "../../component";
import type { NodeProject } from "../../javascript/node-project";
import { JsonFile } from "../../json";
import type { InitProject, Project } from "../../project";
import type { Task } from "../../task";
import { type BiomeConfiguration, type OverridePattern, type Rules } from "./biome-config";
export interface BiomeOptions {
    /**
     * Version of Biome to use
     *
     * @default "^2.5"
     */
    readonly version?: string;
    /**
     * Enable linting with recommended rules.
     *
     * @default true
     */
    readonly linter?: boolean;
    /**
     * Enable code formatter with recommended settings.
     *
     * @default true
     */
    readonly formatter?: boolean;
    /**
     * Enable code assist with recommended actions.
     *
     * @default true
     */
    readonly assist?: boolean;
    /**
     * Should arrays be merged or overwritten when creating Biome configuration
     *
     * By default arrays are merged and duplicate values are removed
     *
     * @default true
     */
    readonly mergeArraysInConfiguration?: boolean;
    /**
     * Automatically ignore all generated files.
     *
     * This prevents Biome from trying to format or lint files that are marked as generated,
     * which would fail since generated files are typically read-only.
     *
     * @default true
     */
    readonly ignoreGeneratedFiles?: boolean;
    /**
     * Full Biome configuration.
     *
     * This configuration dictates the final outcome if value is set.
     * For example, if the linter is disabled at the top-level, it can be enabled with `biomeConfig.linter.enabled`.
     */
    readonly biomeConfig?: BiomeConfiguration;
}
/**
 * Biome component.
 */
export declare class Biome extends Component {
    private options;
    static of(project: Project): Biome | undefined;
    private readonly biomeConfiguration;
    private readonly _filePatterns;
    private readonly biomeCommand;
    /**
     * Biome task.
     */
    readonly task: Task;
    /**
     * Biome configuration file content
     */
    readonly file: JsonFile;
    constructor(project: NodeProject, options?: BiomeOptions);
    /**
     * Runs biome once, right after the project is first created, so the generated code is linted and formatted immediately.
     */
    postProjectCreation(_initProject: InitProject): void;
    /**
     * Add a file pattern to biome.
     *
     * Use ! or !! to ignore a file pattern.
     * @param pattern Biome glob pattern
     * @see https://biomejs.dev/guides/configure-biome/#control-files-via-configuration
     */
    addFilePattern(pattern: string): void;
    /**
     * Add a biome override to set rules for a specific file pattern.
     * @param override Override object
     * @see https://biomejs.dev/reference/configuration/#overrides
     */
    addOverride(override: OverridePattern): void;
    /**
     * Expand the linting rules applied.
     *
     * Use `undefined` to remove the rule or group.
     *
     * @param rules Rules to apply.
     * @see https://biomejs.dev/reference/configuration/#linterrulesgroup
     * @example
     * biome.expandLintingRules({
     *   style: undefined,
     *   suspicious: {
     *     noExplicitAny: undefined,
     *     noDuplicateCase: "info",
     *   }
     * })
     */
    expandLinterRules(rules: Rules): void;
    private createLocalBiomeTask;
}
