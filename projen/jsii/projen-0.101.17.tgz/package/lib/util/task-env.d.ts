/**
 * Runs a builtin's async body, exiting non-zero on failure. Prints the error's
 * stack when available, otherwise its message/string form - dax parse errors
 * are not `Error` instances and have no `.stack`, so a naive `console.log(e.stack)`
 * would print a bare "undefined".
 */
export declare function runBuiltin(body: () => Promise<void>): void;
/** Returns a required env var, throwing a clear error when it is missing. */
export declare function requireEnv(name: string): string;
/** Parses an optional integer env var, throwing when it is set but not a number. */
export declare function intEnv(name: string): number | undefined;
