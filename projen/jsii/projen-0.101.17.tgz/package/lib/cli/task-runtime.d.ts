import type { TasksManifest, TaskSpec } from "../task-model";
/**
 * The runtime component of the tasks engine.
 */
export declare class TaskRuntime {
    /**
     * The project-relative path of the tasks manifest file.
     */
    static readonly MANIFEST_FILE: string;
    /**
     * One-shot entrypoint for the standalone task runner.
     *
     * Creates a runtime rooted at the current working directory, runs the named
     * task, and converts any failure into a non-zero process exit code. This is
     * the single line invoked by the bundled `scripts/run-task.cjs` that
     * "projen eject" emits, which keeps the generated bundle footer trivial.
     *
     * @param name The name of the task to run. Defaults to `process.argv[2]`.
     */
    static main(name?: string): Promise<void>;
    /**
     * The contents of tasks.json
     */
    private _manifest;
    /**
     * The raw contents of the currently loaded manifest, used to detect changes
     * on disk so the runtime can reload a regenerated manifest mid-run.
     */
    private _identity?;
    /**
     * The root directory of the project and the cwd for executing tasks.
     */
    readonly workdir: string;
    constructor(workdir: string);
    /**
     * The contents of tasks.json
     */
    get manifest(): TasksManifest;
    /**
     * The absolute path of the tasks manifest file.
     */
    private get manifestPath();
    /**
     * The tasks in this project.
     */
    get tasks(): TaskSpec[];
    /**
     * Find a task by name, or `undefined` if not found.
     */
    tryFindTask(name: string): TaskSpec | undefined;
    /**
     * Runs the task.
     * @param name The task name.
     */
    runTask(name: string, parents?: string[], args?: Array<string | number>, env?: {
        [name: string]: string;
    }, options?: {
        captureOutput?: boolean;
    }): Promise<string | void>;
    /**
     * Re-reads the tasks manifest from disk if its contents changed since it was
     * last loaded, verifying its schema version along the way.
     *
     * Change detection compares the raw file contents, so an unchanged manifest
     * is not re-verified or re-adopted.
     */
    private reloadManifestIfChanged;
    /**
     * Validates a freshly read manifest:
     *
     * - Legacy manifests (no `manifestVersion`) are accepted as-is for backwards
     *   compatibility.
     * - Manifests from a newer projen (a higher `manifestVersion`) are accepted
     *   with a warning, since this runtime may not understand the schema.
     */
    private verifyManifest;
}
/**
 * Normalized result of running a command through the system shell (a subset of
 * node's `SpawnSyncReturns`).
 */
export interface SystemShellResult {
    /** Exit code, or `null` if terminated by a signal or never spawned. */
    readonly status: number | null;
    /** Captured stdout, or `null` when stdout was inherited. */
    readonly stdout: Buffer | null;
    /** Captured stderr, or `null` when stderr was inherited. */
    readonly stderr: Buffer | null;
    /** An error raised while attempting to spawn (not a non-zero exit). */
    readonly error?: Error;
}
/**
 * Runs a command line through the operating system's native shell.
 *
 * Calls the OS shell via `child_process` with `shell: true`.
 * This backs the `system` task shell, which lets a user opt out of the built-in
 * cross-platform shell and use the host's native shell instead:
 * `/bin/sh`on POSIX and `cmd.exe` on Windows.
 *
 * Never throws for a non-zero exit (that is reported via `status`);
 * a spawn failure is reported via `error`. The caller supplies the full `env`.
 */
export declare function systemShell(command: string, options: {
    cwd: string;
    env?: NodeJS.ProcessEnv;
    capture?: boolean;
    stream?: boolean;
}): SystemShellResult;
