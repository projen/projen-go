/**
 * Metadata and configuration for uv.
 *
 * @schema UvConfiguration
 */
export interface UvConfiguration {
    /**
     * The default version specifier when adding a dependency.
     *
     * When adding a dependency to the project, if no constraint or URL is provided, a constraint
     * is added based on the latest compatible version of the package. By default, a lower bound
     * constraint is used, e.g., `>=1.2.3`.
     *
     * When `--frozen` is provided, no resolution is performed, and dependencies are always added
     * without constraints.
     *
     * This option is in preview and may change in any future release.
     *
     * @schema UvConfiguration#add-bounds
     */
    readonly addBounds?: AddBoundsKind;
    /**
     * Allow insecure connections to host.
     *
     * Expects to receive either a hostname (e.g., `localhost`), a host-port pair (e.g.,
     * `localhost:8080`), or a URL (e.g., `https://localhost`).
     *
     * WARNING: Hosts included in this list will not be verified against the system's certificate
     * store. Only use `--allow-insecure-host` in a secure network with verified sources, as it
     * bypasses SSL verification and could expose you to MITM attacks.
     *
     * @schema UvConfiguration#allow-insecure-host
     */
    readonly allowInsecureHost?: string[];
    /**
     * @schema UvConfiguration#audit
     */
    readonly audit?: AuditOptions;
    /**
     * Configuration for the uv build backend.
     *
     * Note that those settings only apply when using the `uv_build` backend, other build backends
     * (such as hatchling) have their own configuration.
     *
     * @schema UvConfiguration#build-backend
     */
    readonly buildBackend?: BuildBackendSettings;
    /**
     * PEP 508-style requirements, e.g., `ruff==0.5.0`, or `ruff @ https://...`.
     *
     * @schema UvConfiguration#build-constraint-dependencies
     */
    readonly buildConstraintDependencies?: string[];
    /**
     * Path to the cache directory.
     *
     * @schema UvConfiguration#cache-dir
     */
    readonly cacheDir?: string;
    /**
     * The keys to consider when caching builds for the project.
     *
     * Cache keys enable you to specify the files or directories that should trigger a rebuild when
     * modified. By default, uv will rebuild a project whenever the `pyproject.toml`, `setup.py`,
     * or `setup.cfg` files in the project directory are modified, or if a `src` directory is
     * added or removed, i.e.:
     *
     * ```toml
     * cache-keys = [{ file = "pyproject.toml" }, { file = "setup.py" }, { file = "setup.cfg" }, { dir = "src" }]
     * ```
     *
     * As an example: if a project uses dynamic metadata to read its dependencies from a
     * `requirements.txt` file, you can specify `cache-keys = [{ file = "requirements.txt" }, { file = "pyproject.toml" }]`
     * to ensure that the project is rebuilt whenever the `requirements.txt` file is modified (in
     * addition to watching the `pyproject.toml`).
     *
     * Globs are supported, following the syntax of the [`glob`](https://docs.rs/glob/0.3.1/glob/struct.Pattern.html)
     * crate. For example, to invalidate the cache whenever a `.toml` file in the project directory
     * or any of its subdirectories is modified, you can specify `cache-keys = [{ file = "*_/*.toml" }]`.
     * Note that the use of globs can be expensive, as uv may need to walk the filesystem to
     * determine whether any files have changed.
     *
     * Cache keys can also include version control information. For example, if a project uses
     * `setuptools_scm` to read its version from a Git commit, you can specify `cache-keys = [{ git = { commit = true }, { file = "pyproject.toml" }]`
     * to include the current Git commit hash in the cache key (in addition to the
     * `pyproject.toml`). Git tags are also supported via `cache-keys = [{ git = { commit = true, tags = true } }]`.
     *
     * Cache keys can also include environment variables. For example, if a project relies on
     * `MACOSX_DEPLOYMENT_TARGET` or other environment variables to determine its behavior, you can
     * specify `cache-keys = [{ env = "MACOSX_DEPLOYMENT_TARGET" }]` to invalidate the cache
     * whenever the environment variable changes.
     *
     * Cache keys only affect the project defined by the `pyproject.toml` in which they're
     * specified (as opposed to, e.g., affecting all members in a workspace), and all paths and
     * globs are interpreted as relative to the project directory.
     *
     * @schema UvConfiguration#cache-keys
     */
    readonly cacheKeys?: any[];
    /**
     * Check an index URL for existing files to skip duplicate uploads.
     *
     * This option allows retrying publishing that failed after only some, but not all files have
     * been uploaded, and handles error due to parallel uploads of the same file.
     *
     * Before uploading, the index is checked. If the exact same file already exists in the index,
     * the file will not be uploaded. If an error occurred during the upload, the index is checked
     * again, to handle cases where the identical file was uploaded twice in parallel.
     *
     * The exact behavior will vary based on the index. When uploading to PyPI, uploading the same
     * file succeeds even without `--check-url`, while most other indexes error.
     *
     * The index must provide one of the supported hashes (SHA-256, SHA-384, or SHA-512).
     *
     * @schema UvConfiguration#check-url
     */
    readonly checkUrl?: string;
    /**
     * Compile Python files to bytecode after installation.
     *
     * By default, uv does not compile Python (`.py`) files to bytecode (`__pycache__/*.pyc`);
     * instead, compilation is performed lazily the first time a module is imported. For use-cases
     * in which start time is critical, such as CLI applications and Docker containers, this option
     * can be enabled to trade longer installation times for faster start times.
     *
     * When enabled, uv will process the entire site-packages directory (including packages that
     * are not being modified by the current operation) for consistency. Like pip, it will also
     * ignore errors.
     *
     * @schema UvConfiguration#compile-bytecode
     */
    readonly compileBytecode?: boolean;
    /**
     * The maximum number of source distributions that uv will build concurrently at any given
     * time.
     *
     * Defaults to the number of available CPU cores.
     *
     * @default the number of available CPU cores.
     * @schema UvConfiguration#concurrent-builds
     */
    readonly concurrentBuilds?: number;
    /**
     * The maximum number of in-flight concurrent downloads that uv will perform at any given
     * time.
     *
     * @schema UvConfiguration#concurrent-downloads
     */
    readonly concurrentDownloads?: number;
    /**
     * The number of threads used when installing and unzipping packages.
     *
     * Defaults to the number of available CPU cores.
     *
     * @default the number of available CPU cores.
     * @schema UvConfiguration#concurrent-installs
     */
    readonly concurrentInstalls?: number;
    /**
     * Settings to pass to the [PEP 517](https://peps.python.org/pep-0517/) build backend,
     * specified as `KEY=VALUE` pairs.
     *
     * @schema UvConfiguration#config-settings
     */
    readonly configSettings?: {
        [key: string]: any;
    };
    /**
     * Settings to pass to the [PEP 517](https://peps.python.org/pep-0517/) build backend for specific packages,
     * specified as `KEY=VALUE` pairs.
     *
     * Accepts a map from package names to string key-value pairs.
     *
     * @schema UvConfiguration#config-settings-package
     */
    readonly configSettingsPackage?: {
        [key: string]: {
            [key: string]: any;
        };
    };
    /**
     * A list of sets of conflicting groups or extras.
     *
     * @schema UvConfiguration#conflicts
     */
    readonly conflicts?: SchemaConflictItem[][];
    /**
     * PEP 508-style requirements, e.g., `ruff==0.5.0`, or `ruff @ https://...`.
     *
     * @schema UvConfiguration#constraint-dependencies
     */
    readonly constraintDependencies?: string[];
    /**
     * The list of `dependency-groups` to install by default.
     *
     * Can also be the literal `"all"` to default enable all groups.
     *
     * @schema UvConfiguration#default-groups
     */
    readonly defaultGroups?: any;
    /**
     * Additional settings for `dependency-groups`.
     *
     * Currently this can only be used to add `requires-python` constraints
     * to dependency groups (typically to inform uv that your dev tooling
     * has a higher python requirement than your actual project).
     *
     * This cannot be used to define dependency groups, use the top-level
     * `[dependency-groups]` table for that.
     *
     * @schema UvConfiguration#dependency-groups
     */
    readonly dependencyGroups?: {
        [key: string]: DependencyGroupSettings;
    };
    /**
     * Pre-defined static metadata for dependencies of the project (direct or transitive). When
     * provided, enables the resolver to use the specified metadata instead of querying the
     * registry or building the relevant package from source.
     *
     * Metadata should be provided in adherence with the [Metadata 2.3](https://packaging.python.org/en/latest/specifications/core-metadata/)
     * standard, though only the following fields are respected:
     *
     * - `name`: The name of the package.
     * - (Optional) `version`: The version of the package. If omitted, the metadata will be applied
     * to all versions of the package.
     * - (Optional) `requires-dist`: The dependencies of the package (e.g., `werkzeug>=0.14`).
     * - (Optional) `requires-python`: The Python version required by the package (e.g., `>=3.10`).
     * - (Optional) `provides-extra`: The extras provided by the package.
     *
     * @schema UvConfiguration#dependency-metadata
     */
    readonly dependencyMetadata?: StaticMetadata[];
    /**
     * PEP 508-style requirements, e.g., `ruff==0.5.0`, or `ruff @ https://...`.
     *
     * @schema UvConfiguration#dev-dependencies
     */
    readonly devDependencies?: string[];
    /**
     * A list of environment markers, e.g., `python_version >= '3.6'`.
     *
     * @schema UvConfiguration#environments
     */
    readonly environments?: string[];
    /**
     * Dependencies to exclude when resolving the project's dependencies.
     *
     * Excludes are used to prevent a package from being selected during resolution,
     * regardless of whether it's requested by any other package. When a package is excluded,
     * it will be omitted from the dependency list entirely.
     *
     * Including a package as an exclusion will prevent it from being installed, even if
     * it's requested by transitive dependencies. This can be useful for removing optional
     * dependencies or working around packages with broken dependencies.
     *
     * Exclusions can be limited to the dependencies declared by a specific package version by
     * using a table with `package` and `dependencies`. The `package` table identifies the package
     * whose dependencies will be excluded by `name` and, optionally, `version`. If `version` is
     * omitted, the exclusions apply to all versions of that package. A version-specific entry
     * takes precedence over an all-versions entry.
     *
     * !!! note
     * In `uv lock`, `uv sync`, and `uv run`, uv will only read `exclude-dependencies` from
     * the `pyproject.toml` at the workspace root, and will ignore any declarations in other
     * workspace members or `uv.toml` files.
     *
     * @schema UvConfiguration#exclude-dependencies
     */
    readonly excludeDependencies?: any[];
    /**
     * Limit candidate packages to those that were uploaded prior to the given date.
     *
     * The date is compared against the upload time of each individual distribution artifact
     * (i.e., when each file was uploaded to the package index), not the release date of the
     * package version.
     *
     * Accepts RFC 3339 timestamps (e.g., `2006-12-02T02:07:43Z`), a "friendly" duration (e.g.,
     * `24 hours`, `1 week`, `30 days`), or an ISO 8601 duration (e.g., `PT24H`, `P7D`, `P30D`).
     *
     * Durations do not respect semantics of the local time zone and are always resolved to a fixed
     * number of seconds assuming that a day is 24 hours (e.g., DST transitions are ignored).
     * Calendar units such as months and years are not allowed.
     *
     * Set to `false` to disable `exclude-newer`.
     *
     * @schema UvConfiguration#exclude-newer
     */
    readonly excludeNewer?: ExcludeNewerOverride;
    /**
     * Limit candidate packages for specific packages to those that were uploaded prior to the
     * given date.
     *
     * Accepts a dictionary format of `PACKAGE = "DATE"` pairs, where `DATE` is an RFC 3339
     * timestamp (e.g., `2006-12-02T02:07:43Z`), a "friendly" duration (e.g., `24 hours`, `1 week`,
     * `30 days`), or a ISO 8601 duration (e.g., `PT24H`, `P7D`, `P30D`).
     *
     * Durations do not respect semantics of the local time zone and are always resolved to a fixed
     * number of seconds assuming that a day is 24 hours (e.g., DST transitions are ignored).
     * Calendar units such as months and years are not allowed.
     *
     * Set a package to `false` to exempt it from the global [`exclude-newer`](#exclude-newer)
     * constraint entirely.
     *
     * @schema UvConfiguration#exclude-newer-package
     */
    readonly excludeNewerPackage?: {
        [key: string]: ExcludeNewerOverride;
    };
    /**
     * Additional build dependencies for packages.
     *
     * This allows extending the PEP 517 build environment for the project's dependencies with
     * additional packages. This is useful for packages that assume the presence of packages like
     * `pip`, and do not declare them as build dependencies.
     *
     * @schema UvConfiguration#extra-build-dependencies
     */
    readonly extraBuildDependencies?: {
        [key: string]: any[];
    };
    /**
     * Extra environment variables to set when building certain packages.
     *
     * Environment variables will be added to the environment when building the
     * specified packages.
     *
     * @schema UvConfiguration#extra-build-variables
     */
    readonly extraBuildVariables?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
     * Extra URLs of package indexes to use, in addition to `--index-url`.
     *
     * Accepts either a repository compliant with [PEP 503](https://peps.python.org/pep-0503/)
     * (the simple repository API), or a local directory laid out in the same format.
     *
     * All indexes provided via this flag take priority over the index specified by
     * [`index_url`](#index-url) or [`index`](#index) with `default = true`. When multiple indexes
     * are provided, earlier values take priority.
     *
     * To control uv's resolution strategy when multiple indexes are present, see
     * [`index_strategy`](#index-strategy).
     *
     * (Deprecated: use `index` instead.)
     *
     * @schema UvConfiguration#extra-index-url
     */
    readonly extraIndexUrl?: string[];
    /**
     * Locations to search for candidate distributions, in addition to those found in the registry
     * indexes.
     *
     * If a path, the target must be a directory that contains packages as wheel files (`.whl`) or
     * source distributions (e.g., `.tar.gz` or `.zip`) at the top level.
     *
     * If a URL, the page must contain a flat list of links to package files adhering to the
     * formats described above.
     *
     * @schema UvConfiguration#find-links
     */
    readonly findLinks?: string[];
    /**
     * The strategy to use when selecting multiple versions of a given package across Python
     * versions and platforms.
     *
     * By default, uv will optimize for selecting the latest version of each package for each
     * supported Python version (`requires-python`), while minimizing the number of selected
     * versions across platforms.
     *
     * Under `fewest`, uv will minimize the number of selected versions for each package,
     * preferring older versions that are compatible with a wider range of supported Python
     * versions or platforms.
     *
     * @schema UvConfiguration#fork-strategy
     */
    readonly forkStrategy?: ForkStrategy;
    /**
     * The URL of the HTTP proxy to use.
     *
     * @schema UvConfiguration#http-proxy
     */
    readonly httpProxy?: string;
    /**
     * The URL of the HTTPS proxy to use.
     *
     * @schema UvConfiguration#https-proxy
     */
    readonly httpsProxy?: string;
    /**
     * The indexes to use when resolving dependencies.
     *
     * Accepts either a repository compliant with [PEP 503](https://peps.python.org/pep-0503/)
     * (the simple repository API), or a local directory laid out in the same format.
     *
     * Indexes are considered in the order in which they're defined, such that the first-defined
     * index has the highest priority. Further, the indexes provided by this setting are given
     * higher priority than any indexes specified via [`index_url`](#index-url) or
     * [`extra_index_url`](#extra-index-url). uv will only consider the first index that contains
     * a given package, unless an alternative [index strategy](#index-strategy) is specified.
     *
     * If an index is marked as `explicit = true`, it will be used exclusively for the
     * dependencies that select it explicitly via `[tool.uv.sources]`, as in:
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "pytorch"
     * url = "https://download.pytorch.org/whl/cu130"
     * explicit = true
     *
     * [tool.uv.sources]
     * torch = { index = "pytorch" }
     * ```
     *
     * If an index is marked as `default = true`, it will be moved to the end of the prioritized list, such that it is
     * given the lowest priority when resolving packages. Additionally, marking an index as default will disable the
     * PyPI default index.
     *
     * @schema UvConfiguration#index
     */
    readonly index?: Index[];
    /**
     * The strategy to use when resolving against multiple index URLs.
     *
     * By default, uv will stop at the first index on which a given package is available, and
     * limit resolutions to those present on that first index (`first-index`). This prevents
     * "dependency confusion" attacks, whereby an attacker can upload a malicious package under the
     * same name to an alternate index.
     *
     * @schema UvConfiguration#index-strategy
     */
    readonly indexStrategy?: IndexStrategy;
    /**
     * The URL of the Python package index (by default: <https://pypi.org/simple>).
     *
     * Accepts either a repository compliant with [PEP 503](https://peps.python.org/pep-0503/)
     * (the simple repository API), or a local directory laid out in the same format.
     *
     * The index provided by this setting is given lower priority than any indexes specified via
     * [`extra_index_url`](#extra-index-url) or [`index`](#index).
     *
     * (Deprecated: use `index` instead.)
     *
     * @schema UvConfiguration#index-url
     */
    readonly indexUrl?: string;
    /**
     * Attempt to use `keyring` for authentication for index URLs.
     *
     * At present, only `--keyring-provider subprocess` is supported, which configures uv to
     * use the `keyring` CLI to handle authentication.
     *
     * @schema UvConfiguration#keyring-provider
     */
    readonly keyringProvider?: KeyringProviderType;
    /**
     * The method to use when installing packages from the global cache.
     *
     * Defaults to `clone` (also known as Copy-on-Write) on macOS and Linux, and `hardlink` on
     * Windows.
     *
     * WARNING: The use of symlink link mode is discouraged, as they create tight coupling between
     * the cache and the target environment. For example, clearing the cache (`uv cache clean`)
     * will break all installed packages by way of removing the underlying source files. Use
     * symlinks with caution.
     *
     * @default clone` (also known as Copy-on-Write) on macOS and Linux, and `hardlink` on
     * @schema UvConfiguration#link-mode
     */
    readonly linkMode?: LinkMode;
    /**
     * Whether the project is managed by uv. If `false`, uv will ignore the project when
     * `uv run` is invoked.
     *
     * @schema UvConfiguration#managed
     */
    readonly managed?: boolean;
    /**
     * Whether to load TLS certificates from the platform's native certificate store.
     *
     * By default, uv uses bundled Mozilla root certificates. When enabled, this loads
     * certificates from the platform's native certificate store instead.
     *
     * (Deprecated: use `system-certs` instead.)
     *
     * @schema UvConfiguration#native-tls
     */
    readonly nativeTls?: boolean;
    /**
     * Don't install pre-built wheels.
     *
     * The given packages will be built and installed from source. The resolver will still use
     * pre-built wheels to extract package metadata, if available.
     *
     * @schema UvConfiguration#no-binary
     */
    readonly noBinary?: boolean;
    /**
     * Don't install pre-built wheels for a specific package.
     *
     * @schema UvConfiguration#no-binary-package
     */
    readonly noBinaryPackage?: string[];
    /**
     * Don't build source distributions.
     *
     * When enabled, uv will reuse cached wheels from previously built source distributions, but
     * operations that require building a source distribution will exit with an error. uv may
     * still build editable requirements, and their build backends may run arbitrary Python code.
     *
     * @schema UvConfiguration#no-build
     */
    readonly noBuild?: boolean;
    /**
     * Disable isolation when building source distributions.
     *
     * Assumes that build dependencies specified by [PEP 518](https://peps.python.org/pep-0518/)
     * are already installed.
     *
     * @schema UvConfiguration#no-build-isolation
     */
    readonly noBuildIsolation?: boolean;
    /**
     * Disable isolation when building source distributions for a specific package.
     *
     * Assumes that the packages' build dependencies specified by [PEP 518](https://peps.python.org/pep-0518/)
     * are already installed.
     *
     * @schema UvConfiguration#no-build-isolation-package
     */
    readonly noBuildIsolationPackage?: string[];
    /**
     * Don't build source distributions for a specific package.
     *
     * @schema UvConfiguration#no-build-package
     */
    readonly noBuildPackage?: string[];
    /**
     * Avoid reading from or writing to the cache, instead using a temporary directory for the
     * duration of the operation.
     *
     * @schema UvConfiguration#no-cache
     */
    readonly noCache?: boolean;
    /**
     * Ignore all registry indexes (e.g., PyPI), instead relying on direct URL dependencies and
     * those provided via `--find-links`.
     *
     * @schema UvConfiguration#no-index
     */
    readonly noIndex?: boolean;
    /**
     * A list of hosts to exclude from proxying.
     *
     * @schema UvConfiguration#no-proxy
     */
    readonly noProxy?: string[];
    /**
     * Ignore the `tool.uv.sources` table when resolving dependencies. Used to lock against the
     * standards-compliant, publishable package metadata, as opposed to using any local or Git
     * sources.
     *
     * @schema UvConfiguration#no-sources
     */
    readonly noSources?: boolean;
    /**
     * Ignore `tool.uv.sources` for the specified packages.
     *
     * @schema UvConfiguration#no-sources-package
     */
    readonly noSourcesPackage?: string[];
    /**
     * Disable network access, relying only on locally cached data and locally available files.
     *
     * @schema UvConfiguration#offline
     */
    readonly offline?: boolean;
    /**
     * Overrides to apply when resolving the project's dependencies.
     *
     * Overrides are used to force selection of a specific version of a package, regardless of the
     * version requested by any other package, and regardless of whether choosing that version
     * would typically constitute an invalid resolution.
     *
     * While constraints are _additive_, in that they're combined with the requirements of the
     * constituent packages, overrides are _absolute_, in that they completely replace the
     * requirements of any constituent packages.
     *
     * Including a package as an override will _not_ trigger installation of the package on its
     * own; instead, the package must be requested elsewhere in the project's first-party or
     * transitive dependencies.
     *
     * Overrides can be limited to the dependencies declared by a specific package version by
     * using a table with `package` and `dependencies`. The `package` table identifies the package
     * whose dependencies will be overridden by `name` and, optionally, `version`. If `version` is
     * omitted, the overrides apply to all versions of that package. Requirements in `dependencies`
     * replace dependencies with the same name and add dependencies that are not declared by the
     * package. Dependencies not listed in `dependencies` are left unchanged.
     *
     * Scoped overrides currently support registry version specifiers only. Direct URL and path
     * sources, including Git sources, and explicit indexes are not supported.
     *
     * !!! note
     * In `uv lock`, `uv sync`, and `uv run`, uv will only read `override-dependencies` from
     * the `pyproject.toml` at the workspace root, and will ignore any declarations in other
     * workspace members or `uv.toml` files.
     *
     * @schema UvConfiguration#override-dependencies
     */
    readonly overrideDependencies?: any[];
    /**
     * Whether the project should be considered a Python package, or a non-package ("virtual")
     * project.
     *
     * Packages are built and installed into the virtual environment in editable mode and thus
     * require a build backend, while virtual projects are _not_ built or installed; instead, only
     * their dependencies are included in the virtual environment.
     *
     * Creating a package requires that a `build-system` is present in the `pyproject.toml`, and
     * that the project adheres to a structure that adheres to the build backend's expectations
     * (e.g., a `src` layout).
     *
     * @schema UvConfiguration#package
     */
    readonly package?: boolean;
    /**
     * @schema UvConfiguration#pip
     */
    readonly pip?: PipOptions;
    /**
     * The strategy to use when considering pre-release versions.
     *
     * By default, uv will accept pre-releases for packages that _only_ publish pre-releases,
     * along with first-party requirements that contain an explicit pre-release marker in the
     * declared specifiers (`if-necessary-or-explicit`).
     *
     * @schema UvConfiguration#prerelease
     */
    readonly prerelease?: PrereleaseMode;
    /**
     * Whether to enable all experimental, preview features.
     *
     * Use `preview-features` instead.
     *
     * @schema UvConfiguration#preview
     */
    readonly preview?: boolean;
    /**
     * Whether to enable specific or all experimental preview features.
     *
     * Unknown feature names are ignored with a warning.
     *
     * @schema UvConfiguration#preview-features
     */
    readonly previewFeatures?: any;
    /**
     * The URL for publishing packages to the Python package index (by default:
     * <https://upload.pypi.org/legacy/>).
     *
     * @schema UvConfiguration#publish-url
     */
    readonly publishUrl?: string;
    /**
     * Mirror URL to use for downloading managed PyPy installations.
     *
     * By default, managed PyPy installations are downloaded from [downloads.python.org](https://downloads.python.org/).
     * This variable can be set to a mirror URL to use a different source for PyPy installations.
     * The provided URL will replace `https://downloads.python.org/pypy` in, e.g., `https://downloads.python.org/pypy/pypy3.8-v7.3.7-osx64.tar.bz2`.
     *
     * Distributions can be read from a
     * local directory by using the `file://` URL scheme.
     *
     * @schema UvConfiguration#pypy-install-mirror
     */
    readonly pypyInstallMirror?: string;
    /**
     * Whether to allow Python downloads.
     *
     * @schema UvConfiguration#python-downloads
     */
    readonly pythonDownloads?: PythonDownloads;
    /**
     * URL pointing to JSON of custom Python installations.
     *
     * @schema UvConfiguration#python-downloads-json-url
     */
    readonly pythonDownloadsJsonUrl?: string;
    /**
     * Mirror URL for downloading managed Python installations.
     *
     * By default, managed Python installations are downloaded from [`python-build-standalone`](https://github.com/astral-sh/python-build-standalone).
     * This variable can be set to a mirror URL to use a different source for Python installations.
     * The provided URL will replace `https://github.com/astral-sh/python-build-standalone/releases/download` in, e.g., `https://github.com/astral-sh/python-build-standalone/releases/download/20240713/cpython-3.12.4%2B20240713-aarch64-apple-darwin-install_only.tar.gz`.
     *
     * Distributions can be read from a local directory by using the `file://` URL scheme.
     *
     * @schema UvConfiguration#python-install-mirror
     */
    readonly pythonInstallMirror?: string;
    /**
     * Whether to prefer using Python installations that are already present on the system, or
     * those that are downloaded and installed by uv.
     *
     * @schema UvConfiguration#python-preference
     */
    readonly pythonPreference?: PythonPreference;
    /**
     * Reinstall all packages, regardless of whether they're already installed. Implies `refresh`.
     *
     * @schema UvConfiguration#reinstall
     */
    readonly reinstall?: boolean;
    /**
     * Reinstall a specific package, regardless of whether it's already installed. Implies
     * `refresh-package`.
     *
     * @schema UvConfiguration#reinstall-package
     */
    readonly reinstallPackage?: string[];
    /**
     * A list of environment markers, e.g., `sys_platform == 'darwin'.
     *
     * @schema UvConfiguration#required-environments
     */
    readonly requiredEnvironments?: string[];
    /**
     * Enforce a requirement on the version of uv.
     *
     * If the version of uv does not meet the requirement at runtime, uv will exit
     * with an error.
     *
     * Accepts a [PEP 440](https://peps.python.org/pep-0440/) specifier, like `==0.5.0` or `>=0.5.0`.
     *
     * @schema UvConfiguration#required-version
     */
    readonly requiredVersion?: string;
    /**
     * The strategy to use when selecting between the different compatible versions for a given
     * package requirement.
     *
     * By default, uv will use the latest compatible version of each package (`highest`).
     *
     * @schema UvConfiguration#resolution
     */
    readonly resolution?: ResolutionMode;
    /**
     * The sources to use when resolving dependencies.
     *
     * `tool.uv.sources` enriches the dependency metadata with additional sources, incorporated
     * during development. A dependency source can be a Git repository, a URL, a local path, or an
     * alternative registry.
     *
     * See [Dependencies](https://docs.astral.sh/uv/concepts/projects/dependencies/) for more.
     *
     * @schema UvConfiguration#sources
     */
    readonly sources?: {
        [key: string]: any[];
    };
    /**
     * Whether to load TLS certificates from the platform's native certificate store.
     *
     * By default, uv uses bundled Mozilla root certificates. When enabled, this loads
     * certificates from the platform's native certificate store instead.
     *
     * @schema UvConfiguration#system-certs
     */
    readonly systemCerts?: boolean;
    /**
     * The backend to use when fetching packages in the PyTorch ecosystem.
     *
     * When set, uv will ignore the configured index URLs for packages in the PyTorch ecosystem,
     * and will instead use the defined backend.
     *
     * For example, when set to `cpu`, uv will use the CPU-only PyTorch index; when set to `cu126`,
     * uv will use the PyTorch index for CUDA 12.6.
     *
     * The `auto` mode will attempt to detect the appropriate PyTorch index based on the currently
     * installed CUDA drivers.
     *
     * This setting is only respected by `uv pip` commands.
     *
     * This option is in preview and may change in any future release.
     *
     * @schema UvConfiguration#torch-backend
     */
    readonly torchBackend?: TorchMode;
    /**
     * Configure trusted publishing.
     *
     * By default, uv checks for trusted publishing when running in a supported environment, but
     * ignores it if it isn't configured.
     *
     * uv's supported environments for trusted publishing include GitHub Actions and GitLab CI/CD.
     *
     * @schema UvConfiguration#trusted-publishing
     */
    readonly trustedPublishing?: TrustedPublishing;
    /**
     * Allow package upgrades, ignoring pinned versions in any existing output file.
     *
     * @schema UvConfiguration#upgrade
     */
    readonly upgrade?: boolean;
    /**
     * Allow upgrades for a specific package, ignoring pinned versions in any existing output
     * file.
     *
     * Accepts both standalone package names (`ruff`) and version specifiers (`ruff<0.5.0`).
     *
     * @schema UvConfiguration#upgrade-package
     */
    readonly upgradePackage?: string[];
    /**
     * The workspace definition for the project, if any.
     *
     * @schema UvConfiguration#workspace
     */
    readonly workspace?: ToolUvWorkspace;
}
/**
 * Converts an object of type 'UvConfiguration' to JSON representation.
 * @internal
 */
export declare function toJson_UvConfiguration(obj: UvConfiguration | undefined): Record<string, any> | undefined;
/**
 * The default version specifier when adding a dependency.
 *
 * @schema AddBoundsKind
 */
export declare enum AddBoundsKind {
    /** Only a lower bound, e.g., `>=1.2.3`. (lower) */
    LOWER = "lower",
    /** Allow the same major version, similar to the semver caret, e.g., `>=1.2.3, <2.0.0`.
  
  Leading zeroes are skipped, e.g. `>=0.1.2, <0.2.0`. (major) */
    MAJOR = "major",
    /** Allow the same minor version, similar to the semver tilde, e.g., `>=1.2.3, <1.3.0`.
  
  Leading zeroes are skipped, e.g. `>=0.1.2, <0.1.3`. (minor) */
    MINOR = "minor",
    /** Pin the exact version, e.g., `==1.2.3`.
  
  This option is not recommended, as versions are already pinned in the uv lockfile. (exact) */
    EXACT = "exact"
}
/**
 * @schema AuditOptions
 */
export interface AuditOptions {
    /**
     * A list of vulnerability IDs to ignore during auditing.
     *
     * Vulnerabilities matching any of the provided IDs (including aliases) will be excluded from
     * the audit results.
     *
     * @schema AuditOptions#ignore
     */
    readonly ignore?: string[];
    /**
     * A list of vulnerability IDs to ignore during auditing, but only while no fix is available.
     *
     * Vulnerabilities matching any of the provided IDs (including aliases) will be excluded from
     * the audit results as long as they have no known fix versions. Once a fix version becomes
     * available, the vulnerability will be reported again.
     *
     * @schema AuditOptions#ignore-until-fixed
     */
    readonly ignoreUntilFixed?: string[];
}
/**
 * Converts an object of type 'AuditOptions' to JSON representation.
 * @internal
 */
export declare function toJson_AuditOptions(obj: AuditOptions | undefined): Record<string, any> | undefined;
/**
 * Settings for the uv build backend (`uv_build`).
 *
 * Note that those settings only apply when using the `uv_build` backend, other build backends
 * (such as hatchling) have their own configuration.
 *
 * All options that accept globs use the portable glob patterns from
 * [PEP 639](https://packaging.python.org/en/latest/specifications/glob-patterns/).
 *
 * @schema BuildBackendSettings
 */
export interface BuildBackendSettings {
    /**
     * Data includes for wheels.
     *
     * Each entry is a directory, whose contents are copied to the matching directory in the wheel
     * in `<name>-<version>.data/(purelib|platlib|headers|scripts|data)`. Upon installation, this
     * data is moved to its target location, as defined by
     * <https://docs.python.org/3.12/library/sysconfig.html#installation-paths>. Usually, small
     * data files are included by placing them in the Python module instead of using data includes.
     *
     * - `scripts`: Installed to the directory for executables, `<venv>/bin` on Unix or
     * `<venv>\Scripts` on Windows. This directory is added to `PATH` when the virtual
     * environment  is activated or when using `uv run`, so this data type can be used to install
     * additional binaries. Consider using `project.scripts` instead for Python entrypoints.
     * - `data`: Installed over the virtualenv environment root.
     *
     * Warning: This may override existing files!
     *
     * - `headers`: Installed to the include directory. Compilers building Python packages
     * with this package as build requirement use the include directory to find additional header
     * files.
     * - `purelib` and `platlib`: Installed to the `site-packages` directory. It is not recommended
     * to use these two options.
     *
     * @schema BuildBackendSettings#data
     */
    readonly data?: WheelDataIncludes;
    /**
     * If set to `false`, the default excludes aren't applied.
     *
     * Default excludes: `__pycache__`, `*.pyc`, and `*.pyo`.
     *
     * @schema BuildBackendSettings#default-excludes
     */
    readonly defaultExcludes?: boolean;
    /**
     * The name of the module directory inside `module-root`.
     *
     * The default module name is the package name with dots and dashes replaced by underscores.
     *
     * Package names need to be valid Python identifiers, and the directory needs to contain a
     * `__init__.py`. An exception are stubs packages, whose name ends with `-stubs`, with the stem
     * being the module name, and which contain a `__init__.pyi` file.
     *
     * For namespace packages with a single module, the path can be dotted, e.g., `foo.bar` or
     * `foo-stubs.bar`.
     *
     * For namespace packages with multiple modules, the path can be a list, e.g.,
     * `["foo", "bar"]`. We recommend using a single module per package, splitting multiple
     * packages into a workspace.
     *
     * Note that using this option runs the risk of creating two packages with different names but
     * the same module names. Installing such packages together leads to unspecified behavior,
     * often with corrupted files or directory trees.
     *
     * @schema BuildBackendSettings#module-name
     */
    readonly moduleName?: any;
    /**
     * The directory that contains the module directory.
     *
     * Common values are `src` (src layout, the default) or an empty path (flat layout).
     *
     * @schema BuildBackendSettings#module-root
     */
    readonly moduleRoot?: string;
    /**
     * Build a namespace package.
     *
     * Build a PEP 420 implicit namespace package, allowing more than one root `__init__.py`.
     *
     * Use this option when the namespace package contains multiple root `__init__.py`, for
     * namespace packages with a single root `__init__.py` use a dotted `module-name` instead.
     *
     * To compare dotted `module-name` and `namespace = true`, the first example below can be
     * expressed with `module-name = "cloud.database"`: There is one root `__init__.py` `database`.
     * In the second example, we have three roots (`cloud.database`, `cloud.database_pro`,
     * `billing.modules.database_pro`), so `namespace = true` is required.
     *
     * ```text
     * src
     * └── cloud
     * └── database
     * ├── __init__.py
     * ├── query_builder
     * │   └── __init__.py
     * └── sql
     * ├── parser.py
     * └── __init__.py
     * ```
     *
     * ```text
     * src
     * ├── cloud
     * │   ├── database
     * │   │   ├── __init__.py
     * │   │   ├── query_builder
     * │   │   │   └── __init__.py
     * │   │   └── sql
     * │   │       ├── __init__.py
     * │   │       └── parser.py
     * │   └── database_pro
     * │       ├── __init__.py
     * │       └── query_builder.py
     * └── billing
     * └── modules
     * └── database_pro
     * ├── __init__.py
     * └── sql.py
     * ```
     *
     * @schema BuildBackendSettings#namespace
     */
    readonly namespace?: boolean;
    /**
     * Glob expressions which files and directories to exclude from the source distribution.
     *
     * These exclusions are also applied to wheels to ensure that a wheel built from a source tree
     * is consistent with a wheel built from a source distribution.
     *
     * @schema BuildBackendSettings#source-exclude
     */
    readonly sourceExclude?: string[];
    /**
     * Glob expressions which files and directories to additionally include in the source
     * distribution.
     *
     * `pyproject.toml` and the contents of the module directory are always included.
     *
     * @schema BuildBackendSettings#source-include
     */
    readonly sourceInclude?: string[];
    /**
     * Glob expressions which files and directories to exclude from the wheel.
     *
     * @schema BuildBackendSettings#wheel-exclude
     */
    readonly wheelExclude?: string[];
}
/**
 * Converts an object of type 'BuildBackendSettings' to JSON representation.
 * @internal
 */
export declare function toJson_BuildBackendSettings(obj: BuildBackendSettings | undefined): Record<string, any> | undefined;
/**
 * A single item in a conflicting set.
 *
 * Each item is a pair of an (optional) package and a corresponding extra or group name for that
 * package.
 *
 * @schema SchemaConflictItem
 */
export interface SchemaConflictItem {
    /**
     * @schema SchemaConflictItem#extra
     */
    readonly extra?: string;
    /**
     * @schema SchemaConflictItem#group
     */
    readonly group?: string;
    /**
     * @schema SchemaConflictItem#package
     */
    readonly package?: string;
}
/**
 * Converts an object of type 'SchemaConflictItem' to JSON representation.
 * @internal
 */
export declare function toJson_SchemaConflictItem(obj: SchemaConflictItem | undefined): Record<string, any> | undefined;
/**
 * @schema DependencyGroupSettings
 */
export interface DependencyGroupSettings {
    /**
     * Version of python to require when installing this group
     *
     * @schema DependencyGroupSettings#requires-python
     */
    readonly requiresPython?: string;
}
/**
 * Converts an object of type 'DependencyGroupSettings' to JSON representation.
 * @internal
 */
export declare function toJson_DependencyGroupSettings(obj: DependencyGroupSettings | undefined): Record<string, any> | undefined;
/**
 * A subset of the Python Package Metadata 2.3 standard as specified in
 * <https://packaging.python.org/specifications/core-metadata/>.
 *
 * @schema StaticMetadata
 */
export interface StaticMetadata {
    /**
     * @schema StaticMetadata#name
     */
    readonly name: string;
    /**
     * @schema StaticMetadata#provides-extra
     */
    readonly providesExtra?: string[];
    /**
     * @schema StaticMetadata#requires-dist
     */
    readonly requiresDist?: string[];
    /**
     * PEP 508-style Python requirement, e.g., `>=3.10`
     *
     * @schema StaticMetadata#requires-python
     */
    readonly requiresPython?: string;
    /**
     * PEP 440-style package version, e.g., `1.2.3`
     *
     * @schema StaticMetadata#version
     */
    readonly version?: string;
}
/**
 * Converts an object of type 'StaticMetadata' to JSON representation.
 * @internal
 */
export declare function toJson_StaticMetadata(obj: StaticMetadata | undefined): Record<string, any> | undefined;
/**
 * @schema ExcludeNewerOverride
 */
export declare class ExcludeNewerOverride {
    readonly value: boolean | string;
    static fromBoolean(value: boolean): ExcludeNewerOverride;
    static fromString(value: string): ExcludeNewerOverride;
    private constructor();
}
/**
 * @schema ForkStrategy
 */
export declare enum ForkStrategy {
    /** Optimize for selecting the fewest number of versions for each package. Older versions may
  be preferred if they are compatible with a wider range of supported Python versions or
  platforms. (fewest) */
    FEWEST = "fewest",
    /** Optimize for selecting latest supported version of each package, for each supported Python
  version. (requires-python) */
    REQUIRES_HYPHEN_PYTHON = "requires-python"
}
/**
 * @schema Index
 */
export interface Index {
    /**
     * When uv should use authentication for requests to the index.
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "my-index"
     * url = "https://<omitted>/simple"
     * authenticate = "always"
     * ```
     *
     * @schema Index#authenticate
     */
    readonly authenticate?: AuthPolicy;
    /**
     * Cache control configuration for this index.
     *
     * When set, these headers will override the server's cache control headers
     * for both package metadata requests and artifact downloads.
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "my-index"
     * url = "https://<omitted>/simple"
     * cache-control = { api = "max-age=600", files = "max-age=3600" }
     * ```
     *
     * @schema Index#cache-control
     */
    readonly cacheControl?: IndexCacheControl;
    /**
     * Mark the index as the default index.
     *
     * By default, uv uses PyPI as the default index, such that even if additional indexes are
     * defined via `[[tool.uv.index]]`, PyPI will still be used as a fallback for packages that
     * aren't found elsewhere. To disable the PyPI default, set `default = true` on at least one
     * other index.
     *
     * Marking an index as default will move it to the front of the list of indexes, such that it
     * is given the highest priority when resolving packages.
     *
     * @schema Index#default
     */
    readonly default?: boolean;
    /**
     * An index-specific `exclude-newer` cutoff.
     *
     * Accepts the same date, timestamp, and duration values as the global `exclude-newer`
     * setting. Set this to `false` to disable `exclude-newer` for this index entirely.
     *
     * When set to a value, packages resolved from this index will use that cutoff instead of the
     * globally-specified value, unless a package-specific `exclude-newer-package` override is
     * present.
     *
     * This option is in preview and may change in any future release.
     *
     * ```toml
     * [tool.uv]
     * exclude-newer = "2025-01-01T00:00:00Z"
     *
     * [[tool.uv.index]]
     * name = "internal"
     * url = "https://internal.example.com/simple"
     * exclude-newer = "7 days"
     * ```
     *
     * @schema Index#exclude-newer
     */
    readonly excludeNewer?: ExcludeNewerOverride;
    /**
     * Mark the index as explicit.
     *
     * Explicit indexes will _only_ be used when explicitly requested via a `[tool.uv.sources]`
     * definition, as in:
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "pytorch"
     * url = "https://download.pytorch.org/whl/cu130"
     * explicit = true
     *
     * [tool.uv.sources]
     * torch = { index = "pytorch" }
     * ```
     *
     * @schema Index#explicit
     */
    readonly explicit?: boolean;
    /**
     * The format used by the index.
     *
     * Indexes can either be PEP 503-compliant (i.e., a PyPI-style registry implementing the Simple
     * API) or structured as a flat list of distributions (e.g., `--find-links`). In both cases,
     * indexes can point to either local or remote resources.
     *
     * @schema Index#format
     */
    readonly format?: IndexFormat;
    /**
     * Status codes that uv should ignore when deciding whether to continue resolution after a
     * request to this index fails.
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "my-index"
     * url = "https://<omitted>/simple"
     * ignore-error-codes = [401, 403]
     * ```
     *
     * @schema Index#ignore-error-codes
     */
    readonly ignoreErrorCodes?: number[];
    /**
     * The name of the index.
     *
     * Index names can be used to reference indexes elsewhere in the configuration. For example,
     * you can pin a package to a specific index by name:
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "pytorch"
     * url = "https://download.pytorch.org/whl/cu130"
     *
     * [tool.uv.sources]
     * torch = { index = "pytorch" }
     * ```
     *
     * @schema Index#name
     */
    readonly name?: string;
    /**
     * The URL of the upload endpoint.
     *
     * When using `uv publish --index <name>`, this URL is used for publishing.
     *
     * A configuration for the default index PyPI would look as follows:
     *
     * ```toml
     * [[tool.uv.index]]
     * name = "pypi"
     * url = "https://pypi.org/simple"
     * publish-url = "https://upload.pypi.org/legacy/"
     * ```
     *
     * @schema Index#publish-url
     */
    readonly publishUrl?: string;
    /**
     * The URL of the index.
     *
     * Expects to receive a URL (e.g., `https://pypi.org/simple`) or a local path.
     *
     * @schema Index#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'Index' to JSON representation.
 * @internal
 */
export declare function toJson_Index(obj: Index | undefined): Record<string, any> | undefined;
/**
 * @schema IndexStrategy
 */
export declare enum IndexStrategy {
    /** Only use results from the first index that returns a match for a given package name.
  
  While this differs from pip's behavior, it's the default index strategy as it's the most
  secure. (first-index) */
    FIRST_HYPHEN_INDEX = "first-index",
    /** Search for every package name across all indexes, exhausting the versions from the first
  index before moving on to the next.
  
  In this strategy, we look for every package across all indexes. When resolving, we attempt
  to use versions from the indexes in order, such that we exhaust all available versions from
  the first index before moving on to the next. Further, if a version is found to be
  incompatible in the first index, we do not reconsider that version in subsequent indexes,
  even if the secondary index might contain compatible versions (e.g., variants of the same
  versions with different ABI tags or Python version constraints).
  
  See: <https://peps.python.org/pep-0708/> (unsafe-first-match) */
    UNSAFE_HYPHEN_FIRST_HYPHEN_MATCH = "unsafe-first-match",
    /** Search for every package name across all indexes, preferring the "best" version found. If a
  package version is in multiple indexes, only look at the entry for the first index.
  
  In this strategy, we look for every package across all indexes. When resolving, we consider
  all versions from all indexes, choosing the "best" version found (typically, the highest
  compatible version).
  
  This most closely matches pip's behavior, but exposes the resolver to "dependency confusion"
  attacks whereby malicious actors can publish packages to public indexes with the same name
  as internal packages, causing the resolver to install the malicious package in lieu of
  the intended internal package.
  
  See: <https://peps.python.org/pep-0708/> (unsafe-best-match) */
    UNSAFE_HYPHEN_BEST_HYPHEN_MATCH = "unsafe-best-match"
}
/**
 * Keyring provider type to use for credential lookup.
 *
 * @schema KeyringProviderType
 */
export declare enum KeyringProviderType {
    /** Do not use keyring for credential lookup. (disabled) */
    DISABLED = "disabled",
    /** Use the `keyring` command for credential lookup. (subprocess) */
    SUBPROCESS = "subprocess"
}
/**
 * The method to use when linking.
 *
 * Defaults to [`LinkMode::Clone`] on macOS and Linux (which support copy-on-write on
 * APFS and btrfs/xfs/bcachefs respectively), and [`LinkMode::Hardlink`] on other
 * platforms.
 *
 * @default LinkMode::Clone`] on macOS and Linux (which support copy-on-write on
 * @schema LinkMode
 */
export declare enum LinkMode {
    /** Clone (i.e., copy-on-write) packages from the source into the destination. (clone) */
    CLONE = "clone",
    /** Copy packages from the source into the destination. (copy) */
    COPY = "copy",
    /** Hard link packages from the source into the destination. (hardlink) */
    HARDLINK = "hardlink",
    /** Symbolically link packages from the source into the destination. (symlink) */
    SYMLINK = "symlink"
}
/**
 * Settings that are specific to the `uv pip` command-line interface.
 *
 * These values will be ignored when running commands outside the `uv pip` namespace (e.g.,
 * `uv lock`, `uvx`).
 *
 * @schema PipOptions
 */
export interface PipOptions {
    /**
     * Include all optional dependencies.
     *
     * Only applies to `pyproject.toml`, `setup.py`, and `setup.cfg` sources.
     *
     * @schema PipOptions#all-extras
     */
    readonly allExtras?: boolean;
    /**
     * Allow `uv pip sync` with empty requirements, which will clear the environment of all
     * packages.
     *
     * @schema PipOptions#allow-empty-requirements
     */
    readonly allowEmptyRequirements?: boolean;
    /**
     * The style of the annotation comments included in the output file, used to indicate the
     * source of each package.
     *
     * @schema PipOptions#annotation-style
     */
    readonly annotationStyle?: AnnotationStyle;
    /**
     * Allow uv to modify an `EXTERNALLY-MANAGED` Python installation.
     *
     * WARNING: `--break-system-packages` is intended for use in continuous integration (CI)
     * environments, when installing into Python installations that are managed by an external
     * package manager, like `apt`. It should be used with caution, as such Python installations
     * explicitly recommend against modifications by other package managers (like uv or pip).
     *
     * @schema PipOptions#break-system-packages
     */
    readonly breakSystemPackages?: boolean;
    /**
     * Compile Python files to bytecode after installation.
     *
     * By default, uv does not compile Python (`.py`) files to bytecode (`__pycache__/*.pyc`);
     * instead, compilation is performed lazily the first time a module is imported. For use-cases
     * in which start time is critical, such as CLI applications and Docker containers, this option
     * can be enabled to trade longer installation times for faster start times.
     *
     * When enabled, uv will process the entire site-packages directory (including packages that
     * are not being modified by the current operation) for consistency. Like pip, it will also
     * ignore errors.
     *
     * @schema PipOptions#compile-bytecode
     */
    readonly compileBytecode?: boolean;
    /**
     * Settings to pass to the [PEP 517](https://peps.python.org/pep-0517/) build backend,
     * specified as `KEY=VALUE` pairs.
     *
     * @schema PipOptions#config-settings
     */
    readonly configSettings?: {
        [key: string]: any;
    };
    /**
     * Settings to pass to the [PEP 517](https://peps.python.org/pep-0517/) build backend for specific packages,
     * specified as `KEY=VALUE` pairs.
     *
     * @schema PipOptions#config-settings-package
     */
    readonly configSettingsPackage?: {
        [key: string]: {
            [key: string]: any;
        };
    };
    /**
     * The header comment to include at the top of the output file generated by `uv pip compile`.
     *
     * Used to reflect custom build scripts and commands that wrap `uv pip compile`.
     *
     * @schema PipOptions#custom-compile-command
     */
    readonly customCompileCommand?: string;
    /**
     * Pre-defined static metadata for dependencies of the project (direct or transitive). When
     * provided, enables the resolver to use the specified metadata instead of querying the
     * registry or building the relevant package from source.
     *
     * Metadata should be provided in adherence with the [Metadata 2.3](https://packaging.python.org/en/latest/specifications/core-metadata/)
     * standard, though only the following fields are respected:
     *
     * - `name`: The name of the package.
     * - (Optional) `version`: The version of the package. If omitted, the metadata will be applied
     * to all versions of the package.
     * - (Optional) `requires-dist`: The dependencies of the package (e.g., `werkzeug>=0.14`).
     * - (Optional) `requires-python`: The Python version required by the package (e.g., `>=3.10`).
     * - (Optional) `provides-extra`: The extras provided by the package.
     *
     * @schema PipOptions#dependency-metadata
     */
    readonly dependencyMetadata?: StaticMetadata[];
    /**
     * Include `--no-binary` and `--only-binary` entries in the output file generated by `uv pip compile`.
     *
     * @schema PipOptions#emit-build-options
     */
    readonly emitBuildOptions?: boolean;
    /**
     * Include `--find-links` entries in the output file generated by `uv pip compile`.
     *
     * @schema PipOptions#emit-find-links
     */
    readonly emitFindLinks?: boolean;
    /**
     * Include comment annotations indicating the index used to resolve each package (e.g.,
     * `# from https://pypi.org/simple`).
     *
     * @schema PipOptions#emit-index-annotation
     */
    readonly emitIndexAnnotation?: boolean;
    /**
     * Include `--index-url` and `--extra-index-url` entries in the output file generated by `uv pip compile`.
     *
     * @schema PipOptions#emit-index-url
     */
    readonly emitIndexUrl?: boolean;
    /**
     * Whether to emit a marker string indicating the conditions under which the set of pinned
     * dependencies is valid.
     *
     * The pinned dependencies may be valid even when the marker expression is
     * false, but when the expression is true, the requirements are known to
     * be correct.
     *
     * @schema PipOptions#emit-marker-expression
     */
    readonly emitMarkerExpression?: boolean;
    /**
     * Limit candidate packages to those that were uploaded prior to a given point in time.
     *
     * The date is compared against the upload time of each individual distribution artifact
     * (i.e., when each file was uploaded to the package index), not the release date of the
     * package version.
     *
     * Accepts RFC 3339 timestamps (e.g., `2006-12-02T02:07:43Z`), a "friendly" duration (e.g.,
     * `24 hours`, `1 week`, `30 days`), or an ISO 8601 duration (e.g., `PT24H`, `P7D`, `P30D`).
     *
     * Durations do not respect semantics of the local time zone and are always resolved to a fixed
     * number of seconds assuming that a day is 24 hours (e.g., DST transitions are ignored).
     * Calendar units such as months and years are not allowed.
     *
     * Set to `false` to disable `exclude-newer`.
     *
     * @schema PipOptions#exclude-newer
     */
    readonly excludeNewer?: ExcludeNewerOverride;
    /**
     * Limit candidate packages for specific packages to those that were uploaded prior to the given date.
     *
     * Accepts a dictionary format of `PACKAGE = "DATE"` pairs, where `DATE` is an RFC 3339
     * timestamp (e.g., `2006-12-02T02:07:43Z`), a "friendly" duration (e.g., `24 hours`, `1 week`,
     * `30 days`), or a ISO 8601 duration (e.g., `PT24H`, `P7D`, `P30D`).
     *
     * Durations do not respect semantics of the local time zone and are always resolved to a fixed
     * number of seconds assuming that a day is 24 hours (e.g., DST transitions are ignored).
     * Calendar units such as months and years are not allowed.
     *
     * Set a package to `false` to exempt it from the global [`exclude-newer`](#exclude-newer)
     * constraint entirely.
     *
     * @schema PipOptions#exclude-newer-package
     */
    readonly excludeNewerPackage?: {
        [key: string]: ExcludeNewerOverride;
    };
    /**
     * Include optional dependencies from the specified extra; may be provided more than once.
     *
     * Only applies to `pyproject.toml`, `setup.py`, and `setup.cfg` sources.
     *
     * @schema PipOptions#extra
     */
    readonly extra?: string[];
    /**
     * Additional build dependencies for packages.
     *
     * This allows extending the PEP 517 build environment for the project's dependencies with
     * additional packages. This is useful for packages that assume the presence of packages like
     * `pip`, and do not declare them as build dependencies.
     *
     * @schema PipOptions#extra-build-dependencies
     */
    readonly extraBuildDependencies?: {
        [key: string]: any[];
    };
    /**
     * Extra environment variables to set when building certain packages.
     *
     * Environment variables will be added to the environment when building the
     * specified packages.
     *
     * @schema PipOptions#extra-build-variables
     */
    readonly extraBuildVariables?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
     * Extra URLs of package indexes to use, in addition to `--index-url`.
     *
     * Accepts either a repository compliant with [PEP 503](https://peps.python.org/pep-0503/)
     * (the simple repository API), or a local directory laid out in the same format.
     *
     * All indexes provided via this flag take priority over the index specified by
     * [`index_url`](#index-url). When multiple indexes are provided, earlier values take priority.
     *
     * To control uv's resolution strategy when multiple indexes are present, see
     * [`index_strategy`](#index-strategy).
     *
     * @schema PipOptions#extra-index-url
     */
    readonly extraIndexUrl?: string[];
    /**
     * Locations to search for candidate distributions, in addition to those found in the registry
     * indexes.
     *
     * If a path, the target must be a directory that contains packages as wheel files (`.whl`) or
     * source distributions (e.g., `.tar.gz` or `.zip`) at the top level.
     *
     * If a URL, the page must contain a flat list of links to package files adhering to the
     * formats described above.
     *
     * @schema PipOptions#find-links
     */
    readonly findLinks?: string[];
    /**
     * The strategy to use when selecting multiple versions of a given package across Python
     * versions and platforms.
     *
     * By default, uv will optimize for selecting the latest version of each package for each
     * supported Python version (`requires-python`), while minimizing the number of selected
     * versions across platforms.
     *
     * Under `fewest`, uv will minimize the number of selected versions for each package,
     * preferring older versions that are compatible with a wider range of supported Python
     * versions or platforms.
     *
     * @schema PipOptions#fork-strategy
     */
    readonly forkStrategy?: ForkStrategy;
    /**
     * Include distribution hashes in the output file.
     *
     * @schema PipOptions#generate-hashes
     */
    readonly generateHashes?: boolean;
    /**
     * Include the following dependency groups.
     *
     * @schema PipOptions#group
     */
    readonly group?: PipGroupName[];
    /**
     * The strategy to use when resolving against multiple index URLs.
     *
     * By default, uv will stop at the first index on which a given package is available, and
     * limit resolutions to those present on that first index (`first-index`). This prevents
     * "dependency confusion" attacks, whereby an attacker can upload a malicious package under the
     * same name to an alternate index.
     *
     * @schema PipOptions#index-strategy
     */
    readonly indexStrategy?: IndexStrategy;
    /**
     * The URL of the Python package index (by default: <https://pypi.org/simple>).
     *
     * Accepts either a repository compliant with [PEP 503](https://peps.python.org/pep-0503/)
     * (the simple repository API), or a local directory laid out in the same format.
     *
     * The index provided by this setting is given lower priority than any indexes specified via
     * [`extra_index_url`](#extra-index-url).
     *
     * @schema PipOptions#index-url
     */
    readonly indexUrl?: string;
    /**
     * Attempt to use `keyring` for authentication for index URLs.
     *
     * At present, only `--keyring-provider subprocess` is supported, which configures uv to
     * use the `keyring` CLI to handle authentication.
     *
     * @schema PipOptions#keyring-provider
     */
    readonly keyringProvider?: KeyringProviderType;
    /**
     * The method to use when installing packages from the global cache.
     *
     * Defaults to `clone` (also known as Copy-on-Write) on macOS and Linux, and `hardlink` on
     * Windows.
     *
     * WARNING: The use of symlink link mode is discouraged, as they create tight coupling between
     * the cache and the target environment. For example, clearing the cache (`uv cache clean`)
     * will break all installed packages by way of removing the underlying source files. Use
     * symlinks with caution.
     *
     * @default clone` (also known as Copy-on-Write) on macOS and Linux, and `hardlink` on
     * @schema PipOptions#link-mode
     */
    readonly linkMode?: LinkMode;
    /**
     * Exclude comment annotations indicating the source of each package from the output file
     * generated by `uv pip compile`.
     *
     * @schema PipOptions#no-annotate
     */
    readonly noAnnotate?: boolean;
    /**
     * Don't install pre-built wheels.
     *
     * The given packages will be built and installed from source. The resolver will still use
     * pre-built wheels to extract package metadata, if available.
     *
     * Multiple packages may be provided. Disable binaries for all packages with `:all:`.
     * Clear previously specified packages with `:none:`.
     *
     * @schema PipOptions#no-binary
     */
    readonly noBinary?: string[];
    /**
     * Don't build source distributions.
     *
     * When enabled, uv will reuse cached wheels from previously built source distributions, but
     * operations that require building a source distribution will exit with an error. uv may
     * still build editable requirements, and their build backends may run arbitrary Python code.
     *
     * Alias for `--only-binary :all:`.
     *
     * @schema PipOptions#no-build
     */
    readonly noBuild?: boolean;
    /**
     * Disable isolation when building source distributions.
     *
     * Assumes that build dependencies specified by [PEP 518](https://peps.python.org/pep-0518/)
     * are already installed.
     *
     * @schema PipOptions#no-build-isolation
     */
    readonly noBuildIsolation?: boolean;
    /**
     * Disable isolation when building source distributions for a specific package.
     *
     * Assumes that the packages' build dependencies specified by [PEP 518](https://peps.python.org/pep-0518/)
     * are already installed.
     *
     * @schema PipOptions#no-build-isolation-package
     */
    readonly noBuildIsolationPackage?: string[];
    /**
     * Ignore package dependencies, instead only add those packages explicitly listed
     * on the command line to the resulting requirements file.
     *
     * @schema PipOptions#no-deps
     */
    readonly noDeps?: boolean;
    /**
     * Specify a package to omit from the output resolution. Its dependencies will still be
     * included in the resolution. Equivalent to pip-compile's `--unsafe-package` option.
     *
     * @schema PipOptions#no-emit-package
     */
    readonly noEmitPackage?: string[];
    /**
     * Exclude the specified optional dependencies if `all-extras` is supplied.
     *
     * @schema PipOptions#no-extra
     */
    readonly noExtra?: string[];
    /**
     * Exclude the comment header at the top of output file generated by `uv pip compile`.
     *
     * @schema PipOptions#no-header
     */
    readonly noHeader?: boolean;
    /**
     * Ignore all registry indexes (e.g., PyPI), instead relying on direct URL dependencies and
     * those provided via `--find-links`.
     *
     * @schema PipOptions#no-index
     */
    readonly noIndex?: boolean;
    /**
     * Ignore the `tool.uv.sources` table when resolving dependencies. Used to lock against the
     * standards-compliant, publishable package metadata, as opposed to using any local or Git
     * sources.
     *
     * @schema PipOptions#no-sources
     */
    readonly noSources?: boolean;
    /**
     * Ignore `tool.uv.sources` for the specified packages.
     *
     * @schema PipOptions#no-sources-package
     */
    readonly noSourcesPackage?: string[];
    /**
     * Include extras in the output file.
     *
     * By default, uv strips extras, as any packages pulled in by the extras are already included
     * as dependencies in the output file directly. Further, output files generated with
     * `--no-strip-extras` cannot be used as constraints files in `install` and `sync` invocations.
     *
     * @schema PipOptions#no-strip-extras
     */
    readonly noStripExtras?: boolean;
    /**
     * Include environment markers in the output file generated by `uv pip compile`.
     *
     * By default, uv strips environment markers, as the resolution generated by `compile` is
     * only guaranteed to be correct for the target environment.
     *
     * @schema PipOptions#no-strip-markers
     */
    readonly noStripMarkers?: boolean;
    /**
     * Only use pre-built wheels; don't build source distributions.
     *
     * When enabled, uv will reuse cached wheels from previously built source distributions, but
     * operations that require building a source distribution for the given packages will exit
     * with an error. uv may still build editable requirements, and their build backends may run
     * arbitrary Python code.
     *
     * Multiple packages may be provided. Disable binaries for all packages with `:all:`.
     * Clear previously specified packages with `:none:`.
     *
     * @schema PipOptions#only-binary
     */
    readonly onlyBinary?: string[];
    /**
     * Write the requirements generated by `uv pip compile` to the given `requirements.txt` file.
     *
     * If the file already exists, the existing versions will be preferred when resolving
     * dependencies, unless `--upgrade` is also specified.
     *
     * @schema PipOptions#output-file
     */
    readonly outputFile?: string;
    /**
     * Install packages into `lib`, `bin`, and other top-level folders under the specified
     * directory, as if a virtual environment were present at that location.
     *
     * In general, prefer the use of `--python` to install into an alternate environment, as
     * scripts and other artifacts installed via `--prefix` will reference the installing
     * interpreter, rather than any interpreter added to the `--prefix` directory, rendering them
     * non-portable.
     *
     * @schema PipOptions#prefix
     */
    readonly prefix?: string;
    /**
     * The strategy to use when considering pre-release versions.
     *
     * By default, uv will accept pre-releases for packages that _only_ publish pre-releases,
     * along with first-party requirements that contain an explicit pre-release marker in the
     * declared specifiers (`if-necessary-or-explicit`).
     *
     * @schema PipOptions#prerelease
     */
    readonly prerelease?: PrereleaseMode;
    /**
     * The Python interpreter into which packages should be installed.
     *
     * By default, uv installs into the virtual environment in the current working directory or
     * any parent directory. The `--python` option allows you to specify a different interpreter,
     * which is intended for use in continuous integration (CI) environments or other automated
     * workflows.
     *
     * Supported formats:
     * - `3.10` looks for an installed Python 3.10 in the registry on Windows (see
     * `py --list-paths`), or `python3.10` on Linux and macOS.
     * - `python3.10` or `python.exe` looks for a binary with the given name in `PATH`.
     * - `/home/ferris/.local/bin/python3.10` uses the exact Python at the given path.
     *
     * @schema PipOptions#python
     */
    readonly python?: string;
    /**
     * The platform for which requirements should be resolved.
     *
     * Represented as a "target triple", a string that describes the target platform in terms of
     * its CPU, vendor, and operating system name, like `x86_64-unknown-linux-gnu` or
     * `aarch64-apple-darwin`.
     *
     * @schema PipOptions#python-platform
     */
    readonly pythonPlatform?: TargetTriple;
    /**
     * The minimum Python version that should be supported by the resolved requirements (e.g.,
     * `3.8` or `3.8.17`).
     *
     * If a patch version is omitted, the minimum patch version is assumed. For example, `3.8` is
     * mapped to `3.8.0`.
     *
     * @schema PipOptions#python-version
     */
    readonly pythonVersion?: string;
    /**
     * Reinstall all packages, regardless of whether they're already installed. Implies `refresh`.
     *
     * @schema PipOptions#reinstall
     */
    readonly reinstall?: boolean;
    /**
     * Reinstall a specific package, regardless of whether it's already installed. Implies
     * `refresh-package`.
     *
     * @schema PipOptions#reinstall-package
     */
    readonly reinstallPackage?: string[];
    /**
     * Require a matching hash for each requirement.
     *
     * Hash-checking mode is all or nothing. If enabled, _all_ requirements must be provided
     * with a corresponding hash or set of hashes. Additionally, if enabled, _all_ requirements
     * must either be pinned to exact versions (e.g., `==1.0.0`), or be specified via direct URL.
     *
     * Hash-checking mode introduces a number of additional constraints:
     *
     * - Git dependencies are not supported.
     * - Editable installations are not supported.
     * - Local dependencies are not supported, unless they point to a specific wheel (`.whl`) or
     * source archive (`.zip`, `.tar.gz`), as opposed to a directory.
     *
     * @schema PipOptions#require-hashes
     */
    readonly requireHashes?: boolean;
    /**
     * The strategy to use when selecting between the different compatible versions for a given
     * package requirement.
     *
     * By default, uv will use the latest compatible version of each package (`highest`).
     *
     * @schema PipOptions#resolution
     */
    readonly resolution?: ResolutionMode;
    /**
     * Validate the Python environment, to detect packages with missing dependencies and other
     * issues.
     *
     * @schema PipOptions#strict
     */
    readonly strict?: boolean;
    /**
     * Install packages into the system Python environment.
     *
     * By default, uv installs into the virtual environment in the current working directory or
     * any parent directory. The `--system` option instructs uv to instead use the first Python
     * found in the system `PATH`.
     *
     * WARNING: `--system` is intended for use in continuous integration (CI) environments and
     * should be used with caution, as it can modify the system Python installation.
     *
     * @schema PipOptions#system
     */
    readonly system?: boolean;
    /**
     * Install packages into the specified directory, rather than into the virtual or system Python
     * environment. The packages will be installed at the top-level of the directory.
     *
     * @schema PipOptions#target
     */
    readonly target?: string;
    /**
     * The backend to use when fetching packages in the PyTorch ecosystem.
     *
     * When set, uv will ignore the configured index URLs for packages in the PyTorch ecosystem,
     * and will instead use the defined backend.
     *
     * For example, when set to `cpu`, uv will use the CPU-only PyTorch index; when set to `cu126`,
     * uv will use the PyTorch index for CUDA 12.6.
     *
     * The `auto` mode will attempt to detect the appropriate PyTorch index based on the currently
     * installed CUDA drivers.
     *
     * This setting is only respected by `uv pip` commands.
     *
     * This option is in preview and may change in any future release.
     *
     * @schema PipOptions#torch-backend
     */
    readonly torchBackend?: TorchMode;
    /**
     * Perform a universal resolution, attempting to generate a single `requirements.txt` output
     * file that is compatible with all operating systems, architectures, and Python
     * implementations.
     *
     * In universal mode, the current Python version (or user-provided `--python-version`) will be
     * treated as a lower bound. For example, `--universal --python-version 3.7` would produce a
     * universal resolution for Python 3.7 and later.
     *
     * @schema PipOptions#universal
     */
    readonly universal?: boolean;
    /**
     * Allow package upgrades, ignoring pinned versions in any existing output file.
     *
     * @schema PipOptions#upgrade
     */
    readonly upgrade?: boolean;
    /**
     * Allow upgrades for a specific package, ignoring pinned versions in any existing output
     * file.
     *
     * Accepts both standalone package names (`ruff`) and version specifiers (`ruff<0.5.0`).
     *
     * @schema PipOptions#upgrade-package
     */
    readonly upgradePackage?: string[];
    /**
     * Validate any hashes provided in the requirements file.
     *
     * Unlike `--require-hashes`, `--verify-hashes` does not require that all requirements have
     * hashes; instead, it will limit itself to verifying the hashes of those requirements that do
     * include them.
     *
     * @schema PipOptions#verify-hashes
     */
    readonly verifyHashes?: boolean;
}
/**
 * Converts an object of type 'PipOptions' to JSON representation.
 * @internal
 */
export declare function toJson_PipOptions(obj: PipOptions | undefined): Record<string, any> | undefined;
/**
 * @schema PrereleaseMode
 */
export declare enum PrereleaseMode {
    /** Disallow all pre-release versions. (disallow) */
    DISALLOW = "disallow",
    /** Allow all pre-release versions. (allow) */
    ALLOW = "allow",
    /** Allow pre-release versions if all versions of a package are pre-release. (if-necessary) */
    IF_HYPHEN_NECESSARY = "if-necessary",
    /** Allow pre-release versions for first-party packages with explicit pre-release markers in
  their version requirements. (explicit) */
    EXPLICIT = "explicit",
    /** Allow pre-release versions if all versions of a package are pre-release, or if the package
  has an explicit pre-release marker in its version requirements. (if-necessary-or-explicit) */
    IF_HYPHEN_NECESSARY_HYPHEN_OR_HYPHEN_EXPLICIT = "if-necessary-or-explicit"
}
/**
 * @schema PythonDownloads
 */
export declare enum PythonDownloads {
    /** Automatically download managed Python installations when needed. (automatic) */
    AUTOMATIC = "automatic",
    /** Do not automatically download managed Python installations; require explicit installation. (manual) */
    MANUAL = "manual",
    /** Do not ever allow Python downloads. (never) */
    NEVER = "never"
}
/**
 * @schema PythonPreference
 */
export declare enum PythonPreference {
    /** Only use managed Python installations; never use system Python installations. (only-managed) */
    ONLY_HYPHEN_MANAGED = "only-managed",
    /** Prefer managed Python installations over system Python installations.
  
  System Python installations are still preferred over downloading managed Python versions.
  Use `only-managed` to always fetch a managed Python version. (managed) */
    MANAGED = "managed",
    /** Prefer system Python installations over managed Python installations.
  
  If a system Python installation cannot be found, a managed Python installation can be used. (system) */
    SYSTEM = "system",
    /** Only use system Python installations; never use managed Python installations. (only-system) */
    ONLY_HYPHEN_SYSTEM = "only-system"
}
/**
 * @schema ResolutionMode
 */
export declare enum ResolutionMode {
    /** Resolve the highest compatible version of each package. (highest) */
    HIGHEST = "highest",
    /** Resolve the lowest compatible version of each package. (lowest) */
    LOWEST = "lowest",
    /** Resolve the lowest compatible version of any direct dependencies, and the highest
  compatible version of any transitive dependencies. (lowest-direct) */
    LOWEST_HYPHEN_DIRECT = "lowest-direct"
}
/**
 * The strategy to use when determining the appropriate PyTorch index.
 *
 * @schema TorchMode
 */
export declare enum TorchMode {
    /** Select the appropriate PyTorch index based on the operating system and CUDA driver version. (auto) */
    AUTO = "auto",
    /** Use the CPU-only PyTorch index. (cpu) */
    CPU = "cpu",
    /** Use the PyTorch index for CUDA 13.2. (cu132) */
    CU132 = "cu132",
    /** Use the PyTorch index for CUDA 13.0. (cu130) */
    CU130 = "cu130",
    /** Use the PyTorch index for CUDA 12.9. (cu129) */
    CU129 = "cu129",
    /** Use the PyTorch index for CUDA 12.8. (cu128) */
    CU128 = "cu128",
    /** Use the PyTorch index for CUDA 12.6. (cu126) */
    CU126 = "cu126",
    /** Use the PyTorch index for CUDA 12.5. (cu125) */
    CU125 = "cu125",
    /** Use the PyTorch index for CUDA 12.4. (cu124) */
    CU124 = "cu124",
    /** Use the PyTorch index for CUDA 12.3. (cu123) */
    CU123 = "cu123",
    /** Use the PyTorch index for CUDA 12.2. (cu122) */
    CU122 = "cu122",
    /** Use the PyTorch index for CUDA 12.1. (cu121) */
    CU121 = "cu121",
    /** Use the PyTorch index for CUDA 12.0. (cu120) */
    CU120 = "cu120",
    /** Use the PyTorch index for CUDA 11.8. (cu118) */
    CU118 = "cu118",
    /** Use the PyTorch index for CUDA 11.7. (cu117) */
    CU117 = "cu117",
    /** Use the PyTorch index for CUDA 11.6. (cu116) */
    CU116 = "cu116",
    /** Use the PyTorch index for CUDA 11.5. (cu115) */
    CU115 = "cu115",
    /** Use the PyTorch index for CUDA 11.4. (cu114) */
    CU114 = "cu114",
    /** Use the PyTorch index for CUDA 11.3. (cu113) */
    CU113 = "cu113",
    /** Use the PyTorch index for CUDA 11.2. (cu112) */
    CU112 = "cu112",
    /** Use the PyTorch index for CUDA 11.1. (cu111) */
    CU111 = "cu111",
    /** Use the PyTorch index for CUDA 11.0. (cu110) */
    CU110 = "cu110",
    /** Use the PyTorch index for CUDA 10.2. (cu102) */
    CU102 = "cu102",
    /** Use the PyTorch index for CUDA 10.1. (cu101) */
    CU101 = "cu101",
    /** Use the PyTorch index for CUDA 10.0. (cu100) */
    CU100 = "cu100",
    /** Use the PyTorch index for CUDA 9.2. (cu92) */
    CU92 = "cu92",
    /** Use the PyTorch index for CUDA 9.1. (cu91) */
    CU91 = "cu91",
    /** Use the PyTorch index for CUDA 9.0. (cu90) */
    CU90 = "cu90",
    /** Use the PyTorch index for CUDA 8.0. (cu80) */
    CU80 = "cu80",
    /** Use the PyTorch index for ROCm 7.2. (rocm7.2) */
    ROCM7_2 = "rocm7.2",
    /** Use the PyTorch index for ROCm 7.1. (rocm7.1) */
    ROCM7_1 = "rocm7.1",
    /** Use the PyTorch index for ROCm 7.0. (rocm7.0) */
    ROCM7_0 = "rocm7.0",
    /** Use the PyTorch index for ROCm 6.4. (rocm6.4) */
    ROCM6_4 = "rocm6.4",
    /** Use the PyTorch index for ROCm 6.3. (rocm6.3) */
    ROCM6_3 = "rocm6.3",
    /** Use the PyTorch index for ROCm 6.2.4. (rocm6.2.4) */
    ROCM6_2_4 = "rocm6.2.4",
    /** Use the PyTorch index for ROCm 6.2. (rocm6.2) */
    ROCM6_2 = "rocm6.2",
    /** Use the PyTorch index for ROCm 6.1. (rocm6.1) */
    ROCM6_1 = "rocm6.1",
    /** Use the PyTorch index for ROCm 6.0. (rocm6.0) */
    ROCM6_0 = "rocm6.0",
    /** Use the PyTorch index for ROCm 5.7. (rocm5.7) */
    ROCM5_7 = "rocm5.7",
    /** Use the PyTorch index for ROCm 5.6. (rocm5.6) */
    ROCM5_6 = "rocm5.6",
    /** Use the PyTorch index for ROCm 5.5. (rocm5.5) */
    ROCM5_5 = "rocm5.5",
    /** Use the PyTorch index for ROCm 5.4.2. (rocm5.4.2) */
    ROCM5_4_2 = "rocm5.4.2",
    /** Use the PyTorch index for ROCm 5.4. (rocm5.4) */
    ROCM5_4 = "rocm5.4",
    /** Use the PyTorch index for ROCm 5.3. (rocm5.3) */
    ROCM5_3 = "rocm5.3",
    /** Use the PyTorch index for ROCm 5.2. (rocm5.2) */
    ROCM5_2 = "rocm5.2",
    /** Use the PyTorch index for ROCm 5.1.1. (rocm5.1.1) */
    ROCM5_1_1 = "rocm5.1.1",
    /** Use the PyTorch index for ROCm 4.2. (rocm4.2) */
    ROCM4_2 = "rocm4.2",
    /** Use the PyTorch index for ROCm 4.1. (rocm4.1) */
    ROCM4_1 = "rocm4.1",
    /** Use the PyTorch index for ROCm 4.0.1. (rocm4.0.1) */
    ROCM4_0_1 = "rocm4.0.1",
    /** Use the PyTorch index for Intel XPU. (xpu) */
    XPU = "xpu"
}
/**
 * @schema TrustedPublishing
 */
export declare enum TrustedPublishing {
    /** always */
    ALWAYS = "always",
    /** never */
    NEVER = "never",
    /** Attempt trusted publishing when we're in a supported environment, continue if that fails.
  
  Supported environments include GitHub Actions and GitLab CI/CD. (automatic) */
    AUTOMATIC = "automatic"
}
/**
 * @schema ToolUvWorkspace
 */
export interface ToolUvWorkspace {
    /**
     * Packages to exclude as workspace members. If a package matches both `members` and
     * `exclude`, it will be excluded.
     *
     * Supports both globs and explicit paths.
     *
     * For more information on the glob syntax, refer to the [`glob` documentation](https://docs.rs/glob/latest/glob/struct.Pattern.html).
     *
     * @schema ToolUvWorkspace#exclude
     */
    readonly exclude?: string[];
    /**
     * Packages to include as workspace members.
     *
     * Supports both globs and explicit paths.
     *
     * For more information on the glob syntax, refer to the [`glob` documentation](https://docs.rs/glob/latest/glob/struct.Pattern.html).
     *
     * @schema ToolUvWorkspace#members
     */
    readonly members?: string[];
}
/**
 * Converts an object of type 'ToolUvWorkspace' to JSON representation.
 * @internal
 */
export declare function toJson_ToolUvWorkspace(obj: ToolUvWorkspace | undefined): Record<string, any> | undefined;
/**
 * Data includes for wheels.
 *
 * See `BuildBackendSettings::data`.
 *
 * @schema WheelDataIncludes
 */
export interface WheelDataIncludes {
    /**
     * @schema WheelDataIncludes#data
     */
    readonly data?: string;
    /**
     * @schema WheelDataIncludes#headers
     */
    readonly headers?: string;
    /**
     * @schema WheelDataIncludes#platlib
     */
    readonly platlib?: string;
    /**
     * @schema WheelDataIncludes#purelib
     */
    readonly purelib?: string;
    /**
     * @schema WheelDataIncludes#scripts
     */
    readonly scripts?: string;
}
/**
 * Converts an object of type 'WheelDataIncludes' to JSON representation.
 * @internal
 */
export declare function toJson_WheelDataIncludes(obj: WheelDataIncludes | undefined): Record<string, any> | undefined;
/**
 * When to use authentication.
 *
 * @schema AuthPolicy
 */
export declare enum AuthPolicy {
    /** Authenticate when necessary.
  
  If credentials are provided, they will be used. Otherwise, an unauthenticated request will
  be attempted first. If the request fails, uv will search for credentials. If credentials are
  found, an authenticated request will be attempted. (auto) */
    AUTO = "auto",
    /** Always authenticate.
  
  If credentials are not provided, uv will eagerly search for credentials. If credentials
  cannot be found, uv will error instead of attempting an unauthenticated request. (always) */
    ALWAYS = "always",
    /** Never authenticate.
  
  If credentials are provided, uv will error. uv will not search for credentials. (never) */
    NEVER = "never"
}
/**
 * Cache control configuration for an index.
 *
 * @schema IndexCacheControl
 */
export interface IndexCacheControl {
    /**
     * Cache control header for Simple API requests.
     *
     * @schema IndexCacheControl#api
     */
    readonly api?: string;
    /**
     * Cache control header for file downloads.
     *
     * @schema IndexCacheControl#files
     */
    readonly files?: string;
}
/**
 * Converts an object of type 'IndexCacheControl' to JSON representation.
 * @internal
 */
export declare function toJson_IndexCacheControl(obj: IndexCacheControl | undefined): Record<string, any> | undefined;
/**
 * @schema IndexFormat
 */
export declare enum IndexFormat {
    /** A PyPI-style index implementing the Simple Repository API. (simple) */
    SIMPLE = "simple",
    /** A `--find-links`-style index containing a flat list of wheels and source distributions. (flat) */
    FLAT = "flat"
}
/**
 * Indicate the style of annotation comments, used to indicate the dependencies that requested each
 * package.
 *
 * @schema AnnotationStyle
 */
export declare enum AnnotationStyle {
    /** Render the annotations on a single, comma-separated line. (line) */
    LINE = "line",
    /** Render each annotation on its own line. (split) */
    SPLIT = "split"
}
/**
 * The pip-compatible variant of a [`GroupName`].
 *
 * Either <groupname> or <path>:<groupname>.
 * If <path> is omitted it defaults to "pyproject.toml".
 *
 * @schema PipGroupName
 */
export interface PipGroupName {
    /**
     * @schema PipGroupName#name
     */
    readonly name: string;
    /**
     * @schema PipGroupName#path
     */
    readonly path?: string;
}
/**
 * Converts an object of type 'PipGroupName' to JSON representation.
 * @internal
 */
export declare function toJson_PipGroupName(obj: PipGroupName | undefined): Record<string, any> | undefined;
/**
 * The supported target triples. Each triple consists of an architecture, vendor, and operating
 * system.
 *
 * See: <https://doc.rust-lang.org/nightly/rustc/platform-support.html>
 *
 * @schema TargetTriple
 */
export declare enum TargetTriple {
    /** An alias for `x86_64-pc-windows-msvc`, the default target for Windows. (windows) */
    WINDOWS = "windows",
    /** An alias for `x86_64-unknown-linux-gnu`, the default target for Linux. (linux) */
    LINUX = "linux",
    /** An alias for `aarch64-apple-darwin`, the default target for macOS. (macos) */
    MACOS = "macos",
    /** A 64-bit x86 Windows target. (x86_64-pc-windows-msvc) */
    X86_UNDERSCORE_64_HYPHEN_PC_HYPHEN_WINDOWS_HYPHEN_MSVC = "x86_64-pc-windows-msvc",
    /** An ARM64 Windows target. (aarch64-pc-windows-msvc) */
    AARCH64_HYPHEN_PC_HYPHEN_WINDOWS_HYPHEN_MSVC = "aarch64-pc-windows-msvc",
    /** A 32-bit x86 Windows target. (i686-pc-windows-msvc) */
    I686_HYPHEN_PC_HYPHEN_WINDOWS_HYPHEN_MSVC = "i686-pc-windows-msvc",
    /** An x86 Linux target. Equivalent to `x86_64-manylinux_2_28`. (x86_64-unknown-linux-gnu) */
    X86_UNDERSCORE_64_HYPHEN_UNKNOWN_HYPHEN_LINUX_HYPHEN_GNU = "x86_64-unknown-linux-gnu",
    /** An ARM-based macOS target, as seen on Apple Silicon devices
  
  By default, assumes the least-recent, non-EOL macOS version (13.0), but respects
  the `MACOSX_DEPLOYMENT_TARGET` environment variable if set. (aarch64-apple-darwin) */
    AARCH64_HYPHEN_APPLE_HYPHEN_DARWIN = "aarch64-apple-darwin",
    /** An x86 macOS target.
  
  By default, assumes the least-recent, non-EOL macOS version (13.0), but respects
  the `MACOSX_DEPLOYMENT_TARGET` environment variable if set. (x86_64-apple-darwin) */
    X86_UNDERSCORE_64_HYPHEN_APPLE_HYPHEN_DARWIN = "x86_64-apple-darwin",
    /** An ARM64 Linux target. Equivalent to `aarch64-manylinux_2_28`. (aarch64-unknown-linux-gnu) */
    AARCH64_HYPHEN_UNKNOWN_HYPHEN_LINUX_HYPHEN_GNU = "aarch64-unknown-linux-gnu",
    /** An ARM64 Linux target. (aarch64-unknown-linux-musl) */
    AARCH64_HYPHEN_UNKNOWN_HYPHEN_LINUX_HYPHEN_MUSL = "aarch64-unknown-linux-musl",
    /** An `x86_64` Linux target. (x86_64-unknown-linux-musl) */
    X86_UNDERSCORE_64_HYPHEN_UNKNOWN_HYPHEN_LINUX_HYPHEN_MUSL = "x86_64-unknown-linux-musl",
    /** A RISCV64 Linux target. (riscv64-unknown-linux) */
    RISCV64_HYPHEN_UNKNOWN_HYPHEN_LINUX = "riscv64-unknown-linux",
    /** An `x86_64` target for the `manylinux2014` platform. Equivalent to `x86_64-manylinux_2_17`. (x86_64-manylinux2014) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX2014 = "x86_64-manylinux2014",
    /** An `x86_64` target for the `manylinux_2_17` platform. (x86_64-manylinux_2_17) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_17 = "x86_64-manylinux_2_17",
    /** An `x86_64` target for the `manylinux_2_28` platform. (x86_64-manylinux_2_28) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_28 = "x86_64-manylinux_2_28",
    /** An `x86_64` target for the `manylinux_2_31` platform. (x86_64-manylinux_2_31) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_31 = "x86_64-manylinux_2_31",
    /** An `x86_64` target for the `manylinux_2_32` platform. (x86_64-manylinux_2_32) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_32 = "x86_64-manylinux_2_32",
    /** An `x86_64` target for the `manylinux_2_33` platform. (x86_64-manylinux_2_33) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_33 = "x86_64-manylinux_2_33",
    /** An `x86_64` target for the `manylinux_2_34` platform. (x86_64-manylinux_2_34) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_34 = "x86_64-manylinux_2_34",
    /** An `x86_64` target for the `manylinux_2_35` platform. (x86_64-manylinux_2_35) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_35 = "x86_64-manylinux_2_35",
    /** An `x86_64` target for the `manylinux_2_36` platform. (x86_64-manylinux_2_36) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_36 = "x86_64-manylinux_2_36",
    /** An `x86_64` target for the `manylinux_2_37` platform. (x86_64-manylinux_2_37) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_37 = "x86_64-manylinux_2_37",
    /** An `x86_64` target for the `manylinux_2_38` platform. (x86_64-manylinux_2_38) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_38 = "x86_64-manylinux_2_38",
    /** An `x86_64` target for the `manylinux_2_39` platform. (x86_64-manylinux_2_39) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_39 = "x86_64-manylinux_2_39",
    /** An `x86_64` target for the `manylinux_2_40` platform. (x86_64-manylinux_2_40) */
    X86_UNDERSCORE_64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_40 = "x86_64-manylinux_2_40",
    /** An ARM64 target for the `manylinux2014` platform. Equivalent to `aarch64-manylinux_2_17`. (aarch64-manylinux2014) */
    AARCH64_HYPHEN_MANYLINUX2014 = "aarch64-manylinux2014",
    /** An ARM64 target for the `manylinux_2_17` platform. (aarch64-manylinux_2_17) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_17 = "aarch64-manylinux_2_17",
    /** An ARM64 target for the `manylinux_2_28` platform. (aarch64-manylinux_2_28) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_28 = "aarch64-manylinux_2_28",
    /** An ARM64 target for the `manylinux_2_31` platform. (aarch64-manylinux_2_31) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_31 = "aarch64-manylinux_2_31",
    /** An ARM64 target for the `manylinux_2_32` platform. (aarch64-manylinux_2_32) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_32 = "aarch64-manylinux_2_32",
    /** An ARM64 target for the `manylinux_2_33` platform. (aarch64-manylinux_2_33) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_33 = "aarch64-manylinux_2_33",
    /** An ARM64 target for the `manylinux_2_34` platform. (aarch64-manylinux_2_34) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_34 = "aarch64-manylinux_2_34",
    /** An ARM64 target for the `manylinux_2_35` platform. (aarch64-manylinux_2_35) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_35 = "aarch64-manylinux_2_35",
    /** An ARM64 target for the `manylinux_2_36` platform. (aarch64-manylinux_2_36) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_36 = "aarch64-manylinux_2_36",
    /** An ARM64 target for the `manylinux_2_37` platform. (aarch64-manylinux_2_37) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_37 = "aarch64-manylinux_2_37",
    /** An ARM64 target for the `manylinux_2_38` platform. (aarch64-manylinux_2_38) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_38 = "aarch64-manylinux_2_38",
    /** An ARM64 target for the `manylinux_2_39` platform. (aarch64-manylinux_2_39) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_39 = "aarch64-manylinux_2_39",
    /** An ARM64 target for the `manylinux_2_40` platform. (aarch64-manylinux_2_40) */
    AARCH64_HYPHEN_MANYLINUX_UNDERSCORE_2_UNDERSCORE_40 = "aarch64-manylinux_2_40",
    /** An ARM64 Android target.
  
  By default uses Android API level 24, but respects
  the `ANDROID_API_LEVEL` environment variable if set. (aarch64-linux-android) */
    AARCH64_HYPHEN_LINUX_HYPHEN_ANDROID = "aarch64-linux-android",
    /** An `x86_64` Android target.
  
  By default uses Android API level 24, but respects
  the `ANDROID_API_LEVEL` environment variable if set. (x86_64-linux-android) */
    X86_UNDERSCORE_64_HYPHEN_LINUX_HYPHEN_ANDROID = "x86_64-linux-android",
    /** A wasm32 target using the Pyodide 2024 platform. Meant for use with Python 3.12.
  See <https://pyodide.org/en/stable/development/abi/312.html> (wasm32-pyodide2024) */
    WASM32_HYPHEN_PYODIDE2024 = "wasm32-pyodide2024",
    /** A wasm32 target using the Pyodide 2025 platform. Meant for use with Python 3.13.
  See <https://pyodide.org/en/stable/development/abi/313.html> (wasm32-pyodide2025) */
    WASM32_HYPHEN_PYODIDE2025 = "wasm32-pyodide2025",
    /** An ARM64 target for iOS device
  
  By default, iOS 13.0 is used, but respects the `IPHONEOS_DEPLOYMENT_TARGET`
  environment variable if set. (arm64-apple-ios) */
    ARM64_HYPHEN_APPLE_HYPHEN_IOS = "arm64-apple-ios",
    /** An ARM64 target for iOS simulator
  
  By default, iOS 13.0 is used, but respects the `IPHONEOS_DEPLOYMENT_TARGET`
  environment variable if set. (arm64-apple-ios-simulator) */
    ARM64_HYPHEN_APPLE_HYPHEN_IOS_HYPHEN_SIMULATOR = "arm64-apple-ios-simulator",
    /** An `x86_64` target for iOS simulator
  
  By default, iOS 13.0 is used, but respects the `IPHONEOS_DEPLOYMENT_TARGET`
  environment variable if set. (x86_64-apple-ios-simulator) */
    X86_UNDERSCORE_64_HYPHEN_APPLE_HYPHEN_IOS_HYPHEN_SIMULATOR = "x86_64-apple-ios-simulator"
}
