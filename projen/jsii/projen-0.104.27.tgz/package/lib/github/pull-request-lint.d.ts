import type { GitHub } from ".";
import type { Job } from "./workflows-model";
import { Component } from "../component";
import type { RunsOnOptions } from "../runner-options";
/**
 * The pull request event that triggers the pull request lint workflow.
 */
export declare enum PullRequestLintTrigger {
    /**
     * Run in the context of the base branch, with access to secrets and a read/write token.
     */
    PULL_REQUEST_TARGET = "pull_request_target",
    /**
     * Run in the context of the merge commit, with a read-only token for pull requests from forks.
     */
    PULL_REQUEST = "pull_request"
}
/**
 * Options for PullRequestLint
 */
export interface PullRequestLintOptions extends RunsOnOptions {
    /**
     * The pull request event that triggers the workflow.
     *
     * @default PullRequestLintTrigger.PULL_REQUEST_TARGET
     */
    readonly trigger?: PullRequestLintTrigger;
    /**
     * Add a job that combines the results of all checks into a single status check.
     *
     * Use this job as the required status check, so it does not need updating when checks are added or removed.
     *
     * @default true
     */
    readonly consolidatedStatusCheck?: boolean;
    /**
     * Validate that pull request titles follow Conventional Commits.
     *
     * @default true
     * @see https://www.conventionalcommits.org/
     */
    readonly semanticTitle?: boolean;
    /**
     * Options for validating the conventional commit title linter.
     * @default - title must start with "feat", "fix", or "chore"
     */
    readonly semanticTitleOptions?: SemanticTitleOptions;
    /**
     * Require a contributor statement to be included in the PR description.
     * For example confirming that the contribution has been made by the contributor and complies with the project's license.
     *
     * Appends the statement to the end of the Pull Request template.
     *
     * @default - no contributor statement is required
     */
    readonly contributorStatement?: string;
    /**
     * Options for requiring a contributor statement on Pull Requests
     * @default - none
     */
    readonly contributorStatementOptions?: ContributorStatementOptions;
}
/**
 * Options for linting that PR titles follow Conventional Commits.
 * @see https://www.conventionalcommits.org/
 */
export interface SemanticTitleOptions {
    /**
     * Configure a list of commit types that are allowed.
     * @default ["feat", "fix", "chore"]
     */
    readonly types?: string[];
    /**
     * Configure that a scope must always be provided.
     * e.g. feat(ui), fix(core)
     * @default false
     */
    readonly requireScope?: boolean;
    /**
     * Configure which scopes are allowed (newline-delimited).
     * These are regex patterns auto-wrapped in `^ $`.
     *
     * @default - all scopes allowed
     */
    readonly scopes?: string[];
}
/**
 * Options for requiring a contributor statement on Pull Requests
 */
export interface ContributorStatementOptions {
    /**
     * Pull requests from these GitHub users are exempted from a contributor statement.
     * @default - no users are exempted
     */
    readonly exemptUsers?: string[];
    /**
     * Pull requests with one of these labels are exempted from a contributor statement.
     * @default - no labels are excluded
     */
    readonly exemptLabels?: string[];
}
/**
 * Configure validations to run on GitHub pull requests.
 * Only generates a file if at least one check is configured.
 */
export declare class PullRequestLint extends Component {
    private readonly github;
    private readonly options;
    private workflow?;
    private readonly checkIds;
    constructor(github: GitHub, options?: PullRequestLintOptions);
    /**
     * Adds a job to the pull request lint workflow that is part of the consolidated status check.
     *
     * The job also runs for merge groups. Skip it there with a job condition, a skipped job counts as passing.
     *
     * @param id The job ID, unique within the workflow
     * @param job The job definition
     */
    addCheck(id: string, job: Job): void;
    preSynthesize(): void;
    private ensureWorkflow;
    private renderConsolidatedJob;
}
