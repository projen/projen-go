/**
 * @schema NodeConfigSchema
 */
export interface NodeConfigSchema {
    /**
     * @schema NodeConfigSchema#$schema
     */
    readonly schema?: string;
    /**
     * @schema NodeConfigSchema#bench
     */
    readonly bench?: NodeConfigSchemaBench;
    /**
     * @schema NodeConfigSchema#nodeOptions
     */
    readonly nodeOptions?: NodeConfigSchemaNodeOptions;
    /**
     * @schema NodeConfigSchema#nodeVersion
     */
    readonly nodeVersion?: number;
    /**
     * @schema NodeConfigSchema#permission
     */
    readonly permission?: NodeConfigSchemaPermission;
    /**
     * @schema NodeConfigSchema#test
     */
    readonly test?: NodeConfigSchemaTest;
    /**
     * @schema NodeConfigSchema#watch
     */
    readonly watch?: NodeConfigSchemaWatch;
}
/**
 * Converts an object of type 'NodeConfigSchema' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchema(obj: NodeConfigSchema | undefined): Record<string, any> | undefined;
/**
 * @schema NodeConfigSchemaBench
 */
export interface NodeConfigSchemaBench {
    /**
     * launch benchmark runner on startup
     *
     * @schema NodeConfigSchemaBench#bench
     */
    readonly bench?: boolean;
    /**
     * configures the type of benchmark isolation used in the benchmark runner
     *
     * @schema NodeConfigSchemaBench#bench-isolation
     */
    readonly benchIsolation?: string;
    /**
     * run benchmarks whose name matches this regular expression
     *
     * @schema NodeConfigSchemaBench#bench-name-pattern
     */
    readonly benchNamePattern?: string;
    /**
     * report benchmark output using the given reporter
     *
     * @schema NodeConfigSchemaBench#bench-reporter
     */
    readonly benchReporter?: string[];
    /**
     * report the given benchmark reporter to the given destination
     *
     * @schema NodeConfigSchemaBench#bench-reporter-destination
     */
    readonly benchReporterDestination?: string[];
    /**
     * specify the number of measured benchmark samples
     *
     * @schema NodeConfigSchemaBench#bench-samples
     */
    readonly benchSamples?: number;
    /**
     * specify the number of unreported benchmark warmup samples
     *
     * @schema NodeConfigSchemaBench#bench-warmup
     */
    readonly benchWarmup?: number;
}
/**
 * Converts an object of type 'NodeConfigSchemaBench' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchemaBench(obj: NodeConfigSchemaBench | undefined): Record<string, any> | undefined;
/**
 * @schema NodeConfigSchemaNodeOptions
 */
export interface NodeConfigSchemaNodeOptions {
    /**
     * disable loading native addons
     *
     * @schema NodeConfigSchemaNodeOptions#addons
     */
    readonly addons?: boolean;
    /**
     * allow use of addons when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-addons
     */
    readonly allowAddons?: boolean;
    /**
     * allow use of child process when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-child-process
     */
    readonly allowChildProcess?: boolean;
    /**
     * allow use of FFI when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-ffi
     */
    readonly allowFfi?: boolean;
    /**
     * allow permissions to read the filesystem
     *
     * @schema NodeConfigSchemaNodeOptions#allow-fs-read
     */
    readonly allowFsRead?: string[];
    /**
     * allow permissions to write in the filesystem
     *
     * @schema NodeConfigSchemaNodeOptions#allow-fs-write
     */
    readonly allowFsWrite?: string[];
    /**
     * allow use of inspector when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-inspector
     */
    readonly allowInspector?: boolean;
    /**
     * allow use of network when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-net
     */
    readonly allowNet?: boolean;
    /**
     * allow use of OpenSSL STORE loaders when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-openssl-store
     */
    readonly allowOpensslStore?: boolean;
    /**
     * allow wasi when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-wasi
     */
    readonly allowWasi?: boolean;
    /**
     * allow worker threads when any permissions are set
     *
     * @schema NodeConfigSchemaNodeOptions#allow-worker
     */
    readonly allowWorker?: boolean;
    /**
     * Improve AsyncLocalStorage performance with AsyncContextFrame
     *
     * @schema NodeConfigSchemaNodeOptions#async-context-frame
     */
    readonly asyncContextFrame?: boolean;
    /**
     * configures the type of benchmark isolation used in the benchmark runner
     *
     * @schema NodeConfigSchemaNodeOptions#bench-isolation
     */
    readonly benchIsolation?: string;
    /**
     * run benchmarks whose name matches this regular expression
     *
     * @schema NodeConfigSchemaNodeOptions#bench-name-pattern
     */
    readonly benchNamePattern?: string;
    /**
     * report benchmark output using the given reporter
     *
     * @schema NodeConfigSchemaNodeOptions#bench-reporter
     */
    readonly benchReporter?: string[];
    /**
     * report the given benchmark reporter to the given destination
     *
     * @schema NodeConfigSchemaNodeOptions#bench-reporter-destination
     */
    readonly benchReporterDestination?: string[];
    /**
     * specify the number of measured benchmark samples
     *
     * @schema NodeConfigSchemaNodeOptions#bench-samples
     */
    readonly benchSamples?: number;
    /**
     * specify the number of unreported benchmark warmup samples
     *
     * @schema NodeConfigSchemaNodeOptions#bench-warmup
     */
    readonly benchWarmup?: number;
    /**
     * additional user conditions for conditional exports and imports
     *
     * @schema NodeConfigSchemaNodeOptions#conditions
     */
    readonly conditions?: string[];
    /**
     * Start the V8 CPU profiler on start up, and write the CPU profile to disk before exit. If --cpu-prof-dir is not specified, write the profile to the current working directory.
     *
     * @schema NodeConfigSchemaNodeOptions#cpu-prof
     */
    readonly cpuProf?: boolean;
    /**
     * Directory where the V8 profiles generated by --cpu-prof will be placed. Does not affect --prof.
     *
     * @schema NodeConfigSchemaNodeOptions#cpu-prof-dir
     */
    readonly cpuProfDir?: string;
    /**
     * specified sampling interval in microseconds for the V8 CPU profile generated with --cpu-prof. (default: 1000)
     *
     * @schema NodeConfigSchemaNodeOptions#cpu-prof-interval
     */
    readonly cpuProfInterval?: number;
    /**
     * specified file name of the V8 CPU profile generated with --cpu-prof
     *
     * @schema NodeConfigSchemaNodeOptions#cpu-prof-name
     */
    readonly cpuProfName?: string;
    /**
     * @schema NodeConfigSchemaNodeOptions#debug-arraybuffer-allocations
     */
    readonly debugArraybufferAllocations?: boolean;
    /**
     * silence deprecation warnings
     *
     * @schema NodeConfigSchemaNodeOptions#deprecation
     */
    readonly deprecation?: boolean;
    /**
     * set dir for all output files (default: current working directory)
     *
     * @schema NodeConfigSchemaNodeOptions#diagnostic-dir
     */
    readonly diagnosticDir?: string;
    /**
     * disable Object.prototype.__proto__
     *
     * @schema NodeConfigSchemaNodeOptions#disable-proto
     */
    readonly disableProto?: string;
    /**
     * Disable inspector thread to be listening for SIGUSR1 signal
     *
     * @schema NodeConfigSchemaNodeOptions#disable-sigusr1
     */
    readonly disableSigusr1?: boolean;
    /**
     * silence specific process warnings
     *
     * @schema NodeConfigSchemaNodeOptions#disable-warning
     */
    readonly disableWarning?: string[];
    /**
     * Disable trap-handler-based WebAssembly bound checks. V8 will insert inline bound checks when compiling WebAssembly which may slow down performance.
     *
     * @schema NodeConfigSchemaNodeOptions#disable-wasm-trap-handler
     */
    readonly disableWasmTrapHandler?: boolean;
    /**
     * set default value of verbatim in dns.lookup. Options are 'ipv4first' (IPv4 addresses are placed before IPv6 addresses) 'ipv6first' (IPv6 addresses are placed before IPv4 addresses) 'verbatim' (addresses are in the order the DNS resolver returned)
     *
     * @schema NodeConfigSchemaNodeOptions#dns-result-order
     */
    readonly dnsResultOrder?: string;
    /**
     * enable FIPS crypto at startup
     *
     * @schema NodeConfigSchemaNodeOptions#enable-fips
     */
    readonly enableFips?: boolean;
    /**
     * Source Map V3 support for stack traces
     *
     * @schema NodeConfigSchemaNodeOptions#enable-source-maps
     */
    readonly enableSourceMaps?: boolean;
    /**
     * Treat the entrypoint as a URL
     *
     * @schema NodeConfigSchemaNodeOptions#entry-url
     */
    readonly entryUrl?: boolean;
    /**
     * experimental import support for addons
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-addon-modules
     */
    readonly experimentalAddonModules?: boolean;
    /**
     * experimental node:bench module and benchmark runner
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-bench
     */
    readonly experimentalBench?: boolean;
    /**
     * when ambiguous modules fail to evaluate because they contain ES module syntax, try again to evaluate them as ES modules
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-detect-module
     */
    readonly experimentalDetectModule?: boolean;
    /**
     * experimental EventSource API
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-eventsource
     */
    readonly experimentalEventsource?: boolean;
    /**
     * experimental node:ffi module
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-ffi
     */
    readonly experimentalFfi?: boolean;
    /**
     * expose experimental Navigator API on the global scope
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-global-navigator
     */
    readonly experimentalGlobalNavigator?: boolean;
    /**
     * experimental ES Module import.meta.resolve() parentURL support
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-import-meta-resolve
     */
    readonly experimentalImportMetaResolve?: boolean;
    /**
     * use the specified module as a custom loader
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-loader
     */
    readonly experimentalLoader?: string[];
    /**
     * Print pending top-level await. If --require-module is true, evaluate asynchronous graphs loaded by `require()` but do not run the microtasks, in order to find and print top-level await in the graph
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-print-required-tla
     */
    readonly experimentalPrintRequiredTla?: boolean;
    /**
     * experimental await keyword support in REPL
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-repl-await
     */
    readonly experimentalReplAwait?: boolean;
    /**
     * Legacy alias for --require-module
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-require-module
     */
    readonly experimentalRequireModule?: boolean;
    /**
     * @schema NodeConfigSchemaNodeOptions#experimental-shadow-realm
     */
    readonly experimentalShadowRealm?: boolean;
    /**
     * experimental node:sqlite module
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-sqlite
     */
    readonly experimentalSqlite?: boolean;
    /**
     * experimental iterable streams API (node:stream/iter)
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-stream-iter
     */
    readonly experimentalStreamIter?: boolean;
    /**
     * experimental ES Module support in vm module
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-vm-modules
     */
    readonly experimentalVmModules?: boolean;
    /**
     * experimental WebSocket API
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-websocket
     */
    readonly experimentalWebsocket?: boolean;
    /**
     * experimental Web Storage API
     *
     * @schema NodeConfigSchemaNodeOptions#experimental-webstorage
     */
    readonly experimentalWebstorage?: boolean;
    /**
     * hide extra information on fatal exception that causes exit
     *
     * @schema NodeConfigSchemaNodeOptions#extra-info-on-fatal-exception
     */
    readonly extraInfoOnFatalException?: boolean;
    /**
     * disable checks for async_hooks
     *
     * @schema NodeConfigSchemaNodeOptions#force-async-hooks-checks
     */
    readonly forceAsyncHooksChecks?: boolean;
    /**
     * disable loading non-context-aware addons
     *
     * @schema NodeConfigSchemaNodeOptions#force-context-aware
     */
    readonly forceContextAware?: boolean;
    /**
     * force FIPS crypto (cannot be disabled)
     *
     * @schema NodeConfigSchemaNodeOptions#force-fips
     */
    readonly forceFips?: boolean;
    /**
     * enforces 'uncaughtException' event on Node API asynchronous callbacks
     *
     * @schema NodeConfigSchemaNodeOptions#force-node-api-uncaught-exceptions-policy
     */
    readonly forceNodeApiUncaughtExceptionsPolicy?: boolean;
    /**
     * experimental frozen intrinsics support
     *
     * @schema NodeConfigSchemaNodeOptions#frozen-intrinsics
     */
    readonly frozenIntrinsics?: boolean;
    /**
     * disable global module search paths
     *
     * @schema NodeConfigSchemaNodeOptions#global-search-paths
     */
    readonly globalSearchPaths?: boolean;
    /**
     * Start the V8 heap profiler on start up, and write the heap profile to disk before exit. If --heap-prof-dir is not specified, write the profile to the current working directory.
     *
     * @schema NodeConfigSchemaNodeOptions#heap-prof
     */
    readonly heapProf?: boolean;
    /**
     * Directory where the V8 heap profiles generated by --heap-prof will be placed.
     *
     * @schema NodeConfigSchemaNodeOptions#heap-prof-dir
     */
    readonly heapProfDir?: string;
    /**
     * specified sampling interval in bytes for the V8 heap profile generated with --heap-prof. (default: 512 * 1024)
     *
     * @schema NodeConfigSchemaNodeOptions#heap-prof-interval
     */
    readonly heapProfInterval?: number;
    /**
     * specified file name of the V8 heap profile generated with --heap-prof
     *
     * @schema NodeConfigSchemaNodeOptions#heap-prof-name
     */
    readonly heapProfName?: string;
    /**
     * Generate heap snapshots whenever V8 is approaching the heap limit. No more than the specified number of heap snapshots will be generated.
     *
     * @schema NodeConfigSchemaNodeOptions#heapsnapshot-near-heap-limit
     */
    readonly heapsnapshotNearHeapLimit?: number;
    /**
     * Generate heap snapshot on specified signal
     *
     * @schema NodeConfigSchemaNodeOptions#heapsnapshot-signal
     */
    readonly heapsnapshotSignal?: string;
    /**
     * set ICU data load path to dir (overrides NODE_ICU_DATA) (note: linked-in ICU data is present)
     *
     * @schema NodeConfigSchemaNodeOptions#icu-data-dir
     */
    readonly icuDataDir?: string;
    /**
     * ES module to preload (option can be repeated)
     *
     * @schema NodeConfigSchemaNodeOptions#import
     */
    readonly import?: string[];
    /**
     * set module type for string input
     *
     * @schema NodeConfigSchemaNodeOptions#input-type
     */
    readonly inputType?: string;
    /**
     * use an insecure HTTP parser that accepts invalid HTTP headers
     *
     * @schema NodeConfigSchemaNodeOptions#insecure-http-parser
     */
    readonly insecureHttpParser?: boolean;
    /**
     * activate inspector on host:port (default: 127.0.0.1:9229)
     *
     * @schema NodeConfigSchemaNodeOptions#inspect
     */
    readonly inspect?: boolean;
    /**
     * activate inspector on host:port and break at start of user script
     *
     * @schema NodeConfigSchemaNodeOptions#inspect-brk
     */
    readonly inspectBrk?: boolean;
    /**
     * set host:port for inspector
     *
     * @schema NodeConfigSchemaNodeOptions#inspect-port
     */
    readonly inspectPort?: number;
    /**
     * comma separated list of destinations for inspector uid(default: stderr,http)
     *
     * @schema NodeConfigSchemaNodeOptions#inspect-publish-uid
     */
    readonly inspectPublishUid?: string;
    /**
     * activate inspector on host:port and wait for debugger to be attached
     *
     * @schema NodeConfigSchemaNodeOptions#inspect-wait
     */
    readonly inspectWait?: boolean;
    /**
     * file used to persist localStorage data
     *
     * @schema NodeConfigSchemaNodeOptions#localstorage-file
     */
    readonly localstorageFile?: string;
    /**
     * set the maximum size of HTTP headers (default: 16384 (16KB))
     *
     * @schema NodeConfigSchemaNodeOptions#max-http-header-size
     */
    readonly maxHttpHeaderSize?: number;
    /**
     * set V8's max old space size as a percentage of available memory (e.g., '50%'). Takes precedence over --max-old-space-size.
     *
     * @schema NodeConfigSchemaNodeOptions#max-old-space-size-percentage
     */
    readonly maxOldSpaceSizePercentage?: string;
    /**
     * Disable network address family autodetection algorithm
     *
     * @schema NodeConfigSchemaNodeOptions#network-family-autoselection
     */
    readonly networkFamilyAutoselection?: boolean;
    /**
     * Sets the default value for the network family autoselection attempt timeout.
     *
     * @schema NodeConfigSchemaNodeOptions#network-family-autoselection-attempt-timeout
     */
    readonly networkFamilyAutoselectionAttemptTimeout?: number;
    /**
     * @schema NodeConfigSchemaNodeOptions#node-snapshot
     */
    readonly nodeSnapshot?: boolean;
    /**
     * load OpenSSL configuration from the specified file (overrides OPENSSL_CONF)
     *
     * @schema NodeConfigSchemaNodeOptions#openssl-config
     */
    readonly opensslConfig?: string;
    /**
     * enable OpenSSL 3.0 legacy provider
     *
     * @schema NodeConfigSchemaNodeOptions#openssl-legacy-provider
     */
    readonly opensslLegacyProvider?: boolean;
    /**
     * enable OpenSSL shared configuration
     *
     * @schema NodeConfigSchemaNodeOptions#openssl-shared-config
     */
    readonly opensslSharedConfig?: boolean;
    /**
     * emit pending deprecation warnings
     *
     * @schema NodeConfigSchemaNodeOptions#pending-deprecation
     */
    readonly pendingDeprecation?: boolean;
    /**
     * enable the permission system
     *
     * @schema NodeConfigSchemaNodeOptions#permission
     */
    readonly permission?: boolean;
    /**
     * enable audit only for the permission system
     *
     * @schema NodeConfigSchemaNodeOptions#permission-audit
     */
    readonly permissionAudit?: boolean;
    /**
     * preserve symbolic links when resolving
     *
     * @schema NodeConfigSchemaNodeOptions#preserve-symlinks
     */
    readonly preserveSymlinks?: boolean;
    /**
     * preserve symbolic links when resolving the main module
     *
     * @schema NodeConfigSchemaNodeOptions#preserve-symlinks-main
     */
    readonly preserveSymlinksMain?: boolean;
    /**
     * write warnings to file instead of stderr
     *
     * @schema NodeConfigSchemaNodeOptions#redirect-warnings
     */
    readonly redirectWarnings?: string;
    /**
     * output compact single-line JSON
     *
     * @schema NodeConfigSchemaNodeOptions#report-compact
     */
    readonly reportCompact?: boolean;
    /**
     * define custom report pathname. (default: current working directory)
     *
     * @schema NodeConfigSchemaNodeOptions#report-dir
     */
    readonly reportDir?: string;
    /**
     * Exclude environment variables when generating report (default: false)
     *
     * @schema NodeConfigSchemaNodeOptions#report-exclude-env
     */
    readonly reportExcludeEnv?: boolean;
    /**
     * exclude network interface diagnostics. (default: false)
     *
     * @schema NodeConfigSchemaNodeOptions#report-exclude-network
     */
    readonly reportExcludeNetwork?: boolean;
    /**
     * define custom report file name. (default: YYYYMMDD.HHMMSS.PID.SEQUENCE#.txt)
     *
     * @schema NodeConfigSchemaNodeOptions#report-filename
     */
    readonly reportFilename?: string;
    /**
     * generate diagnostic report on fatal (internal) errors
     *
     * @schema NodeConfigSchemaNodeOptions#report-on-fatalerror
     */
    readonly reportOnFatalerror?: boolean;
    /**
     * generate diagnostic report upon receiving signals
     *
     * @schema NodeConfigSchemaNodeOptions#report-on-signal
     */
    readonly reportOnSignal?: boolean;
    /**
     * causes diagnostic report to be produced on provided signal, unsupported in Windows. (default: SIGUSR2)
     *
     * @schema NodeConfigSchemaNodeOptions#report-signal
     */
    readonly reportSignal?: string;
    /**
     * generate diagnostic report on uncaught exceptions
     *
     * @schema NodeConfigSchemaNodeOptions#report-uncaught-exception
     */
    readonly reportUncaughtException?: boolean;
    /**
     * CommonJS module to preload (option can be repeated)
     *
     * @schema NodeConfigSchemaNodeOptions#require
     */
    readonly require?: string[];
    /**
     * Allow loading synchronous ES Modules in require().
     *
     * @schema NodeConfigSchemaNodeOptions#require-module
     */
    readonly requireModule?: boolean;
    /**
     * total size of the OpenSSL secure heap
     *
     * @schema NodeConfigSchemaNodeOptions#secure-heap
     */
    readonly secureHeap?: number;
    /**
     * minimum allocation size from the OpenSSL secure heap
     *
     * @schema NodeConfigSchemaNodeOptions#secure-heap-min
     */
    readonly secureHeapMin?: number;
    /**
     * Path to the snapshot blob that's either the result of snapshotbuilding, or the blob that is used to restore the application state
     *
     * @schema NodeConfigSchemaNodeOptions#snapshot-blob
     */
    readonly snapshotBlob?: string;
    /**
     * @schema NodeConfigSchemaNodeOptions#stack-trace-limit
     */
    readonly stackTraceLimit?: number;
    /**
     * Type-stripping for TypeScript files.
     *
     * @schema NodeConfigSchemaNodeOptions#strip-types
     */
    readonly stripTypes?: boolean;
    /**
     * the branch coverage minimum threshold
     *
     * @schema NodeConfigSchemaNodeOptions#test-coverage-branches
     */
    readonly testCoverageBranches?: number;
    /**
     * exclude files from coverage report that match this glob pattern
     *
     * @schema NodeConfigSchemaNodeOptions#test-coverage-exclude
     */
    readonly testCoverageExclude?: string[];
    /**
     * the function coverage minimum threshold
     *
     * @schema NodeConfigSchemaNodeOptions#test-coverage-functions
     */
    readonly testCoverageFunctions?: number;
    /**
     * include files in coverage report that match this glob pattern
     *
     * @schema NodeConfigSchemaNodeOptions#test-coverage-include
     */
    readonly testCoverageInclude?: string[];
    /**
     * the line coverage minimum threshold
     *
     * @schema NodeConfigSchemaNodeOptions#test-coverage-lines
     */
    readonly testCoverageLines?: number;
    /**
     * specifies the path to the global setup file
     *
     * @schema NodeConfigSchemaNodeOptions#test-global-setup
     */
    readonly testGlobalSetup?: string;
    /**
     * configures the type of test isolation used in the test runner
     *
     * @schema NodeConfigSchemaNodeOptions#test-isolation
     */
    readonly testIsolation?: string;
    /**
     * run tests whose name matches this regular expression
     *
     * @schema NodeConfigSchemaNodeOptions#test-name-pattern
     */
    readonly testNamePattern?: string[];
    /**
     * run tests with 'only' option set
     *
     * @schema NodeConfigSchemaNodeOptions#test-only
     */
    readonly testOnly?: boolean;
    /**
     * seed used to randomize test execution order
     *
     * @schema NodeConfigSchemaNodeOptions#test-random-seed
     */
    readonly testRandomSeed?: number;
    /**
     * run tests in a random order
     *
     * @schema NodeConfigSchemaNodeOptions#test-randomize
     */
    readonly testRandomize?: boolean;
    /**
     * report test output using the given reporter
     *
     * @schema NodeConfigSchemaNodeOptions#test-reporter
     */
    readonly testReporter?: string[];
    /**
     * report given reporter to the given destination
     *
     * @schema NodeConfigSchemaNodeOptions#test-reporter-destination
     */
    readonly testReporterDestination?: string[];
    /**
     * specifies the path to the rerun state file
     *
     * @schema NodeConfigSchemaNodeOptions#test-rerun-failures
     */
    readonly testRerunFailures?: string;
    /**
     * run test at specific shard
     *
     * @schema NodeConfigSchemaNodeOptions#test-shard
     */
    readonly testShard?: string;
    /**
     * run tests whose name do not match this regular expression
     *
     * @schema NodeConfigSchemaNodeOptions#test-skip-pattern
     */
    readonly testSkipPattern?: string[];
    /**
     * throw an exception on deprecations
     *
     * @schema NodeConfigSchemaNodeOptions#throw-deprecation
     */
    readonly throwDeprecation?: boolean;
    /**
     * the process title to use on startup
     *
     * @schema NodeConfigSchemaNodeOptions#title
     */
    readonly title?: string;
    /**
     * use an alternative default TLS cipher list
     *
     * @schema NodeConfigSchemaNodeOptions#tls-cipher-list
     */
    readonly tlsCipherList?: string;
    /**
     * log TLS decryption keys to named file for traffic analysis
     *
     * @schema NodeConfigSchemaNodeOptions#tls-keylog
     */
    readonly tlsKeylog?: string;
    /**
     * set default TLS maximum to TLSv1.2 (default: TLSv1.3)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-max-v1.2
     */
    readonly tlsMaxV12?: boolean;
    /**
     * set default TLS maximum to TLSv1.3 (default: TLSv1.3)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-max-v1.3
     */
    readonly tlsMaxV13?: boolean;
    /**
     * set default TLS minimum to TLSv1.0 (default: TLSv1.2)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-min-v1.0
     */
    readonly tlsMinV10?: boolean;
    /**
     * set default TLS minimum to TLSv1.1 (default: TLSv1.2)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-min-v1.1
     */
    readonly tlsMinV11?: boolean;
    /**
     * set default TLS minimum to TLSv1.2 (default: TLSv1.2)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-min-v1.2
     */
    readonly tlsMinV12?: boolean;
    /**
     * set default TLS minimum to TLSv1.3 (default: TLSv1.2)
     *
     * @schema NodeConfigSchemaNodeOptions#tls-min-v1.3
     */
    readonly tlsMinV13?: boolean;
    /**
     * show stack traces on deprecations
     *
     * @schema NodeConfigSchemaNodeOptions#trace-deprecation
     */
    readonly traceDeprecation?: boolean;
    /**
     * Print accesses to the environment variables
     *
     * @schema NodeConfigSchemaNodeOptions#trace-env
     */
    readonly traceEnv?: boolean;
    /**
     * Print accesses to the environment variables and the JavaScript stack trace
     *
     * @schema NodeConfigSchemaNodeOptions#trace-env-js-stack
     */
    readonly traceEnvJsStack?: boolean;
    /**
     * Print accesses to the environment variables and the native stack trace
     *
     * @schema NodeConfigSchemaNodeOptions#trace-env-native-stack
     */
    readonly traceEnvNativeStack?: boolean;
    /**
     * comma separated list of trace event categories to record
     *
     * @schema NodeConfigSchemaNodeOptions#trace-event-categories
     */
    readonly traceEventCategories?: string;
    /**
     * Template string specifying the filepath for the trace-events data, it supports ${rotation} and ${pid}.
     *
     * @schema NodeConfigSchemaNodeOptions#trace-event-file-pattern
     */
    readonly traceEventFilePattern?: string;
    /**
     * show stack trace when an environment exits
     *
     * @schema NodeConfigSchemaNodeOptions#trace-exit
     */
    readonly traceExit?: boolean;
    /**
     * show stack traces on promise initialization and resolution
     *
     * @schema NodeConfigSchemaNodeOptions#trace-promises
     */
    readonly tracePromises?: boolean;
    /**
     * Print access to require(esm). Options are 'all' (print all usage) and 'no-node-modules' (excluding usage from the node_modules folder)
     *
     * @schema NodeConfigSchemaNodeOptions#trace-require-module
     */
    readonly traceRequireModule?: string;
    /**
     * enable printing JavaScript stacktrace on SIGINT
     *
     * @schema NodeConfigSchemaNodeOptions#trace-sigint
     */
    readonly traceSigint?: boolean;
    /**
     * show stack trace when use of sync IO is detected after the first tick
     *
     * @schema NodeConfigSchemaNodeOptions#trace-sync-io
     */
    readonly traceSyncIo?: boolean;
    /**
     * prints TLS packet trace information to stderr
     *
     * @schema NodeConfigSchemaNodeOptions#trace-tls
     */
    readonly traceTls?: boolean;
    /**
     * show stack traces for the `throw` behind uncaught exceptions
     *
     * @schema NodeConfigSchemaNodeOptions#trace-uncaught
     */
    readonly traceUncaught?: boolean;
    /**
     * show stack traces on process warnings
     *
     * @schema NodeConfigSchemaNodeOptions#trace-warnings
     */
    readonly traceWarnings?: boolean;
    /**
     * track heap object allocations for heap snapshots
     *
     * @schema NodeConfigSchemaNodeOptions#track-heap-objects
     */
    readonly trackHeapObjects?: boolean;
    /**
     * define unhandled rejections behavior. Options are 'strict' (always raise an error), 'throw' (raise an error unless 'unhandledRejection' hook is set), 'warn' (log a warning), 'none' (silence warnings), 'warn-with-error-code' (log a warning and set exit code 1 unless 'unhandledRejection' hook is set). (default: throw)
     *
     * @schema NodeConfigSchemaNodeOptions#unhandled-rejections
     */
    readonly unhandledRejections?: string;
    /**
     * use bundled CA store (default)
     *
     * @schema NodeConfigSchemaNodeOptions#use-bundled-ca
     */
    readonly useBundledCa?: boolean;
    /**
     * parse proxy settings from HTTP_PROXY/HTTPS_PROXY/NO_PROXYenvironment variables and apply the setting in global HTTP/HTTPS clients
     *
     * @schema NodeConfigSchemaNodeOptions#use-env-proxy
     */
    readonly useEnvProxy?: boolean;
    /**
     * This option is no longer supported and a no-op. Options are 'off' (default), 'on' (report a warning to stderr), or 'silent' (same as 'off').
     *
     * @schema NodeConfigSchemaNodeOptions#use-largepages
     */
    readonly useLargepages?: string;
    /**
     * use OpenSSL's default CA store
     *
     * @schema NodeConfigSchemaNodeOptions#use-openssl-ca
     */
    readonly useOpensslCa?: boolean;
    /**
     * use system's CA store
     *
     * @schema NodeConfigSchemaNodeOptions#use-system-ca
     */
    readonly useSystemCa?: boolean;
    /**
     * set V8's thread pool size
     *
     * @schema NodeConfigSchemaNodeOptions#v8-pool-size
     */
    readonly v8PoolSize?: number;
    /**
     * @schema NodeConfigSchemaNodeOptions#verify-base-objects
     */
    readonly verifyBaseObjects?: boolean;
    /**
     * silence all process warnings
     *
     * @schema NodeConfigSchemaNodeOptions#warnings
     */
    readonly warnings?: boolean;
    /**
     * run in watch mode
     *
     * @schema NodeConfigSchemaNodeOptions#watch
     */
    readonly watch?: boolean;
    /**
     * kill signal to send to the process on watch mode restarts(default: SIGTERM)
     *
     * @schema NodeConfigSchemaNodeOptions#watch-kill-signal
     */
    readonly watchKillSignal?: string;
    /**
     * path to watch
     *
     * @schema NodeConfigSchemaNodeOptions#watch-path
     */
    readonly watchPath?: string[];
    /**
     * preserve outputs on watch mode restart
     *
     * @schema NodeConfigSchemaNodeOptions#watch-preserve-output
     */
    readonly watchPreserveOutput?: boolean;
    /**
     * automatically zero-fill all newly allocated Buffer instances
     *
     * @schema NodeConfigSchemaNodeOptions#zero-fill-buffers
     */
    readonly zeroFillBuffers?: boolean;
}
/**
 * Converts an object of type 'NodeConfigSchemaNodeOptions' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchemaNodeOptions(obj: NodeConfigSchemaNodeOptions | undefined): Record<string, any> | undefined;
/**
 * @schema NodeConfigSchemaPermission
 */
export interface NodeConfigSchemaPermission {
    /**
     * allow use of addons when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-addons
     */
    readonly allowAddons?: boolean;
    /**
     * allow use of child process when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-child-process
     */
    readonly allowChildProcess?: boolean;
    /**
     * allow use of FFI when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-ffi
     */
    readonly allowFfi?: boolean;
    /**
     * allow permissions to read the filesystem
     *
     * @schema NodeConfigSchemaPermission#allow-fs-read
     */
    readonly allowFsRead?: string[];
    /**
     * allow permissions to write in the filesystem
     *
     * @schema NodeConfigSchemaPermission#allow-fs-write
     */
    readonly allowFsWrite?: string[];
    /**
     * allow use of inspector when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-inspector
     */
    readonly allowInspector?: boolean;
    /**
     * allow use of network when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-net
     */
    readonly allowNet?: boolean;
    /**
     * allow use of OpenSSL STORE loaders when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-openssl-store
     */
    readonly allowOpensslStore?: boolean;
    /**
     * allow wasi when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-wasi
     */
    readonly allowWasi?: boolean;
    /**
     * allow worker threads when any permissions are set
     *
     * @schema NodeConfigSchemaPermission#allow-worker
     */
    readonly allowWorker?: boolean;
    /**
     * enable the permission system
     *
     * @schema NodeConfigSchemaPermission#permission
     */
    readonly permission?: boolean;
}
/**
 * Converts an object of type 'NodeConfigSchemaPermission' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchemaPermission(obj: NodeConfigSchemaPermission | undefined): Record<string, any> | undefined;
/**
 * @schema NodeConfigSchemaTest
 */
export interface NodeConfigSchemaTest {
    /**
     * enable code coverage in the test runner
     *
     * @schema NodeConfigSchemaTest#experimental-test-coverage
     */
    readonly experimentalTestCoverage?: boolean;
    /**
     * enable module mocking in the test runner
     *
     * @schema NodeConfigSchemaTest#experimental-test-module-mocks
     */
    readonly experimentalTestModuleMocks?: boolean;
    /**
     * launch test runner on startup
     *
     * @schema NodeConfigSchemaTest#test
     */
    readonly test?: boolean;
    /**
     * specify test runner concurrency
     *
     * @schema NodeConfigSchemaTest#test-concurrency
     */
    readonly testConcurrency?: number;
    /**
     * the branch coverage minimum threshold
     *
     * @schema NodeConfigSchemaTest#test-coverage-branches
     */
    readonly testCoverageBranches?: number;
    /**
     * exclude files from coverage report that match this glob pattern
     *
     * @schema NodeConfigSchemaTest#test-coverage-exclude
     */
    readonly testCoverageExclude?: string[];
    /**
     * the function coverage minimum threshold
     *
     * @schema NodeConfigSchemaTest#test-coverage-functions
     */
    readonly testCoverageFunctions?: number;
    /**
     * include files in coverage report that match this glob pattern
     *
     * @schema NodeConfigSchemaTest#test-coverage-include
     */
    readonly testCoverageInclude?: string[];
    /**
     * the line coverage minimum threshold
     *
     * @schema NodeConfigSchemaTest#test-coverage-lines
     */
    readonly testCoverageLines?: number;
    /**
     * force test runner to exit upon completion
     *
     * @schema NodeConfigSchemaTest#test-force-exit
     */
    readonly testForceExit?: boolean;
    /**
     * specifies the path to the global setup file
     *
     * @schema NodeConfigSchemaTest#test-global-setup
     */
    readonly testGlobalSetup?: string;
    /**
     * configures the type of test isolation used in the test runner
     *
     * @schema NodeConfigSchemaTest#test-isolation
     */
    readonly testIsolation?: string;
    /**
     * run tests whose name matches this regular expression
     *
     * @schema NodeConfigSchemaTest#test-name-pattern
     */
    readonly testNamePattern?: string[];
    /**
     * run tests with 'only' option set
     *
     * @schema NodeConfigSchemaTest#test-only
     */
    readonly testOnly?: boolean;
    /**
     * seed used to randomize test execution order
     *
     * @schema NodeConfigSchemaTest#test-random-seed
     */
    readonly testRandomSeed?: number;
    /**
     * run tests in a random order
     *
     * @schema NodeConfigSchemaTest#test-randomize
     */
    readonly testRandomize?: boolean;
    /**
     * report test output using the given reporter
     *
     * @schema NodeConfigSchemaTest#test-reporter
     */
    readonly testReporter?: string[];
    /**
     * report given reporter to the given destination
     *
     * @schema NodeConfigSchemaTest#test-reporter-destination
     */
    readonly testReporterDestination?: string[];
    /**
     * specifies the path to the rerun state file
     *
     * @schema NodeConfigSchemaTest#test-rerun-failures
     */
    readonly testRerunFailures?: string;
    /**
     * run test at specific shard
     *
     * @schema NodeConfigSchemaTest#test-shard
     */
    readonly testShard?: string;
    /**
     * run tests whose name do not match this regular expression
     *
     * @schema NodeConfigSchemaTest#test-skip-pattern
     */
    readonly testSkipPattern?: string[];
    /**
     * specify test runner timeout
     *
     * @schema NodeConfigSchemaTest#test-timeout
     */
    readonly testTimeout?: number;
    /**
     * regenerate test snapshots
     *
     * @schema NodeConfigSchemaTest#test-update-snapshots
     */
    readonly testUpdateSnapshots?: boolean;
}
/**
 * Converts an object of type 'NodeConfigSchemaTest' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchemaTest(obj: NodeConfigSchemaTest | undefined): Record<string, any> | undefined;
/**
 * @schema NodeConfigSchemaWatch
 */
export interface NodeConfigSchemaWatch {
    /**
     * run in watch mode
     *
     * @schema NodeConfigSchemaWatch#watch
     */
    readonly watch?: boolean;
    /**
     * kill signal to send to the process on watch mode restarts(default: SIGTERM)
     *
     * @schema NodeConfigSchemaWatch#watch-kill-signal
     */
    readonly watchKillSignal?: string;
    /**
     * path to watch
     *
     * @schema NodeConfigSchemaWatch#watch-path
     */
    readonly watchPath?: string[];
    /**
     * preserve outputs on watch mode restart
     *
     * @schema NodeConfigSchemaWatch#watch-preserve-output
     */
    readonly watchPreserveOutput?: boolean;
}
/**
 * Converts an object of type 'NodeConfigSchemaWatch' to JSON representation.
 * @internal
 */
export declare function toJson_NodeConfigSchemaWatch(obj: NodeConfigSchemaWatch | undefined): Record<string, any> | undefined;
