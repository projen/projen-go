import type { IConstruct, IMixin } from "constructs";
import type { JsiiDotNetTarget, JsiiGoTarget, JsiiJavaTarget, JsiiPythonTarget } from "./jsii-project";
import type { Step } from "../github/workflows-model";
import type { NpmPublishOptions } from "../release";
import { TypeScriptProject } from "../typescript";
/**
 * Options for `JsiiBuild`.
 */
export interface JsiiBuildOptions {
    /**
     * Publish to maven
     * @default - no publishing
     */
    readonly publishToMaven?: JsiiJavaTarget;
    /**
     * Publish to pypi
     * @default - no publishing
     */
    readonly publishToPypi?: JsiiPythonTarget;
    /**
     * Publish Go bindings to a git repository.
     * @default - no publishing
     */
    readonly publishToGo?: JsiiGoTarget;
    /**
     * Publish to NuGet
     * @default - no publishing
     */
    readonly publishToNuget?: JsiiDotNetTarget;
    /**
     * Automatically run API compatibility test against the latest version published to npm after compilation.
     *
     * - You can manually run compatibility tests using `yarn compat` if this feature is disabled.
     * - You can ignore compatibility failures by adding lines to a ".compatignore" file.
     *
     * @default false
     */
    readonly compat?: boolean;
    /**
     * Name of the ignore file for API compatibility tests.
     *
     * @default ".compatignore"
     */
    readonly compatIgnore?: string;
    /**
     * Accepts a list of glob patterns. Files matching any of those patterns will be excluded from the TypeScript compiler input.
     *
     * By default, jsii will include all *.ts files (except .d.ts files) in the TypeScript compiler input.
     * This can be problematic for example when the package's build or test procedure generates .ts files
     * that cannot be compiled with jsii's compiler settings.
     */
    readonly excludeTypescript?: string[];
    /**
     * File path for generated docs.
     * @default "API.md"
     */
    readonly docgenFilePath?: string;
    /**
     * Emit a compressed version of the assembly
     * @default false
     */
    readonly compressAssembly?: boolean;
    /**
     * Version of the jsii compiler to use.
     *
     * Set to "*" if you want to manually manage the version of jsii in your
     * project by managing updates to `package.json` on your own.
     *
     * NOTE: The jsii compiler releases since 5.0.0 are not semantically versioned
     * and should remain on the same minor, so we recommend using a `~` dependency
     * (e.g. `~5.0.0`).
     *
     * @default "~5.9.0"
     * @pjnew "~5.9.0"
     */
    readonly jsiiVersion?: string;
    /**
     * The stability of the package.
     *
     * @default "stable"
     */
    readonly stability?: string;
    /**
     * Generate a MarkDown file describing the jsii API.
     *
     * @default true
     */
    readonly docgen?: boolean;
    /**
     * Whether to publish to npm.
     *
     * @default true
     */
    readonly releaseToNpm?: boolean;
    /**
     * Whether to use trusted publishing for npm.
     *
     * @default false
     */
    readonly npmTrustedPublishing?: boolean;
    /**
     * Options for publishing npm package to AWS CodeArtifact.
     *
     * @default - undefined
     */
    readonly codeArtifactOptions?: NpmPublishOptions["codeArtifactOptions"];
    /**
     * Relative path of the package within the repository.
     *
     * This is used in monorepo setups where the package is not at the root.
     * Packaging steps will extract build artifacts into this subdirectory.
     *
     * @default "." - root of the repository
     */
    readonly workspaceDirectory?: string;
    /**
     * The node version to use in packaging workflows.
     *
     * @default "lts/*"
     */
    readonly workflowNodeVersion?: string;
    /**
     * Additional steps to run before packaging in workflows.
     *
     * @default []
     */
    readonly workflowBootstrapSteps?: Array<Step>;
}
/**
 * A mixin that adds jsii compilation, multi-language packaging, and publishing
 * capabilities to any TypeScript project.
 *
 * This implements the constructs `IMixin` interface and is applied using the
 * `.with()` method on any construct.
 *
 * @example
 * const project = new TypeScriptProject({ disableTsconfig: true, ... });
 * project.with(new JsiiBuild({
 *   jsiiVersion: '~5.9.0',
 *   publishToMaven: { ... },
 * }));
 */
export declare class JsiiBuild implements IMixin {
    private readonly options;
    private readonly extraJobOptions;
    constructor(options?: JsiiBuildOptions, extraJobOptions?: Record<string, unknown>);
    /**
     * Returns true if the construct is a TypeScriptProject.
     */
    supports(construct: IConstruct): construct is TypeScriptProject;
    /**
     * Applies jsii configuration to the target TypeScriptProject.
     */
    applyTo(project: IConstruct): void;
    /**
     * Adds a target language to the release workflow.
     */
    private addTargetToRelease;
    /**
     * Adds a target language to the build workflow.
     */
    private addTargetToBuild;
    private addPackagingTask;
    private pacmakForLanguage;
}
