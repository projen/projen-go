import { Component } from "./component";
import type { Project } from "./project";
export declare class Clobber extends Component {
    constructor(project: Project);
}
