import type { ResolveOptions } from "./file";
export declare function resolve(value: any, options?: ResolveOptions): any;
