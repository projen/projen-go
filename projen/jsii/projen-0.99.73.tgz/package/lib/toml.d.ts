import type { IConstruct } from "constructs";
import type { IResolver } from "./file";
import type { ObjectFileOptions } from "./object-file";
import { ObjectFile } from "./object-file";
/**
 * Options for `TomlFile`.
 */
export interface TomlFileOptions extends ObjectFileOptions {
}
/**
 * Represents a TOML file.
 */
export declare class TomlFile extends ObjectFile {
    constructor(scope: IConstruct, filePath: string, options: TomlFileOptions);
    protected synthesizeContent(resolver: IResolver): string | undefined;
}
