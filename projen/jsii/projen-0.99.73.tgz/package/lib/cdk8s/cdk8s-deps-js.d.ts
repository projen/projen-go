import type { Cdk8sPackageNames } from "./cdk8s-deps";
import { Cdk8sDeps } from "./cdk8s-deps";
export declare class Cdk8sDepsJs extends Cdk8sDeps {
    protected packageNames(): Cdk8sPackageNames;
}
