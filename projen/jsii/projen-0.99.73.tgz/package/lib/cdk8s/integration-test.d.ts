import type { IntegrationTestBaseOptions } from "../cdk";
import { IntegrationTestBase } from "../cdk";
import type { Project } from "../project";
/**
 * Options for IntegrationTest
 */
export interface IntegrationTestOptions extends IntegrationTestBaseOptions {
}
/**
 * CDK8S integration test.
 */
export declare class IntegrationTest extends IntegrationTestBase {
    constructor(project: Project, options: IntegrationTestOptions);
}
