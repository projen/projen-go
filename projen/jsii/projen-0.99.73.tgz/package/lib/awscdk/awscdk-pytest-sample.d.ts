import { Component } from "..";
import type { AwsCdkPythonApp } from "./awscdk-app-py";
export declare class AwsCdkPytestSample extends Component {
    constructor(project: AwsCdkPythonApp, testdir: string);
}
