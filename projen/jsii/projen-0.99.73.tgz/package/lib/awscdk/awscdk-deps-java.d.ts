import type { AwsCdkPackageNames } from "./awscdk-deps";
import { AwsCdkDeps } from "./awscdk-deps";
/**
 * Manages dependencies on the AWS CDK for Java projects.
 */
export declare class AwsCdkDepsJava extends AwsCdkDeps {
    protected packageNames(): AwsCdkPackageNames;
}
