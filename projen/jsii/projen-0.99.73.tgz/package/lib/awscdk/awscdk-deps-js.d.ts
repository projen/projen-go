import type { AwsCdkPackageNames } from "./awscdk-deps";
import { AwsCdkDeps } from "./awscdk-deps";
/**
 * Manages dependencies on the AWS CDK for Node.js projects.
 */
export declare class AwsCdkDepsJs extends AwsCdkDeps {
    protected packageNames(): AwsCdkPackageNames;
}
