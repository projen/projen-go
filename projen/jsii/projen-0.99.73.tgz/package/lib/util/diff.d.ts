/**
 * Compute a unified diff between two strings with context lines, hunk headers,
 * and optional colorized output with character-level inline highlighting.
 *
 * @param oldContent the previous content.
 * @param newContent the new content.
 * @param colorize whether to colorize the output.
 * @param contextSize number of unchanged context lines around each change.
 * @returns the diff as an array of lines, or `undefined` if there are no changes.
 */
export declare function unifiedDiff(oldContent: string, newContent: string, colorize: boolean, contextSize: number): string[] | undefined;
