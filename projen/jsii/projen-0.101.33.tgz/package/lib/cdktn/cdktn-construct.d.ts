import type { ConstructLibraryOptions } from "../cdk";
import { ConstructLibrary } from "../cdk";
export interface ConstructLibraryCdktnOptions extends ConstructLibraryOptions {
    /**
     * Minimum target version this library is tested against.
     * @default "^0.24.0"
     * @featured
     */
    readonly cdktnVersion: string;
    /**
     * Construct version to use
     * @default "^10.7.0"
     */
    readonly constructsVersion?: string;
}
/**
 * CDKTN construct library project
 *
 * A multi-language (jsii) construct library which vends constructs designed to
 * use within CDK Terrain (CDKTN), a community-driven fork of CDKTF.
 * Provides a friendly workflow and automatic publishing to the construct catalog.
 *
 * Learn more at https://cdktn.io/
 *
 * @pjid cdktn-construct
 */
export declare class ConstructLibraryCdktn extends ConstructLibrary {
    constructor(options: ConstructLibraryCdktnOptions);
}
