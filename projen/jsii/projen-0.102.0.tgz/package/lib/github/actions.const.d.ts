/**
 * Fully qualified references for all GitHub Actions used by this project.
 */
export declare class GitHubActions {
    /** actions/checkout at v7 */
    static readonly ACTIONS_CHECKOUT = "actions/checkout@v7";
    /** actions/create-github-app-token at v3.2.0 (immutable) */
    static readonly ACTIONS_CREATE_GITHUB_APP_TOKEN = "actions/create-github-app-token@v3.2.0";
    /** actions/dependency-review-action at v5.0.0 */
    static readonly ACTIONS_DEPENDENCY_REVIEW_ACTION = "actions/dependency-review-action@v5.0.0";
    /** actions/download-artifact at v8 */
    static readonly ACTIONS_DOWNLOAD_ARTIFACT = "actions/download-artifact@v8";
    /** actions/github-script at v9 */
    static readonly ACTIONS_GITHUB_SCRIPT = "actions/github-script@v9";
    /** actions/setup-dotnet at v6 */
    static readonly ACTIONS_SETUP_DOTNET = "actions/setup-dotnet@v6";
    /** actions/setup-go at v7 */
    static readonly ACTIONS_SETUP_GO = "actions/setup-go@v7";
    /** actions/setup-java at v5 */
    static readonly ACTIONS_SETUP_JAVA = "actions/setup-java@v5";
    /** actions/setup-node at v7 */
    static readonly ACTIONS_SETUP_NODE = "actions/setup-node@v7";
    /** actions/setup-python at v7 */
    static readonly ACTIONS_SETUP_PYTHON = "actions/setup-python@v7";
    /** actions/stale at v11 */
    static readonly ACTIONS_STALE = "actions/stale@v11";
    /** actions/upload-artifact at v7 */
    static readonly ACTIONS_UPLOAD_ARTIFACT = "actions/upload-artifact@v7";
    /** amannn/action-semantic-pull-request at v6 */
    static readonly AMANNN_ACTION_SEMANTIC_PULL_REQUEST = "amannn/action-semantic-pull-request@v6";
    /** aws-actions/configure-aws-credentials at v6 */
    static readonly AWS_ACTIONS_CONFIGURE_AWS_CREDENTIALS = "aws-actions/configure-aws-credentials@v6";
    /** codecov/codecov-action at v7 */
    static readonly CODECOV_CODECOV_ACTION = "codecov/codecov-action@v7";
    /** oven-sh/setup-bun at v2 */
    static readonly OVEN_SH_SETUP_BUN = "oven-sh/setup-bun@v2";
    /** peter-evans/create-pull-request at v8 */
    static readonly PETER_EVANS_CREATE_PULL_REQUEST = "peter-evans/create-pull-request@v8";
    /** pnpm/action-setup at v6 */
    static readonly PNPM_ACTION_SETUP = "pnpm/action-setup@v6";
    /** sqren/backport-github-action at v12 */
    static readonly SQREN_BACKPORT_GITHUB_ACTION = "sqren/backport-github-action@v12";
    private constructor();
}
