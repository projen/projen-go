/**
 * JSON schema for pnpm-workspace.yaml files
 *
 * @schema PnpmWorkspaceYamlSchema
 */
export interface PnpmWorkspaceYamlSchema {
    /**
     * Workspace package paths. Glob patterns are supported
     *
     * @schema PnpmWorkspaceYamlSchema#packages
     */
    readonly packages?: string[];
    /**
     * Define dependency version ranges as reusable constants,
     * for later reference in package.json files.
     * This (singular) field creates a catalog named default.
     *
     *
     * @schema PnpmWorkspaceYamlSchema#catalog
     */
    readonly catalog?: {
        [key: string]: string;
    };
    /**
     * Define arbitrarily named catalogs
     *
     * @schema PnpmWorkspaceYamlSchema#catalogs
     */
    readonly catalogs?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
     * Controlling if and how dependencies are added to the default catalog
     *
     * @schema PnpmWorkspaceYamlSchema#catalogMode
     */
    readonly catalogMode?: PnpmWorkspaceYamlSchemaCatalogMode;
    /**
     * When set to `true`, pnpm will remove unused catalog entries during installation.
     *
     * @schema PnpmWorkspaceYamlSchema#cleanupUnusedCatalogs
     */
    readonly cleanupUnusedCatalogs?: boolean;
    /**
     * A list of package names that are allowed to be executed during installation.
     *
     * @schema PnpmWorkspaceYamlSchema#onlyBuiltDependencies
     */
    readonly onlyBuiltDependencies?: string[];
    /**
     * Used to override any dependency in the dependency graph.
     *
     * @schema PnpmWorkspaceYamlSchema#overrides
     */
    readonly overrides?: any;
    /**
     * Used to extend the existing package definitions with additional information.
     *
     * @schema PnpmWorkspaceYamlSchema#packageExtensions
     */
    readonly packageExtensions?: any;
    /**
     * Per-workspace-project pnpm settings that replace project-specific .npmrc files.
     *
     * @schema PnpmWorkspaceYamlSchema#packageConfigs
     */
    readonly packageConfigs?: any;
    /**
     * @schema PnpmWorkspaceYamlSchema#peerDependencyRules
     */
    readonly peerDependencyRules?: PnpmWorkspaceYamlSchemaPeerDependencyRules;
    /**
     * A list of dependencies to run builds for.
     *
     * @schema PnpmWorkspaceYamlSchema#neverBuiltDependencies
     */
    readonly neverBuiltDependencies?: string[];
    /**
     * If set to true, all build scripts (e.g. preinstall, install, postinstall) from dependencies will run automatically, without requiring approval.
     *
     * @schema PnpmWorkspaceYamlSchema#dangerouslyAllowAllBuilds
     */
    readonly dangerouslyAllowAllBuilds?: boolean;
    /**
     * Specifies a JSON file that lists the only packages permitted to run installation scripts during the pnpm install process.
     *
     * @schema PnpmWorkspaceYamlSchema#onlyBuiltDependenciesFile
     */
    readonly onlyBuiltDependenciesFile?: string;
    /**
     * A list of package names that should not be built during installation.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoredBuiltDependencies
     */
    readonly ignoredBuiltDependencies?: string[];
    /**
     * A list of deprecated versions that the warnings are suppressed.
     *
     * @schema PnpmWorkspaceYamlSchema#allowedDeprecatedVersions
     */
    readonly allowedDeprecatedVersions?: {
        [key: string]: string;
    };
    /**
     * A list of dependencies that are patched.
     *
     * @schema PnpmWorkspaceYamlSchema#patchedDependencies
     */
    readonly patchedDependencies?: {
        [key: string]: string;
    };
    /**
     * When true, installation won't fail if some of the patches from the "patchedDependencies" field were not applied. (Previously named "allowNonAppliedPatches")
     *
     * @schema PnpmWorkspaceYamlSchema#allowUnusedPatches
     */
    readonly allowUnusedPatches?: boolean;
    /**
     * When true, installation won't fail if some of the patches from the "patchedDependencies" field were not applied.
     *
     * @schema PnpmWorkspaceYamlSchema#allowNonAppliedPatches
     */
    readonly allowNonAppliedPatches?: boolean;
    /**
     * Default is undefined. Errors out when a patch with an exact version or version range fails. Ignores failures from name-only patches. When true, prints a warning instead of failing when any patch cannot be applied. When false, errors out for any patch failure.
     *
     * @default undefined. Errors out when a patch with an exact version or version range fails. Ignores failures from name-only patches. When true, prints a warning instead of failing when any patch cannot be applied. When false, errors out for any patch failure.
     * @schema PnpmWorkspaceYamlSchema#ignorePatchFailures
     */
    readonly ignorePatchFailures?: boolean;
    /**
     * @schema PnpmWorkspaceYamlSchema#update
     */
    readonly update?: PnpmWorkspaceYamlSchemaUpdate;
    /**
     * @schema PnpmWorkspaceYamlSchema#updateConfig
     */
    readonly updateConfig?: PnpmWorkspaceYamlSchemaUpdateConfig;
    /**
     * Config dependencies allow you to share and centralize configuration files, settings, and hooks across multiple projects. They are installed before all regular dependencies ('dependencies', 'devDependencies', 'optionalDependencies'), making them ideal for setting up custom hooks, patches, and catalog entries.
     *
     * @schema PnpmWorkspaceYamlSchema#configDependencies
     */
    readonly configDependencies?: any;
    /**
     * @schema PnpmWorkspaceYamlSchema#audit
     */
    readonly audit?: PnpmWorkspaceYamlSchemaAudit;
    /**
     * @schema PnpmWorkspaceYamlSchema#auditConfig
     */
    readonly auditConfig?: PnpmWorkspaceYamlSchemaAuditConfig;
    /**
     * A list of scripts that must exist in each project.
     *
     * @schema PnpmWorkspaceYamlSchema#requiredScripts
     */
    readonly requiredScripts?: string[];
    /**
     * Specifies architectures for which you'd like to install optional dependencies, even if they don't match the architecture of the system running the install.
     *
     * @schema PnpmWorkspaceYamlSchema#supportedArchitectures
     */
    readonly supportedArchitectures?: PnpmWorkspaceYamlSchemaSupportedArchitectures;
    /**
     * A list of optional dependencies that the install should be skipped.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoredOptionalDependencies
     */
    readonly ignoredOptionalDependencies?: string[];
    /**
     * @schema PnpmWorkspaceYamlSchema#executionEnv
     */
    readonly executionEnv?: PnpmWorkspaceYamlSchemaExecutionEnv;
    /**
     * When true, all dependencies are hoisted to node_modules/.pnpm/node_modules.
     *
     * @schema PnpmWorkspaceYamlSchema#hoist
     */
    readonly hoist?: boolean;
    /**
     * When true, packages from the workspaces are symlinked to either <workspace_root>/node_modules/.pnpm/node_modules or to <workspace_root>/node_modules depending on other hoisting settings (hoistPattern and publicHoistPattern).
     *
     * @schema PnpmWorkspaceYamlSchema#hoistWorkspacePackages
     */
    readonly hoistWorkspacePackages?: boolean;
    /**
     * Tells pnpm which packages should be hoisted to node_modules/.pnpm/node_modules
     *
     * @schema PnpmWorkspaceYamlSchema#hoistPattern
     */
    readonly hoistPattern?: string[];
    /**
     * Unlike hoistPattern, which hoists dependencies to a hidden modules directory inside the virtual store, publicHoistPattern hoists dependencies matching the pattern to the root modules directory.
     *
     * @schema PnpmWorkspaceYamlSchema#publicHoistPattern
     */
    readonly publicHoistPattern?: string[];
    /**
     * By default, pnpm creates a semistrict node_modules, meaning dependencies have access to undeclared dependencies but modules outside of node_modules do not.
     *
     * @schema PnpmWorkspaceYamlSchema#shamefullyHoist
     */
    readonly shamefullyHoist?: boolean;
    /**
     * The directory in which dependencies will be installed (instead of node_modules).
     *
     * @schema PnpmWorkspaceYamlSchema#modulesDir
     */
    readonly modulesDir?: string;
    /**
     * Defines what linker should be used for installing Node packages.
     *
     * @schema PnpmWorkspaceYamlSchema#nodeLinker
     */
    readonly nodeLinker?: PnpmWorkspaceYamlSchemaNodeLinker;
    /**
     * When symlink is set to false, pnpm creates a virtual store directory without any symlinks. It is a useful setting together with nodeLinker=pnp.
     *
     * @schema PnpmWorkspaceYamlSchema#symlink
     */
    readonly symlink?: boolean;
    /**
     * When false, pnpm will not write any files to the modules directory (node_modules).
     *
     * @schema PnpmWorkspaceYamlSchema#enableModulesDir
     */
    readonly enableModulesDir?: boolean;
    /**
     * The directory with links to the store.
     *
     * @schema PnpmWorkspaceYamlSchema#virtualStoreDir
     */
    readonly virtualStoreDir?: string;
    /**
     * Sets the maximum allowed length of directory names inside the virtual store directory (node_modules/.pnpm).
     *
     * @schema PnpmWorkspaceYamlSchema#virtualStoreDirMaxLength
     */
    readonly virtualStoreDirMaxLength?: number;
    /**
     * Controls the way packages are imported from the store (if you want to disable symlinks inside node_modules, then you need to change the nodeLinker setting, not this one).
     *
     * @schema PnpmWorkspaceYamlSchema#packageImportMethod
     */
    readonly packageImportMethod?: PnpmWorkspaceYamlSchemaPackageImportMethod;
    /**
     * The time in minutes after which orphan packages from the modules directory should be removed.
     *
     * @schema PnpmWorkspaceYamlSchema#modulesCacheMaxAge
     */
    readonly modulesCacheMaxAge?: number;
    /**
     * The time in minutes after which dlx cache expires.
     *
     * @schema PnpmWorkspaceYamlSchema#dlxCacheMaxAge
     */
    readonly dlxCacheMaxAge?: number;
    /**
     * The location where all the packages are saved on the disk.
     *
     * @schema PnpmWorkspaceYamlSchema#storeDir
     */
    readonly storeDir?: string;
    /**
     * By default, if a file in the store has been modified, the content of this file is checked before linking it to a project's node_modules.
     *
     * @schema PnpmWorkspaceYamlSchema#verifyStoreIntegrity
     */
    readonly verifyStoreIntegrity?: boolean;
    /**
     * Some registries allow the exact same content to be published under different package names and/or versions.
     *
     * @schema PnpmWorkspaceYamlSchema#strictStorePkgContentCheck
     */
    readonly strictStorePkgContentCheck?: boolean;
    /**
     * When enabled, node_modules contains only symlinks to a central virtual store, rather than to node_modules/.pnpm.
     *
     * @schema PnpmWorkspaceYamlSchema#enableGlobalVirtualStore
     */
    readonly enableGlobalVirtualStore?: boolean;
    /**
     * When set to false, pnpm won't read or generate a pnpm-lock.yaml file.
     *
     * @schema PnpmWorkspaceYamlSchema#lockfile
     */
    readonly lockfile?: boolean;
    /**
     * When set to true and the available pnpm-lock.yaml satisfies the package.json dependencies directive, a headless installation is performed.
     *
     * @schema PnpmWorkspaceYamlSchema#preferFrozenLockfile
     */
    readonly preferFrozenLockfile?: boolean;
    /**
     * Add the full URL to the package's tarball to every entry in pnpm-lock.yaml.
     *
     * @schema PnpmWorkspaceYamlSchema#lockfileIncludeTarballUrl
     */
    readonly lockfileIncludeTarballUrl?: boolean;
    /**
     * When set to true, the generated lockfile name after installation will be named based on the current branch name to completely avoid merge conflicts.
     *
     * @schema PnpmWorkspaceYamlSchema#gitBranchLockfile
     */
    readonly gitBranchLockfile?: boolean;
    /**
     * This configuration matches the current branch name to determine whether to merge all git branch lockfile files.
     *
     * @schema PnpmWorkspaceYamlSchema#mergeGitBranchLockfilesBranchPattern
     */
    readonly mergeGitBranchLockfilesBranchPattern?: any[];
    /**
     * Max length of the peer IDs suffix added to dependency keys in the lockfile. If the suffix is longer, it is replaced with a hash.
     *
     * @schema PnpmWorkspaceYamlSchema#peersSuffixMaxLength
     */
    readonly peersSuffixMaxLength?: number;
    /**
     * The base URL of the npm package registry (trailing slash included).
     *
     * @schema PnpmWorkspaceYamlSchema#registry
     */
    readonly registry?: string;
    /**
     * The Certificate Authority signing certificate that is trusted for SSL connections to the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#ca
     */
    readonly ca?: string;
    /**
     * A path to a file containing one or multiple Certificate Authority signing certificates.
     *
     * @schema PnpmWorkspaceYamlSchema#cafile
     */
    readonly cafile?: string;
    /**
     * A client certificate to pass when accessing the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#cert
     */
    readonly cert?: string;
    /**
     * A client key to pass when accessing the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#key
     */
    readonly key?: string;
    /**
     * When fetching dependencies that are Git repositories, if the host is listed in this setting, pnpm will use shallow cloning to fetch only the needed commit, not all the history.
     *
     * @schema PnpmWorkspaceYamlSchema#gitShallowHosts
     */
    readonly gitShallowHosts?: string[];
    /**
     * A proxy to use for outgoing HTTPS requests. If the HTTPS_PROXY, https_proxy, HTTP_PROXY or http_proxy environment variables are set, their values will be used instead.
     *
     * @schema PnpmWorkspaceYamlSchema#httpsProxy
     */
    readonly httpsProxy?: string;
    /**
     * A proxy to use for outgoing HTTP requests. If the HTTP_PROXY or http_proxy environment variables are set, proxy settings will be honored by the underlying request library.
     *
     * @schema PnpmWorkspaceYamlSchema#httpProxy
     */
    readonly httpProxy?: string;
    /**
     * npm's legacy proxy setting, used as the fallback for both httpsProxy and httpProxy. If the HTTP_PROXY or http_proxy environment variables are set, proxy settings will be honored by the underlying request library.
     *
     * @schema PnpmWorkspaceYamlSchema#proxy
     */
    readonly proxy?: string;
    /**
     * The IP address of the local interface to use when making connections to the npm registry.
     *
     * @schema PnpmWorkspaceYamlSchema#localAddress
     */
    readonly localAddress?: string;
    /**
     * The maximum number of connections to use per origin (protocol/host/port combination).
     *
     * @schema PnpmWorkspaceYamlSchema#maxsockets
     */
    readonly maxsockets?: number;
    /**
     * A comma-separated string of domain extensions that a proxy should not be used for.
     *
     * @schema PnpmWorkspaceYamlSchema#noProxy
     */
    readonly noProxy?: string;
    /**
     * Whether or not to do SSL key validation when making requests to the registry via HTTPS.
     *
     * @schema PnpmWorkspaceYamlSchema#strictSsl
     */
    readonly strictSsl?: boolean;
    /**
     * Controls the maximum number of HTTP(S) requests to process simultaneously.
     *
     * @schema PnpmWorkspaceYamlSchema#networkConcurrency
     */
    readonly networkConcurrency?: number;
    /**
     * How many times to retry if pnpm fails to fetch from the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchRetries
     */
    readonly fetchRetries?: number;
    /**
     * The exponential factor for retry backoff.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchRetryFactor
     */
    readonly fetchRetryFactor?: number;
    /**
     * The minimum (base) timeout for retrying requests.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchRetryMintimeout
     */
    readonly fetchRetryMintimeout?: number;
    /**
     * The maximum fallback timeout to ensure the retry factor does not make requests too long.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchRetryMaxtimeout
     */
    readonly fetchRetryMaxtimeout?: number;
    /**
     * The maximum amount of time to wait for HTTP requests to complete.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchTimeout
     */
    readonly fetchTimeout?: number;
    /**
     * A warning message is displayed if a metadata request to the registry takes longer than the specified threshold (in milliseconds). Added in pnpm v10.18.0.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchWarnTimeoutMs
     */
    readonly fetchWarnTimeoutMs?: number;
    /**
     * A warning message is displayed if the download speed of a tarball from the registry falls below the specified threshold (in KiB/s). Added in pnpm v10.18.0.
     *
     * @schema PnpmWorkspaceYamlSchema#fetchMinSpeedKiBps
     */
    readonly fetchMinSpeedKiBps?: number;
    /**
     * When true, any missing non-optional peer dependencies are automatically installed.
     *
     * @schema PnpmWorkspaceYamlSchema#autoInstallPeers
     */
    readonly autoInstallPeers?: boolean;
    /**
     * When this setting is set to true, packages with peer dependencies will be deduplicated after peers resolution.
     *
     * @schema PnpmWorkspaceYamlSchema#dedupePeerDependents
     */
    readonly dedupePeerDependents?: boolean;
    /**
     * If this is enabled, commands will fail if there is a missing or invalid peer dependency in the tree.
     *
     * @schema PnpmWorkspaceYamlSchema#strictPeerDependencies
     */
    readonly strictPeerDependencies?: boolean;
    /**
     * When enabled, dependencies of the root workspace project are used to resolve peer dependencies of any projects in the workspace.
     *
     * @schema PnpmWorkspaceYamlSchema#resolvePeersFromWorkspaceRoot
     */
    readonly resolvePeersFromWorkspaceRoot?: boolean;
    /**
     * Controls colors in the output.
     *
     * @schema PnpmWorkspaceYamlSchema#color
     */
    readonly color?: PnpmWorkspaceYamlSchemaColor;
    /**
     * Any logs at or higher than the given level will be shown.
     *
     * @schema PnpmWorkspaceYamlSchema#loglevel
     */
    readonly loglevel?: PnpmWorkspaceYamlSchemaLoglevel;
    /**
     * Allows you to customize the output style of the logs.
     * https://pnpm.io/cli/install#--reportername
     *
     * @schema PnpmWorkspaceYamlSchema#reporter
     */
    readonly reporter?: PnpmWorkspaceYamlSchemaReporter;
    /**
     * Experimental option that enables beta features of the CLI.
     *
     * @schema PnpmWorkspaceYamlSchema#useBetaCli
     */
    readonly useBetaCli?: boolean;
    /**
     * If this is enabled, the primary behaviour of pnpm install becomes that of pnpm install -r, meaning the install is performed on all workspace or subdirectory packages.
     *
     * @schema PnpmWorkspaceYamlSchema#recursiveInstall
     */
    readonly recursiveInstall?: boolean;
    /**
     * If this is enabled, pnpm will not install any package that claims to not be compatible with the current Node version.
     *
     * @schema PnpmWorkspaceYamlSchema#engineStrict
     */
    readonly engineStrict?: boolean;
    /**
     * The location of the npm binary that pnpm uses for some actions, like publishing.
     *
     * @schema PnpmWorkspaceYamlSchema#npmPath
     */
    readonly npmPath?: string;
    /**
     * If this setting is disabled, pnpm will not fail if a different package manager is specified in the packageManager field of package.json. When enabled, only the package name is checked (since pnpm v9.2.0), so you can still run any version of pnpm regardless of the version specified in the packageManager field.
     *
     * @schema PnpmWorkspaceYamlSchema#packageManagerStrict
     */
    readonly packageManagerStrict?: boolean;
    /**
     * When enabled, pnpm will fail if its version doesn't exactly match the version specified in the packageManager field of package.json.
     *
     * @schema PnpmWorkspaceYamlSchema#packageManagerStrictVersion
     */
    readonly packageManagerStrictVersion?: boolean;
    /**
     * When enabled, pnpm will automatically download and run the version of pnpm specified in the packageManager field of package.json.
     *
     * @schema PnpmWorkspaceYamlSchema#managePackageManagerVersions
     */
    readonly managePackageManagerVersions?: boolean;
    /**
     * Do not execute any scripts defined in the project package.json and its dependencies.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoreScripts
     */
    readonly ignoreScripts?: boolean;
    /**
     * Do not execute any scripts of the installed packages. Scripts of the projects are executed.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoreDepScripts
     */
    readonly ignoreDepScripts?: boolean;
    /**
     * The maximum number of child processes to allocate simultaneously to build node_modules.
     *
     * @schema PnpmWorkspaceYamlSchema#childConcurrency
     */
    readonly childConcurrency?: number;
    /**
     * Use and cache the results of (pre/post)install hooks.
     *
     * @schema PnpmWorkspaceYamlSchema#sideEffectsCache
     */
    readonly sideEffectsCache?: boolean;
    /**
     * Only use the side effects cache if present, do not create it for new packages.
     *
     * @schema PnpmWorkspaceYamlSchema#sideEffectsCacheReadonly
     */
    readonly sideEffectsCacheReadonly?: boolean;
    /**
     * Set to true to enable UID/GID switching when running package scripts. If set explicitly to false, then installing as a non-root user will fail.
     *
     * @schema PnpmWorkspaceYamlSchema#unsafePerm
     */
    readonly unsafePerm?: boolean;
    /**
     * Options to pass through to Node.js via the NODE_OPTIONS environment variable.
     *
     * @schema PnpmWorkspaceYamlSchema#nodeOptions
     */
    readonly nodeOptions?: string;
    /**
     * This setting allows the checking of the state of dependencies before running scripts.
     *
     * @schema PnpmWorkspaceYamlSchema#verifyDepsBeforeRun
     */
    readonly verifyDepsBeforeRun?: any;
    /**
     * When strictDepBuilds is enabled, the installation will exit with a non-zero exit code if any dependencies have unreviewed build scripts (aka postinstall scripts).
     *
     * @schema PnpmWorkspaceYamlSchema#strictDepBuilds
     */
    readonly strictDepBuilds?: boolean;
    /**
     * Specifies which exact Node.js version should be used for the project's runtime.
     *
     * @schema PnpmWorkspaceYamlSchema#useNodeVersion
     */
    readonly useNodeVersion?: string;
    /**
     * The Node.js version to use when checking a package's engines setting.
     *
     * @schema PnpmWorkspaceYamlSchema#nodeVersion
     */
    readonly nodeVersion?: string;
    /**
     * If this is enabled, locally available packages are linked to node_modules instead of being downloaded from the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#linkWorkspacePackages
     */
    readonly linkWorkspacePackages?: PnpmWorkspaceYamlSchemaLinkWorkspacePackages;
    /**
     * Enables hard-linking of all local workspace dependencies instead of symlinking them.
     *
     * @schema PnpmWorkspaceYamlSchema#injectWorkspacePackages
     */
    readonly injectWorkspacePackages?: boolean;
    /**
     * Injected workspace dependencies are collections of hardlinks, which don't add or remove the files when their sources change.
     *
     * @schema PnpmWorkspaceYamlSchema#syncInjectedDepsAfterScripts
     */
    readonly syncInjectedDepsAfterScripts?: string[];
    /**
     * If this is enabled, local packages from the workspace are preferred over packages from the registry, even if there is a newer version of the package in the registry.
     *
     * @schema PnpmWorkspaceYamlSchema#preferWorkspacePackages
     */
    readonly preferWorkspacePackages?: boolean;
    /**
     * If this is enabled, pnpm creates a single pnpm-lock.yaml file in the root of the workspace.
     *
     * @schema PnpmWorkspaceYamlSchema#sharedWorkspaceLockfile
     */
    readonly sharedWorkspaceLockfile?: boolean;
    /**
     * This setting controls how dependencies that are linked from the workspace are added to package.json.
     *
     * @schema PnpmWorkspaceYamlSchema#saveWorkspaceProtocol
     */
    readonly saveWorkspaceProtocol?: PnpmWorkspaceYamlSchemaSaveWorkspaceProtocol;
    /**
     * When executing commands recursively in a workspace, execute them on the root workspace project as well.
     *
     * @schema PnpmWorkspaceYamlSchema#includeWorkspaceRoot
     */
    readonly includeWorkspaceRoot?: boolean;
    /**
     * When set to true, no workspace cycle warnings will be printed.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoreWorkspaceCycles
     */
    readonly ignoreWorkspaceCycles?: boolean;
    /**
     * Adding a new dependency to the root workspace package fails, unless the --ignore-workspace-root-check or -w flag is used.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoreWorkspaceRootCheck
     */
    readonly ignoreWorkspaceRootCheck?: boolean;
    /**
     * When set to true, installation will fail if the workspace has cycles.
     *
     * @schema PnpmWorkspaceYamlSchema#disallowWorkspaceCycles
     */
    readonly disallowWorkspaceCycles?: boolean;
    /**
     * Set the maximum number of tasks to run simultaneously. For unlimited concurrency use Infinity. You can set the value to <= 0 and it will use amount of CPU cores of the host minus the absolute value of the provided number as: max(1, (number of cores) - abs(workspaceConcurrency)).
     *
     * @schema PnpmWorkspaceYamlSchema#workspaceConcurrency
     */
    readonly workspaceConcurrency?: number;
    /**
     * If true, pnpm will fail if no packages match the filter
     *
     * @schema PnpmWorkspaceYamlSchema#failIfNoMatch
     */
    readonly failIfNoMatch?: boolean;
    /**
     * By default, pnpm deploy will try creating a dedicated lockfile from a shared lockfile for deployment. If this setting is set to true, the legacy deploy behavior will be used.
     *
     * @schema PnpmWorkspaceYamlSchema#forceLegacyDeploy
     */
    readonly forceLegacyDeploy?: boolean;
    /**
     * Configure how versions of packages installed to a package.json file get prefixed.
     *
     * @schema PnpmWorkspaceYamlSchema#savePrefix
     */
    readonly savePrefix?: PnpmWorkspaceYamlSchemaSavePrefix;
    /**
     * If you pnpm add a package and you don't provide a specific version, then it will install the package at the version registered under the tag from this setting.
     *
     * @schema PnpmWorkspaceYamlSchema#tag
     */
    readonly tag?: string;
    /**
     * Specify a custom directory to store global packages.
     *
     * @schema PnpmWorkspaceYamlSchema#globalDir
     */
    readonly globalDir?: string;
    /**
     * Allows to set the target directory for the bin files of globally installed packages.
     *
     * @schema PnpmWorkspaceYamlSchema#globalBinDir
     */
    readonly globalBinDir?: string;
    /**
     * The location where all the packages are saved on the disk.
     *
     * @schema PnpmWorkspaceYamlSchema#stateDir
     */
    readonly stateDir?: string;
    /**
     * The location of the cache (package metadata and dlx).
     *
     * @schema PnpmWorkspaceYamlSchema#cacheDir
     */
    readonly cacheDir?: string;
    /**
     * When true, all the output is written to stderr.
     *
     * @schema PnpmWorkspaceYamlSchema#useStderr
     */
    readonly useStderr?: boolean;
    /**
     * When true, pnpm will check for updates to the installed packages and notify the user.
     *
     * @schema PnpmWorkspaceYamlSchema#updateNotifier
     */
    readonly updateNotifier?: boolean;
    /**
     * Create symlinks to executables in node_modules/.bin instead of command shims. This setting is ignored on Windows, where only command shims work.
     *
     * @schema PnpmWorkspaceYamlSchema#preferSymlinkedExecutables
     */
    readonly preferSymlinkedExecutables?: boolean;
    /**
     * During installation the dependencies of some packages are automatically patched. If you want to disable this, set this config to false.
     *
     * @schema PnpmWorkspaceYamlSchema#ignoreCompatibilityDb
     */
    readonly ignoreCompatibilityDb?: boolean;
    /**
     * Determines how pnpm resolves dependencies, See https://pnpm.io/settings#resolutionmode
     *
     * @schema PnpmWorkspaceYamlSchema#resolutionMode
     */
    readonly resolutionMode?: PnpmWorkspaceYamlSchemaResolutionMode;
    /**
     * Set this to true if the registry that you are using returns the "time" field in the abbreviated metadata.
     *
     * @schema PnpmWorkspaceYamlSchema#registrySupportsTimeField
     */
    readonly registrySupportsTimeField?: boolean;
    /**
     * When false, the NODE_PATH environment variable is not set in the command shims.
     *
     * @schema PnpmWorkspaceYamlSchema#extendNodePath
     */
    readonly extendNodePath?: boolean;
    /**
     * When deploying a package or installing a local package, all files of the package are copied.
     *
     * @schema PnpmWorkspaceYamlSchema#deployAllFiles
     */
    readonly deployAllFiles?: boolean;
    /**
     * When set to true, dependencies that are already symlinked to the root node_modules directory of the workspace will not be symlinked to subproject node_modules directories.
     *
     * @schema PnpmWorkspaceYamlSchema#dedupeDirectDeps
     */
    readonly dedupeDirectDeps?: boolean;
    /**
     * When this setting is enabled, dependencies that are injected will be symlinked from the workspace whenever possible.
     *
     * @schema PnpmWorkspaceYamlSchema#dedupeInjectedDeps
     */
    readonly dedupeInjectedDeps?: boolean;
    /**
     * When enabled, a fast check will be performed before proceeding to installation. This way a repeat install or an install on a project with everything up-to-date becomes a lot faster.
     *
     * @schema PnpmWorkspaceYamlSchema#optimisticRepeatInstall
     */
    readonly optimisticRepeatInstall?: boolean;
    /**
     * Check if current branch is your publish branch, clean, and up-to-date with remote.
     *
     * @schema PnpmWorkspaceYamlSchema#gitChecks
     */
    readonly gitChecks?: boolean;
    /**
     * UNDOCUMENTED. When `true`, `pnpm publish` writes the README file's content into the published package.json (the `readme` field), so registries such as npmjs.com render the package's README. Added in pnpm 6.28.0; pnpm does not embed the README unless this is enabled. It also won't override a `readme` field already set in the package.json
     *
     * @schema PnpmWorkspaceYamlSchema#embedReadme
     */
    readonly embedReadme?: boolean;
    /**
     * The primary branch of the repository which is used for publishing the latest changes.
     *
     * @schema PnpmWorkspaceYamlSchema#publishBranch
     */
    readonly publishBranch?: string;
    /**
     * Versioning settings for pnpm's native workspace release management, used by `pnpm change` and recursive `pnpm version`.
     *
     * @schema PnpmWorkspaceYamlSchema#versioning
     */
    readonly versioning?: PnpmWorkspaceYamlSchemaVersioning;
    /**
     * When publishing from a supported cloud CI/CD system, the package will be publicly linked to where it was built and published from.
     *
     * @schema PnpmWorkspaceYamlSchema#provenance
     */
    readonly provenance?: boolean;
    /**
     * The location of the local pnpmfile.
     *
     * @schema PnpmWorkspaceYamlSchema#pnpmfile
     */
    readonly pnpmfile?: string;
    /**
     * The location of a global pnpmfile. A global pnpmfile is used by all projects during installation.
     *
     * @schema PnpmWorkspaceYamlSchema#globalPnpmfile
     */
    readonly globalPnpmfile?: string;
    /**
     * .pnpmfile.cjs will be ignored. Useful together with --ignore-scripts when you want to make sure that no script gets executed during install.
     *
     * @schema PnpmWorkspaceYamlSchema#ignorePnpmfile
     */
    readonly ignorePnpmfile?: boolean;
    /**
     * The generated patch file will be saved to this directory.
     *
     * @schema PnpmWorkspaceYamlSchema#patchesDir
     */
    readonly patchesDir?: string;
    /**
     * When true, pnpm will run any pre/post scripts automatically.
     *
     * @schema PnpmWorkspaceYamlSchema#enablePrePostScripts
     */
    readonly enablePrePostScripts?: boolean;
    /**
     * The shell to use for scripts run with the pnpm run command.
     *
     * @schema PnpmWorkspaceYamlSchema#scriptShell
     */
    readonly scriptShell?: string;
    /**
     * When true, pnpm will use a JavaScript implementation of a bash-like shell to execute scripts.
     *
     * @schema PnpmWorkspaceYamlSchema#shellEmulator
     */
    readonly shellEmulator?: boolean;
    /**
     * Saved dependencies will be configured with an exact version rather than using pnpm's default semver range operator.
     *
     * @schema PnpmWorkspaceYamlSchema#saveExact
     */
    readonly saveExact?: boolean;
    /**
     * minimumReleaseAge defines the minimum number of minutes that must pass after a version is published before pnpm will install it. This applies to all dependencies, including transitive ones.
     *
     * @schema PnpmWorkspaceYamlSchema#minimumReleaseAge
     */
    readonly minimumReleaseAge?: number;
    /**
     * If you set `minimumReleaseAge` but need certain dependencies to always install the newest version immediately, you can list them under `minimumReleaseAgeExclude`. The exclusion works by `package name` and applies to all versions of that package.
     *
     * @schema PnpmWorkspaceYamlSchema#minimumReleaseAgeExclude
     */
    readonly minimumReleaseAgeExclude?: string[];
    /**
     * Controls how pnpm behaves when no version of a dependency satisfies the minimumReleaseAge constraint within the requested range.
     * https://pnpm.io/settings#minimumreleaseagestrict
     *
     * @schema PnpmWorkspaceYamlSchema#minimumReleaseAgeStrict
     */
    readonly minimumReleaseAgeStrict?: boolean;
    /**
     * Bypass staleness checks for cached data. Missing data will still be requested from the server.
     *
     * @schema PnpmWorkspaceYamlSchema#preferOffline
     */
    readonly preferOffline?: boolean;
    /**
     * When set to no-downgrade, pnpm will fail if a package's trust level has decreased compared to previous releases. For example, if a package was previously published by a trusted publisher but now only has provenance or no trust evidence, installation will fail. This helps prevent installing potentially compromised versions.
     *
     * @schema PnpmWorkspaceYamlSchema#trustPolicy
     */
    readonly trustPolicy?: PnpmWorkspaceYamlSchemaTrustPolicy;
    /**
     * You can now list one or more specific packages or versions that pnpm should allow to install, even if those packages don't satisfy the trust policy requirement.
     *
     * @schema PnpmWorkspaceYamlSchema#trustPolicyExclude
     */
    readonly trustPolicyExclude?: string[];
    /**
     * A map of package matchers to explicitly allow (`true`) or disallow (`false`) script execution. This field replaces `onlyBuiltDependencies` and `ignoredBuiltDependencies` (which are also deprecated by this new setting), providing a single source of truth.
     *
     * @schema PnpmWorkspaceYamlSchema#allowBuilds
     */
    readonly allowBuilds?: any;
    /**
     * When set to true, it prevents the resolution of exotic protocols (like git+ssh: or direct https: tarballs) in transitive dependencies. Only direct dependencies are allowed to use exotic sources.
     *
     * @schema PnpmWorkspaceYamlSchema#blockExoticSubdeps
     */
    readonly blockExoticSubdeps?: boolean;
    /**
     * Allows ignoring the trust policy check for packages published more than the specified number of minutes ago. This is useful when enabling strict trust policies, as it allows older versions of packages (which may lack a process for publishing with signatures or provenance) to be installed without manual exclusion, assuming they are safe due to their age.
     *
     * @schema PnpmWorkspaceYamlSchema#trustPolicyIgnoreAfter
     */
    readonly trustPolicyIgnoreAfter?: number;
    /**
     * Controls the level of issues reported by `pnpm audit`. When set to 'low', all vulnerabilities are reported. When set to 'moderate', 'high', or 'critical', only vulnerabilities with that severity or higher are reported.
     *
     * @schema PnpmWorkspaceYamlSchema#auditLevel
     */
    readonly auditLevel?: PnpmWorkspaceYamlSchemaAuditLevel;
    /**
     * When enabled, peer dependency suffixes use version-only identifiers (`name@version`) instead of full dep paths, eliminating nested suffixes like `(foo@1.0.0(bar@2.0.0))`. This dramatically reduces the number of package instances in projects with many recursive peer dependencies.
     *
     * @schema PnpmWorkspaceYamlSchema#dedupePeers
     */
    readonly dedupePeers?: boolean;
    /**
     * The path to a file containing registry authentication tokens. By default, pnpm reads auth tokens from ~/.npmrc as a fallback for registry authentication. Use this setting to point to a different file instead.
     *
     * @schema PnpmWorkspaceYamlSchema#npmrcAuthFile
     */
    readonly npmrcAuthFile?: string;
    /**
     * When `true`, pnpm skips the `minimumReleaseAge` check for a package whose registry metadata does not include the time field (some private registries and mirrors omit it). Set to `false` to fail resolution in that case instead of installing the package.
     *
     * @schema PnpmWorkspaceYamlSchema#minimumReleaseAgeIgnoreMissingTime
     */
    readonly minimumReleaseAgeIgnoreMissingTime?: boolean;
    /**
     * Configure registries for scoped packages in `pnpm-workspace.yaml`. The `default` key sets the main registry (equivalent to the `registry` `.npmrc` setting). Scoped keys configure registries for specific package scopes.
     *
     * @schema PnpmWorkspaceYamlSchema#registries
     */
    readonly registries?: {
        [key: string]: string;
    };
    /**
     * Defines named registry aliases that can be used as a prefix when installing packages, e.g. `pnpm add work:@corp/lib@^2.0.0` resolves `@corp/lib@^2.0.0` against the configured URL. Built-in aliases `gh:` (https://npm.pkg.github.com/) and `npmjs:` (https://registry.npmjs.org/) work without any configuration and can be overridden. An alias must start with a letter and contain only letters, digits, `.`, `_`, and `-`. Added in pnpm 11.1.0.
     *
     * @schema PnpmWorkspaceYamlSchema#namedRegistries
     */
    readonly namedRegistries?: {
        [key: string]: string;
    };
    /**
     * When set to true, pnpm populates the virtual store without creating importer symlinks, hoisting, bin links, or running lifecycle scripts. This is useful for pre-populating a store (e.g., in Nix builds) without creating unnecessary project-level artifacts. pnpm fetch uses this mode internally.
     *
     * @schema PnpmWorkspaceYamlSchema#virtualStoreOnly
     */
    readonly virtualStoreOnly?: boolean;
    /**
     * Overrides the `onFail` behavior of both the `packageManager` field and `devEngines.packageManager` when the running pnpm version does not match the declared one.
     *
     * @schema PnpmWorkspaceYamlSchema#pmOnFail
     */
    readonly pmOnFail?: PnpmWorkspaceYamlSchemaPmOnFail;
    /**
     * Overrides the `onFail` field of `devEngines.runtime` (and `engines.runtime`) in the root project's `package.json`. This is useful when you want a different local behavior than what is written in the manifest — for instance, forcing pnpm to download the declared runtime even when the manifest sets `onFail: "warn"`.
     *
     * @schema PnpmWorkspaceYamlSchema#runtimeOnFail
     */
    readonly runtimeOnFail?: PnpmWorkspaceYamlSchemaRuntimeOnFail;
    /**
     * Configure custom Node.js download mirrors in `pnpm-workspace.yaml`. The keys are release channels (`release`, `rc`, `nightly`, `v8-canary`, etc.) and the values are base URLs.
     *
     * @schema PnpmWorkspaceYamlSchema#nodeDownloadMirrors
     */
    readonly nodeDownloadMirrors?: {
        [key: string]: string;
    };
    /**
     * A new trustLockfile setting controls whether pnpm install re-applies the `minimumReleaseAge` / `trustPolicy: 'no-downgrade'` checks to every entry in the loaded lockfile. When true, the install treats the lockfile as already-trusted and skips the verification pass — useful for closed-source projects where every commit comes from a trusted author. The default is false, so verification stays on by default.
     *
     * @schema PnpmWorkspaceYamlSchema#trustLockfile
     */
    readonly trustLockfile?: boolean;
    /**
     * Added a new hoistingLimits setting for `nodeLinker: hoisted` installs, mirroring yarn's `nmHoistingLimits`. It accepts `none` (the default — hoist as far as possible), workspaces (hoist only as far as each workspace package), or dependencies (hoist only up to each workspace package's direct dependencies).
     *
     * @schema PnpmWorkspaceYamlSchema#hoistingLimits
     */
    readonly hoistingLimits?: PnpmWorkspaceYamlSchemaHoistingLimits;
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchema' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchema(obj: PnpmWorkspaceYamlSchema | undefined): Record<string, any> | undefined;
/**
 * Controlling if and how dependencies are added to the default catalog
 *
 * @schema PnpmWorkspaceYamlSchemaCatalogMode
 */
export declare enum PnpmWorkspaceYamlSchemaCatalogMode {
    /** strict */
    STRICT = "strict",
    /** prefer */
    PREFER = "prefer",
    /** manual */
    MANUAL = "manual"
}
/**
 * @schema PnpmWorkspaceYamlSchemaPeerDependencyRules
 */
export interface PnpmWorkspaceYamlSchemaPeerDependencyRules {
    /**
     * pnpm will not print warnings about missing peer dependencies from this list.
     *
     * @schema PnpmWorkspaceYamlSchemaPeerDependencyRules#ignoreMissing
     */
    readonly ignoreMissing?: string[];
    /**
     * Unmet peer dependency warnings will not be printed for peer dependencies of the specified range.
     *
     * @schema PnpmWorkspaceYamlSchemaPeerDependencyRules#allowedVersions
     */
    readonly allowedVersions?: any;
    /**
     * Any peer dependency matching the pattern will be resolved from any version, regardless of the range specified in "peerDependencies".
     *
     * @schema PnpmWorkspaceYamlSchemaPeerDependencyRules#allowAny
     */
    readonly allowAny?: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaPeerDependencyRules' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaPeerDependencyRules(obj: PnpmWorkspaceYamlSchemaPeerDependencyRules | undefined): Record<string, any> | undefined;
/**
 * @schema PnpmWorkspaceYamlSchemaUpdate
 */
export interface PnpmWorkspaceYamlSchemaUpdate {
    /**
     * A list of dependency name patterns that pnpm update and pnpm outdated should skip.
     *
     * @schema PnpmWorkspaceYamlSchemaUpdate#ignoreDeps
     */
    readonly ignoreDeps?: string[];
    /**
     * When true, pnpm update writes a change intent after updating workspace manifests.
     *
     * @schema PnpmWorkspaceYamlSchemaUpdate#changeset
     */
    readonly changeset?: boolean;
    /**
     * When true, pnpm update and pnpm outdated also check the GitHub Actions referenced by the repository's workflow files.
     *
     * @schema PnpmWorkspaceYamlSchemaUpdate#githubActions
     */
    readonly githubActions?: boolean;
    /**
     * The base URL of the GitHub server that hosts the repositories of the GitHub Actions referenced by the workflow files.
     *
     * @schema PnpmWorkspaceYamlSchemaUpdate#githubActionsServer
     */
    readonly githubActionsServer?: string;
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaUpdate' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaUpdate(obj: PnpmWorkspaceYamlSchemaUpdate | undefined): Record<string, any> | undefined;
/**
 * @schema PnpmWorkspaceYamlSchemaUpdateConfig
 */
export interface PnpmWorkspaceYamlSchemaUpdateConfig {
    /**
     * A list of packages that should be ignored when running "pnpm outdated" or "pnpm update --latest".
     *
     * @schema PnpmWorkspaceYamlSchemaUpdateConfig#ignoreDependencies
     */
    readonly ignoreDependencies?: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaUpdateConfig' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaUpdateConfig(obj: PnpmWorkspaceYamlSchemaUpdateConfig | undefined): Record<string, any> | undefined;
/**
 * @schema PnpmWorkspaceYamlSchemaAudit
 */
export interface PnpmWorkspaceYamlSchemaAudit {
    /**
     * Only print advisories with severity greater than or equal to this level.
     *
     * @schema PnpmWorkspaceYamlSchemaAudit#level
     */
    readonly level?: PnpmWorkspaceYamlSchemaAuditLevel;
    /**
     * A list of GHSA codes that will be ignored by pnpm audit.
     *
     * @schema PnpmWorkspaceYamlSchemaAudit#ignore
     */
    readonly ignore?: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaAudit' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaAudit(obj: PnpmWorkspaceYamlSchemaAudit | undefined): Record<string, any> | undefined;
/**
 * @schema PnpmWorkspaceYamlSchemaAuditConfig
 */
export interface PnpmWorkspaceYamlSchemaAuditConfig {
    /**
     * A list of CVE IDs that will be ignored by "pnpm audit".
     *
     * @schema PnpmWorkspaceYamlSchemaAuditConfig#ignoreCves
     */
    readonly ignoreCves?: string[];
    /**
     * A list of GHSA Codes that will be ignored by "pnpm audit".
     *
     * @schema PnpmWorkspaceYamlSchemaAuditConfig#ignoreGhsas
     */
    readonly ignoreGhsas?: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaAuditConfig' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaAuditConfig(obj: PnpmWorkspaceYamlSchemaAuditConfig | undefined): Record<string, any> | undefined;
/**
 * Specifies architectures for which you'd like to install optional dependencies, even if they don't match the architecture of the system running the install.
 *
 * @schema PnpmWorkspaceYamlSchemaSupportedArchitectures
 */
export interface PnpmWorkspaceYamlSchemaSupportedArchitectures {
    /**
     * @schema PnpmWorkspaceYamlSchemaSupportedArchitectures#os
     */
    readonly os?: string[];
    /**
     * @schema PnpmWorkspaceYamlSchemaSupportedArchitectures#cpu
     */
    readonly cpu?: string[];
    /**
     * @schema PnpmWorkspaceYamlSchemaSupportedArchitectures#libc
     */
    readonly libc?: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaSupportedArchitectures' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaSupportedArchitectures(obj: PnpmWorkspaceYamlSchemaSupportedArchitectures | undefined): Record<string, any> | undefined;
/**
 * @schema PnpmWorkspaceYamlSchemaExecutionEnv
 */
export interface PnpmWorkspaceYamlSchemaExecutionEnv {
    /**
     * Specifies which exact Node.js version should be used for the project's runtime.
     *
     * @schema PnpmWorkspaceYamlSchemaExecutionEnv#nodeVersion
     */
    readonly nodeVersion?: string;
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaExecutionEnv' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaExecutionEnv(obj: PnpmWorkspaceYamlSchemaExecutionEnv | undefined): Record<string, any> | undefined;
/**
 * Defines what linker should be used for installing Node packages.
 *
 * @schema PnpmWorkspaceYamlSchemaNodeLinker
 */
export declare enum PnpmWorkspaceYamlSchemaNodeLinker {
    /** isolated */
    ISOLATED = "isolated",
    /** hoisted */
    HOISTED = "hoisted",
    /** pnp */
    PNP = "pnp"
}
/**
 * Controls the way packages are imported from the store (if you want to disable symlinks inside node_modules, then you need to change the nodeLinker setting, not this one).
 *
 * @schema PnpmWorkspaceYamlSchemaPackageImportMethod
 */
export declare enum PnpmWorkspaceYamlSchemaPackageImportMethod {
    /** auto */
    AUTO = "auto",
    /** hardlink */
    HARDLINK = "hardlink",
    /** copy */
    COPY = "copy",
    /** clone */
    CLONE = "clone",
    /** clone-or-copy */
    CLONE_HYPHEN_OR_HYPHEN_COPY = "clone-or-copy"
}
/**
 * Controls colors in the output.
 *
 * @schema PnpmWorkspaceYamlSchemaColor
 */
export declare enum PnpmWorkspaceYamlSchemaColor {
    /** always */
    ALWAYS = "always",
    /** auto */
    AUTO = "auto",
    /** never */
    NEVER = "never"
}
/**
 * Any logs at or higher than the given level will be shown.
 *
 * @schema PnpmWorkspaceYamlSchemaLoglevel
 */
export declare enum PnpmWorkspaceYamlSchemaLoglevel {
    /** debug */
    DEBUG = "debug",
    /** info */
    INFO = "info",
    /** warn */
    WARN = "warn",
    /** error */
    ERROR = "error"
}
/**
 * Allows you to customize the output style of the logs.
 * https://pnpm.io/cli/install#--reportername
 *
 * @schema PnpmWorkspaceYamlSchemaReporter
 */
export declare enum PnpmWorkspaceYamlSchemaReporter {
    /** silent */
    SILENT = "silent",
    /** default */
    DEFAULT = "default",
    /** append-only */
    APPEND_HYPHEN_ONLY = "append-only",
    /** ndjson */
    NDJSON = "ndjson"
}
/**
 * If this is enabled, locally available packages are linked to node_modules instead of being downloaded from the registry.
 *
 * @schema PnpmWorkspaceYamlSchemaLinkWorkspacePackages
 */
export declare class PnpmWorkspaceYamlSchemaLinkWorkspacePackages {
    readonly value: boolean | string;
    static fromBoolean(value: boolean): PnpmWorkspaceYamlSchemaLinkWorkspacePackages;
    static fromString(value: string): PnpmWorkspaceYamlSchemaLinkWorkspacePackages;
    private constructor();
}
/**
 * This setting controls how dependencies that are linked from the workspace are added to package.json.
 *
 * @schema PnpmWorkspaceYamlSchemaSaveWorkspaceProtocol
 */
export declare class PnpmWorkspaceYamlSchemaSaveWorkspaceProtocol {
    readonly value: boolean | string;
    static fromBoolean(value: boolean): PnpmWorkspaceYamlSchemaSaveWorkspaceProtocol;
    static fromString(value: string): PnpmWorkspaceYamlSchemaSaveWorkspaceProtocol;
    private constructor();
}
/**
 * Configure how versions of packages installed to a package.json file get prefixed.
 *
 * @schema PnpmWorkspaceYamlSchemaSavePrefix
 */
export declare enum PnpmWorkspaceYamlSchemaSavePrefix {
    /** ^ */
    VALUE_CARAT = "^",
    /** ~ */
    VALUE_TILDE = "~",
    /** = */
    VALUE_EQUALS = "="
}
/**
 * Determines how pnpm resolves dependencies, See https://pnpm.io/settings#resolutionmode
 *
 * @schema PnpmWorkspaceYamlSchemaResolutionMode
 */
export declare enum PnpmWorkspaceYamlSchemaResolutionMode {
    /** highest */
    HIGHEST = "highest",
    /** time-based */
    TIME_HYPHEN_BASED = "time-based",
    /** lowest-direct */
    LOWEST_HYPHEN_DIRECT = "lowest-direct"
}
/**
 * Versioning settings for pnpm's native workspace release management, used by `pnpm change` and recursive `pnpm version`.
 *
 * @schema PnpmWorkspaceYamlSchemaVersioning
 */
export interface PnpmWorkspaceYamlSchemaVersioning {
    /**
     * Groups of workspace projects that always release together at one shared version. The shared version is the highest current version in the group, bumped by the largest bump any member needs.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#fixed
     */
    readonly fixed?: string[][];
    /**
     * Workspace projects permanently excluded from versioning and dependent propagation.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#ignore
     */
    readonly ignore?: string[];
    /**
     * Caps the bump that a release from the current checkout may apply, after dependent propagation and fixed-group resolution.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#maxBump
     */
    readonly maxBump?: PnpmWorkspaceYamlSchemaVersioningMaxBump;
    /**
     * Maps a workspace project to a release lane. Unlisted projects are on the reserved `main` lane and release stable versions.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#lanes
     */
    readonly lanes?: {
        [key: string]: string;
    };
    /**
     * Ties member projects to a lead project and constrains their major versions to the lead's major-version band.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#epics
     */
    readonly epics?: PnpmWorkspaceYamlSchemaVersioningEpics[];
    /**
     * Controls where release changelog content is stored.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioning#changelog
     */
    readonly changelog?: PnpmWorkspaceYamlSchemaVersioningChangelog;
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaVersioning' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaVersioning(obj: PnpmWorkspaceYamlSchemaVersioning | undefined): Record<string, any> | undefined;
/**
 * When set to no-downgrade, pnpm will fail if a package's trust level has decreased compared to previous releases. For example, if a package was previously published by a trusted publisher but now only has provenance or no trust evidence, installation will fail. This helps prevent installing potentially compromised versions.
 *
 * @schema PnpmWorkspaceYamlSchemaTrustPolicy
 */
export declare enum PnpmWorkspaceYamlSchemaTrustPolicy {
    /** off */
    OFF = "off",
    /** no-downgrade */
    NO_HYPHEN_DOWNGRADE = "no-downgrade"
}
/**
 * Only print advisories with severity greater than or equal to this level.
 *
 * @schema PnpmWorkspaceYamlSchemaAuditLevel
 */
export declare enum PnpmWorkspaceYamlSchemaAuditLevel {
    /** low */
    LOW = "low",
    /** moderate */
    MODERATE = "moderate",
    /** high */
    HIGH = "high",
    /** critical */
    CRITICAL = "critical"
}
/**
 * Overrides the `onFail` behavior of both the `packageManager` field and `devEngines.packageManager` when the running pnpm version does not match the declared one.
 *
 * @schema PnpmWorkspaceYamlSchemaPmOnFail
 */
export declare enum PnpmWorkspaceYamlSchemaPmOnFail {
    /** download */
    DOWNLOAD = "download",
    /** error */
    ERROR = "error",
    /** warn */
    WARN = "warn",
    /** ignore */
    IGNORE = "ignore"
}
/**
 * Overrides the `onFail` field of `devEngines.runtime` (and `engines.runtime`) in the root project's `package.json`. This is useful when you want a different local behavior than what is written in the manifest — for instance, forcing pnpm to download the declared runtime even when the manifest sets `onFail: "warn"`.
 *
 * @schema PnpmWorkspaceYamlSchemaRuntimeOnFail
 */
export declare enum PnpmWorkspaceYamlSchemaRuntimeOnFail {
    /** download */
    DOWNLOAD = "download",
    /** error */
    ERROR = "error",
    /** warn */
    WARN = "warn",
    /** ignore */
    IGNORE = "ignore"
}
/**
 * Added a new hoistingLimits setting for `nodeLinker: hoisted` installs, mirroring yarn's `nmHoistingLimits`. It accepts `none` (the default — hoist as far as possible), workspaces (hoist only as far as each workspace package), or dependencies (hoist only up to each workspace package's direct dependencies).
 *
 * @schema PnpmWorkspaceYamlSchemaHoistingLimits
 */
export declare enum PnpmWorkspaceYamlSchemaHoistingLimits {
    /** node */
    NODE = "node",
    /** workspaces */
    WORKSPACES = "workspaces",
    /** dependencies */
    DEPENDENCIES = "dependencies"
}
/**
 * Caps the bump that a release from the current checkout may apply, after dependent propagation and fixed-group resolution.
 *
 * @schema PnpmWorkspaceYamlSchemaVersioningMaxBump
 */
export declare enum PnpmWorkspaceYamlSchemaVersioningMaxBump {
    /** patch */
    PATCH = "patch",
    /** minor */
    MINOR = "minor",
    /** major */
    MAJOR = "major"
}
/**
 * @schema PnpmWorkspaceYamlSchemaVersioningEpics
 */
export interface PnpmWorkspaceYamlSchemaVersioningEpics {
    /**
     * Lead workspace project name or a `./`-prefixed workspace-relative directory.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioningEpics#lead
     */
    readonly lead: string;
    /**
     * Project selectors matched in order, supporting name globs, `./`-prefixed directory globs, and `!`-prefixed negations.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioningEpics#packages
     */
    readonly packages: string[];
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaVersioningEpics' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaVersioningEpics(obj: PnpmWorkspaceYamlSchemaVersioningEpics | undefined): Record<string, any> | undefined;
/**
 * Controls where release changelog content is stored.
 *
 * @schema PnpmWorkspaceYamlSchemaVersioningChangelog
 */
export interface PnpmWorkspaceYamlSchemaVersioningChangelog {
    /**
     * Changelog storage mode. `registry` composes changelog entries at publish time, while `repository` commits CHANGELOG.md files in packages.
     *
     * @schema PnpmWorkspaceYamlSchemaVersioningChangelog#storage
     */
    readonly storage?: PnpmWorkspaceYamlSchemaVersioningChangelogStorage;
}
/**
 * Converts an object of type 'PnpmWorkspaceYamlSchemaVersioningChangelog' to JSON representation.
 * @internal
 */
export declare function toJson_PnpmWorkspaceYamlSchemaVersioningChangelog(obj: PnpmWorkspaceYamlSchemaVersioningChangelog | undefined): Record<string, any> | undefined;
/**
 * Changelog storage mode. `registry` composes changelog entries at publish time, while `repository` commits CHANGELOG.md files in packages.
 *
 * @schema PnpmWorkspaceYamlSchemaVersioningChangelogStorage
 */
export declare enum PnpmWorkspaceYamlSchemaVersioningChangelogStorage {
    /** registry */
    REGISTRY = "registry",
    /** repository */
    REPOSITORY = "repository"
}
